// ---------------- 任务 08：真实共享驱动与写编排的完整生命周期 ----------------
// B09 不再投递匿名 CloseRequested；旧 B05-B08 的投递/裁决模拟改为
// 最后可取消的准备阶段与不可撤销的原生提交，不能冒称验证了旧事件的身份。

function deferred() {
  let resolve, reject;
  const promise = new Promise((res, rej) => { resolve = res; reject = rej; });
  return { promise, resolve, reject };
}

const flushClose = () => new Promise((resolve) => setImmediate(resolve));

/** 只替换环境适配；关闭与写入的决策、登记、回滚和收尾均来自生产类。 */
function makeDriverEnv({ coordinator = new CloseCoordinator() } = {}) {
  const native = [];
  const errors = [];
  const asked = [];
  const settled = [];
  const guards = new CloseGuardGate();
  guards.markInstalled("window");
  guards.markInstalled("exit");
  let releaseImpl = async () => {};
  let nativeImpl = async () => {};
  let guardImpl = async () => {};
  let releaseCalls = 0;
  let guardCalls = 0;
  const driver = new CloseDriver({
    coordinator,
    releaseExitGuard: () => { releaseCalls += 1; return releaseImpl(); },
    closeWindow: () => { native.push("close"); return nativeImpl("close"); },
    exitApp: () => { native.push("exit"); return nativeImpl("exit"); },
    onError: (error) => errors.push(error),
    onAsk: (intent, writing, pending) => asked.push({ intent, writing, pending }),
    onSettled: () => settled.push(true),
  });
  const writes = new WriteGuardOrchestrator({
    closeDriver: driver,
    closeBlockedReason: "closing",
    guardsReady: () => guards.ready,
    guardBlockedReason: () => guards.blockedReason,
    register: (id) => coordinator.beginWrite(id),
    guard: () => { guardCalls += 1; return guardImpl(); },
    rollback: (id) => coordinator.rollbackWrite(id),
    reconcile: () => driver.notifyStateChanged(),
    endWrite: (id, needsVerification) => coordinator.endWrite(id, needsVerification),
  });
  return {
    coordinator, driver, writes, native, errors, asked, settled, guards,
    setRelease(fn) { releaseImpl = fn; },
    setNative(fn) { nativeImpl = fn; },
    setGuard(fn) { guardImpl = fn; },
    releaseCalls() { return releaseCalls; },
    guardCalls() { return guardCalls; },
  };
}

for (const intent of ["close", "exit"]) {
  test(`无写入的 ${intent} 执行原动作，回包后保持终态门禁`, async () => {
    const env = makeDriverEnv();
    env.driver.handleRequest(intent);
    await flushClose();
    assert.deepEqual(env.native, [intent]);
    assert.equal(env.releaseCalls(), intent === "exit" ? 1 : 0);
    assert.equal(env.coordinator.pendingIntent(), null);
    assert.equal(env.coordinator.isExecuting(), false);
    assert.equal(env.driver.currentPhase(), "closing");
    assert.equal((await env.writes.begin("wt-a")).ok, false);
  });

  test(`A/B 跨 worktree 写入正常结束后仅执行原 ${intent}`, async () => {
    const env = makeDriverEnv();
    assert.equal((await env.writes.begin("wt-a")).ok, true);
    assert.equal(env.driver.handleRequest(intent).kind, "ask");
    env.driver.handleChoice("wait");
    assert.equal((await env.writes.begin("wt-b")).ok, true);
    env.driver.handleRequest(intent === "close" ? "exit" : "close");
    env.writes.end("wt-a", false);
    await flushClose();
    assert.deepEqual(env.native, []);
    assert.deepEqual(env.coordinator.writingWorktrees(), ["wt-b"]);
    env.writes.end("wt-b", false);
    await flushClose();
    assert.deepEqual(env.native, [intent]);
    assert.equal(env.coordinator.pendingIntent(), null);
  });

  test(`最后一笔写入结束早于选择，${intent} 询问仍可 Wait/Stay`, async () => {
    const env = makeDriverEnv();
    await env.writes.begin("wt-a");
    env.driver.handleRequest(intent);
    env.writes.end("wt-a", false);
    await flushClose();
    assert.deepEqual(env.native, [], "仅展示询问不等于授权");
    assert.equal(env.driver.currentPhase(), "asking");
    env.driver.handleChoice("wait");
    await flushClose();
    assert.deepEqual(env.native, [intent]);
    assert.equal(env.coordinator.pendingIntent(), null);
  });

  test(`已 Wait 的 ${intent} 遇到待核对，真实核对并明确继续前不提交`, async () => {
    const env = makeDriverEnv();
    await env.writes.begin("wt-a");
    env.driver.handleRequest(intent);
    env.driver.handleChoice("wait");
    env.writes.end("wt-a", true);
    await flushClose();
    assert.deepEqual(env.native, []);
    assert.deepEqual(env.asked.at(-1).pending, ["wt-a"]);
    const generation = env.coordinator.pendingGeneration("wt-a");
    assert.equal(env.coordinator.acknowledgePending("wt-a", generation), true);
    env.driver.handlePendingContinue();
    await flushClose();
    assert.deepEqual(env.native, [intent]);
    assert.equal(env.coordinator.pendingIntent(), null);
  });

  test(`${intent} 原生提交失败不自动重试，原请求保留到用户重新选择`, async () => {
    const env = makeDriverEnv();
    const error = new Error("native failed");
    env.setNative(async () => { throw error; });
    env.driver.handleRequest(intent);
    await flushClose();
    assert.deepEqual(env.native, [intent]);
    assert.deepEqual(env.errors, [error]);
    assert.equal(env.coordinator.pendingIntent(), intent);
    assert.equal(env.driver.currentPhase(), "asking");
    assert.equal(env.driver.canStartWrite(), true, "失败时未提交原生动作，可留在应用");
    for (let i = 0; i < 10; i += 1) env.driver.notifyStateChanged();
    await flushClose();
    assert.deepEqual(env.native, [intent], "禁止无界自动重试");
    env.setNative(async () => {});
    env.driver.handleChoice("wait");
    await flushClose();
    assert.deepEqual(env.native, [intent, intent]);
    assert.equal(env.coordinator.pendingIntent(), null);
  });

  test(`${intent} 最终提交至销毁期间，重复事件与迟到选择不能解除门禁`, async () => {
    const env = makeDriverEnv();
    const native = deferred();
    env.setNative(() => native.promise);
    env.driver.handleRequest(intent);
    await flushClose();
    assert.deepEqual(env.native, [intent]);
    assert.equal(env.driver.currentPhase(), "closing");
    const settled = env.settled.length;
    assert.equal(settled, 1, "最终提交时同步隐藏询问");
    for (const delivered of [false, true]) {
      if (delivered) {
        native.resolve();
        await flushClose();
      }
      for (let i = 0; i < 10; i += 1) {
        env.driver.handleNativeCloseRequest();
        env.driver.handleRequest("exit");
        env.driver.handleChoice("stay");
        env.driver.handleChoice("wait");
        env.driver.handlePendingContinue();
        env.driver.notifyStateChanged();
      }
      const guardsBefore = env.guardCalls();
      for (const entry of ["stage", "unstage", "discard", "restore", "save-as"]) {
        const id = entry === "save-as" ? "save-as:/fixture/destination" : "wt-a";
        const started = await env.writes.begin(id);
        assert.deepEqual(started, { ok: false, reason: "closing" }, `${entry} 共享生产入口拒绝`);
      }
      assert.equal(env.guardCalls(), guardsBefore, "拒绝时不发保护 IPC");
      assert.deepEqual(env.coordinator.writingWorktrees(), [], "没有幽灵登记");
      assert.deepEqual(env.native, [intent], "没有重复原生提交");
      assert.equal(env.driver.currentPhase(), "closing");
      assert.equal(env.settled.length, settled, "迟到选择/回包不产生旧 UI 效果");
    }
    assert.equal(env.coordinator.pendingIntent(), null);
    assert.deepEqual(env.errors, []);
  });
}

test("无关闭请求时，写入收尾不会制造请求", async () => {
  const env = makeDriverEnv();
  await env.writes.begin("wt-a");
  await env.writes.begin("save-as:/fixture/destination");
  env.writes.end("wt-a", false);
  env.writes.end("save-as:/fixture/destination", false);
  await flushClose();
  assert.deepEqual(env.native, []);
  assert.equal(env.coordinator.pendingIntent(), null);
});

test("Stay 不取消 A/B 写入，也不保留暗请求", async () => {
  const env = makeDriverEnv();
  await env.writes.begin("wt-a");
  await env.writes.begin("wt-b");
  env.driver.handleRequest("exit");
  env.driver.handleChoice("wait");
  env.driver.handleChoice("stay");
  assert.deepEqual(env.coordinator.writingWorktrees(), ["wt-a", "wt-b"]);
  env.writes.end("wt-a", false);
  env.writes.end("wt-b", false);
  await flushClose();
  assert.deepEqual(env.native, []);
  assert.equal(env.coordinator.pendingIntent(), null);
  env.driver.handleNativeCloseRequest();
  await flushClose();
  assert.deepEqual(env.native, ["close"], "新的真实用户请求正常完成");
  assert.equal(env.coordinator.pendingIntent(), null);
});

test("准备中的重复关闭/退出和写入收尾不递归、不重复认领", async () => {
  const env = makeDriverEnv();
  const release = deferred();
  env.setRelease(() => release.promise);
  env.driver.handleRequest("exit");
  await env.writes.begin("wt-b");
  env.writes.end("wt-b", false);
  for (let i = 0; i < 20; i += 1) {
    env.driver.notifyStateChanged();
    env.driver.handleRequest("exit");
    env.driver.handleNativeCloseRequest();
  }
  assert.equal(env.releaseCalls(), 1);
  assert.deepEqual(env.native, []);
  release.resolve();
  await flushClose();
  assert.deepEqual(env.native, ["exit"]);
  assert.equal(env.coordinator.pendingIntent(), null);
});

test("退出准备期间 B 开始写：最后复核不提交，B 结束后执行原 exit", async () => {
  const env = makeDriverEnv();
  const release = deferred();
  env.setRelease(() => release.promise);
  env.driver.handleRequest("exit");
  assert.equal((await env.writes.begin("wt-b")).ok, true);
  release.resolve();
  await flushClose();
  assert.deepEqual(env.native, []);
  assert.equal(env.coordinator.pendingIntent(), "exit");
  assert.deepEqual(env.asked.at(-1).writing, ["wt-b"]);
  env.setRelease(async () => {});
  env.writes.end("wt-b", false);
  await flushClose();
  assert.deepEqual(env.native, ["exit"]);
  assert.equal(env.coordinator.pendingIntent(), null);
});

test("保护建立仍挂起也算在途：退出等待到真实 begin/end 收尾", async () => {
  const env = makeDriverEnv();
  const guard = deferred();
  env.setGuard(() => guard.promise);
  const begin = env.writes.begin("wt-a");
  assert.deepEqual(env.coordinator.writingWorktrees(), ["wt-a"]);
  env.driver.handleRequest("exit");
  env.driver.handleChoice("wait");
  await flushClose();
  assert.deepEqual(env.native, []);
  guard.resolve();
  assert.equal((await begin).ok, true);
  assert.deepEqual(env.native, []);
  env.writes.end("wt-a", false);
  await flushClose();
  assert.deepEqual(env.native, ["exit"]);
});

test("保护失败回滚真正推进已授权请求，不等待下一笔无关写入", async () => {
  const env = makeDriverEnv();
  const guard = deferred();
  env.setGuard(() => guard.promise);
  const begin = env.writes.begin("wt-a");
  env.driver.handleRequest("exit");
  env.driver.handleChoice("wait");
  guard.reject(new Error("guard failed"));
  await assert.rejects(begin, /guard failed/);
  await flushClose();
  assert.deepEqual(env.coordinator.writingWorktrees(), []);
  assert.deepEqual(env.native, ["exit"]);
  assert.equal(env.coordinator.pendingIntent(), null);
});

for (const oldOutcome of ["resolve", "reject"]) {
  for (const newPhase of ["preparing", "submitted", "returned"]) {
    test(`Stay 后旧准备 ${oldOutcome} 到达新请求 ${newPhase}，不触碰新所有权`, async () => {
      const env = makeDriverEnv();
      const oldRelease = deferred();
      const newRelease = deferred();
      const native = deferred();
      env.setRelease(() => oldRelease.promise);
      env.driver.handleRequest("exit");
      assert.equal(env.driver.currentPhase(), "executing");
      env.driver.handleChoice("stay");
      env.setRelease(() => newRelease.promise);
      env.setNative(() => native.promise);
      env.driver.handleRequest("exit");
      const generation = env.coordinator.generation();
      if (newPhase !== "preparing") {
        newRelease.resolve();
        await flushClose();
      }
      if (newPhase === "returned") {
        native.resolve();
        await flushClose();
      }
      const before = {
        phase: env.driver.currentPhase(), intent: env.coordinator.pendingIntent(),
        claim: env.coordinator.isExecuting(), settled: env.settled.length, asked: env.asked.length,
      };
      oldRelease[oldOutcome](new Error("cancelled attempt"));
      await flushClose();
      assert.deepEqual({
        phase: env.driver.currentPhase(), intent: env.coordinator.pendingIntent(),
        claim: env.coordinator.isExecuting(), settled: env.settled.length, asked: env.asked.length,
      }, before, "旧成功/失败不得清 claim、改阶段、弹旧询问或清新 UI");
      assert.equal(env.coordinator.generation(), generation);
      assert.deepEqual(env.errors, []);
      newRelease.resolve();
      await flushClose();
      assert.deepEqual(env.native, ["exit"], "只有新请求最终提交原生动作");
      native.resolve();
      await flushClose();
      assert.equal(env.coordinator.pendingIntent(), null, "新请求完整结算，不只是投递计数");
      assert.equal(env.coordinator.isExecuting(), false);
      assert.equal(env.driver.currentPhase(), "closing");
      assert.equal((await env.writes.begin("wt-a")).ok, false);
    });
  }

  test(`Stay 后没有新请求，旧准备 ${oldOutcome} 也不得关窗`, async () => {
    const env = makeDriverEnv();
    const release = deferred();
    env.setRelease(() => release.promise);
    env.driver.handleRequest("exit");
    env.driver.handleChoice("stay");
    release[oldOutcome](new Error("cancelled attempt"));
    await flushClose();
    assert.deepEqual(env.native, []);
    assert.deepEqual(env.errors, []);
    assert.equal(env.coordinator.pendingIntent(), null);
    assert.equal(env.driver.currentPhase(), "idle");
    assert.equal((await env.writes.begin("wt-a")).ok, true);
  });
}

test("旧退出准备晚回，不把 Stay 后的新 close 改成 exit", async () => {
  const env = makeDriverEnv();
  const release = deferred();
  env.setRelease(() => release.promise);
  env.driver.handleRequest("exit");
  env.driver.handleChoice("stay");
  env.driver.handleNativeCloseRequest();
  await flushClose();
  release.resolve();
  await flushClose();
  assert.deepEqual(env.native, ["close"]);
  assert.equal(env.coordinator.pendingIntent(), null);
  assert.equal(env.driver.currentPhase(), "closing");
});

test("退出保护持续失败只尝试一次，随后可 Stay 并正常写入", async () => {
  const env = makeDriverEnv();
  env.setRelease(async () => { throw new Error("release failed"); });
  env.driver.handleRequest("exit");
  await flushClose();
  for (let i = 0; i < 10; i += 1) env.driver.notifyStateChanged();
  await flushClose();
  assert.equal(env.releaseCalls(), 1);
  assert.equal(env.errors.length, 1);
  assert.deepEqual(env.native, []);
  assert.equal(env.driver.currentPhase(), "asking");
  env.driver.handleChoice("stay");
  assert.equal(env.coordinator.pendingIntent(), null);
  assert.equal((await env.writes.begin("wt-a")).ok, true);
});

test("准备中的写入引入待核对，旧成功回包不能静默退出", async () => {
  const env = makeDriverEnv();
  const release = deferred();
  env.setRelease(() => release.promise);
  env.driver.handleRequest("exit");
  await env.writes.begin("wt-b");
  env.writes.end("wt-b", true);
  release.resolve();
  await flushClose();
  assert.deepEqual(env.native, []);
  assert.deepEqual(env.asked.at(-1).pending, ["wt-b"]);
  env.driver.handleChoice("stay");
  env.driver.notifyStateChanged();
  assert.deepEqual(env.coordinator.pendingWorktrees(), ["wt-b"], "Stay 不伪清待核对");
  assert.equal(env.coordinator.pendingIntent(), null);
});

test("旧 claim 的完成/失败/撤销不能清新 claim", () => {
  const c = new CloseCoordinator();
  c.request("close");
  const old = c.claimExecution();
  c.abandonExecution(old.claimId);
  const fresh = c.claimExecution();
  assert.notEqual(fresh.claimId, old.claimId);
  assert.equal(c.completeExecution(old.claimId), false);
  assert.equal(c.failExecution(old.claimId), false);
  assert.equal(c.abandonExecution(old.claimId), false);
  assert.equal(c.pendingIntent(), "close");
  assert.equal(c.isExecuting(), true);
  assert.equal(c.completeExecution(fresh.claimId), true);
});
