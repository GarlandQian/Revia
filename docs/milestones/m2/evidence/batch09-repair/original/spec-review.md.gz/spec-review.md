Spec 独立限定复核：缺失/部分0项，范围扩张0项，实现错误0项；无确定缺陷及严重度。本轮静态复核通过，不等于任务08验收完成。

- **Q96关闭与原动作闭合。** 对照 `spec.md:126`“等待完成后关闭／退出”和“留在应用”、`spec.md:127`“执行原关闭／退出请求”，`src/App.tsx:774`先阻止全部原生关闭默认行为；最终分别走 `src/App.tsx:1110`的窗口销毁与 `src/App.tsx:1111`的应用退出。`src-tauri/src/commands.rs:1065`复核退出保护后调用实际退出，未再用关闭窗口冒充退出。
- **旧所有权污染闭合。** `src/lib/refreshGate.ts:1523`允许Stay撤销准备；`src/lib/refreshGate.ts:1579`及 `src/lib/refreshGate.ts:1597`在成功、失败回包后先核attempt身份。旧回包不能清新claim或改变新请求阶段。`src/lib/refreshGate.ts:1588`同步进入closing并隐藏询问，迟到选择及通知不再开放写入。
- **生产写门禁闭合。** 对照 `spec.md:126`保留在途写，`src/App.tsx:1164`把实际driver接入共享编排；三个入口均调用该实例。`src/lib/refreshGate.ts:1426`和 `src/lib/refreshGate.ts:1442`分别在登记前、保护await后复核，不再只是测试调用门禁方法。
- **Q91未见增量回退。** 对照 `spec.md:95`“不自动续做……或重跑命令”，pending仍阻止最终提交，核对按目标代际清账；失败保留原请求并取消自动授权，回到可见询问。

边界：本轴只读，未运行反例、测试或GUI。提供的Node180、Rust268及前端检查结果不替代真实桌面原生退出、焦点/弹窗、Release、CI及长测验收；迁移后的测试也不能声称识别了已移除的匿名原生事件。
