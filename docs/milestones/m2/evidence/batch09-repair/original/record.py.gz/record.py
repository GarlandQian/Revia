import hashlib, json, os, subprocess, sys, time
from pathlib import Path
log = Path(__file__).resolve().parent
cwd = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
files = Path('/private/tmp/revia-b08-1yRxyJ/tested-source-list.txt').read_text().splitlines()
files = sorted(set(files + ['src-tauri/build.rs', 'src-tauri/capabilities/default.json']))
(log / 'tested-source-list.txt').write_text('\n'.join(files) + '\n')
def snapshot(name):
    (log / name).write_text(''.join(f'{hashlib.sha256((cwd / f).read_bytes()).hexdigest()}  {f}\n' for f in files))
commands = json.loads(sys.argv[1])
base_env = {key: os.environ[key] for key in ['PATH', 'HOME'] if key in os.environ}
env = {**base_env, 'CI': '1', 'NO_COLOR': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_SYSTEM': '/dev/null', 'GIT_TERMINAL_PROMPT': '0'}
(log / 'base-sha.txt').write_bytes(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=cwd))
snapshot('tested-source-sha256-before.txt')
index=[]
for i, argv in enumerate(commands):
    stem=f'{i:02d}-{Path(argv[0]).name}-{Path(argv[1]).name}'
    start=time.time()
    with (log / f'{stem}.out').open('wb') as out, (log / f'{stem}.err').open('wb') as err:
        result=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=err)
    end=time.time()
    (log/f'{stem}.exit').write_text(f'{result.returncode}\n')
    index.append({'stem':stem,'argv':argv,'cwd':str(cwd),'env':env,'started_at':start,'ended_at':end,'exit':result.returncode})
    (log / 'invocations.json').write_text(json.dumps(index,indent=2)+'\n')
    print(f'{stem}: exit={result.returncode}, seconds={end-start:.2f}',flush=True)
snapshot('tested-source-sha256-after.txt')
print('source hashes unchanged:', (log/'tested-source-sha256-before.txt').read_bytes()==(log/'tested-source-sha256-after.txt').read_bytes(),flush=True)
sys.exit(int(any(item['exit'] for item in index)))
