from pathlib import Path
import gzip,hashlib,json
src=Path('/private/tmp/revia-b09-Ztcljf')
root=Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia/docs/milestones/m2/evidence/batch09-repair')
(root/'original').mkdir(parents=True,exist_ok=False)
items=[]
for f in sorted(src.iterdir()):
    if not f.is_file(): continue
    raw=f.read_bytes()
    encoded=gzip.compress(raw,mtime=0)
    dest=root/'original'/(f.name+'.gz')
    dest.write_bytes(encoded)
    assert gzip.decompress(dest.read_bytes())==raw
    items.append({'source':str(f),'stored':str(dest.relative_to(root)),'gzip':True,'sourceBytes':len(raw),'storedBytes':len(encoded),'sourceSha256':hashlib.sha256(raw).hexdigest(),'storedSha256':hashlib.sha256(encoded).hexdigest()})
(root/'manifest.json').write_text(json.dumps({'sourceCommit':'7cdab510e8ab360ede61ef3c00c326ca71304bbc','reviewBase':'64aa4ecfee729cfb185bd3c7a85288b60a54bda5','boundary':'81 source hashes match before/after/normalized/commit/disk. Node180, Rust268 passed plus 1 existing fixture-preparation ignored; frontend checks pass. Initial diff-check failed only on generated binding whitespace; repository normalizer restored 20 files and diff-check rerun passed. Standards0/Spec0 independent static findings. No new Release/desktop/CI/soak/merge.','files':items},ensure_ascii=False,indent=2)+'\n')
print('Archived and verified',len(items),'files')
