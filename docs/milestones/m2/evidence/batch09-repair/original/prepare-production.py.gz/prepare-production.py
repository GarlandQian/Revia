from pathlib import Path
import difflib
root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
changes = {}
def load(name):
    return changes.get(name, (root / name).read_text())
def put(name, text):
    changes[name] = text
p = 'src/lib/refreshGate.ts'
s = load(p)
start = s.index('// ---------------- 关闭/退出的**共享生产驱动**')
s = s[:start] + Path('/private/tmp/revia-b09-Ztcljf/close-driver.ts').read_text()
start = s.index('  /**\n   * 原生动作**已投递但裁决未定**')
end = s.index('  /**\n   * 执行失败：', start)
s = s[:start] + s[end:]
start = s.index('  /**\n   * 原生裁决已放行')
end = s.index('  /** 是否已有执行中的原生动作。 */', start)
s = s[:start] + s[end:]
s = s.replace('   * 原生动作**已完成**（确认窗口销毁/进程退出）：清掉授权与原请求。', '   * 最终原生动作已接受：清掉授权与原请求；驱动仍保持关闭终态，不开放写入。')
s = s.replace(' * - `reconcile()` 会消费授权：满足条件就返回 `proceed`，否则返回 `none`/`ask`；', ' * - `reconcile()` 不消费授权：满足条件返回 `proceed`，最终原生动作接受后才清账；')
s = s.replace(' * - 每次 `request()` 与 `resolveAsk("stay")` 都推进 `requestGeneration`，', ' * - 每次新请求与 `resolveAsk("stay")` 都推进 `requestGeneration`，')
s = s.replace('export interface WriteGuardDeps {\n', 'export interface WriteGuardDeps {\n  /** 必填的生产关闭门禁；不能由调用者忘记在 guardsReady 中拼接。 */\n  closeDriver: Pick<CloseDriver, "canStartWrite">;\n  closeBlockedReason: string;\n')
s = s.replace('    if (!this.deps.guardsReady()) {\n      return { ok: false, reason:', '    if (!this.deps.closeDriver.canStartWrite()) {\n      return { ok: false, reason: this.deps.closeBlockedReason };\n    }\n    if (!this.deps.guardsReady()) {\n      return { ok: false, reason:', 1)
s = s.replace('    // await 期间监听可能被卸载/重装/失败：必须复核，否则会带着未受保护状态写 Git。\n    if (!this.deps.guardsReady()) {', '    // await 之后同时复核关闭门禁与监听，拒绝时撤回本次登记。\n    if (!this.deps.closeDriver.canStartWrite() || !this.deps.guardsReady()) {')
s = s.replace('      return { ok: false, reason: this.deps.guardBlockedReason() ?? "" };\n    }\n    return { ok: true };', '      return {\n        ok: false,\n        reason: !this.deps.closeDriver.canStartWrite()\n          ? this.deps.closeBlockedReason : this.deps.guardBlockedReason() ?? "",\n      };\n    }\n    return { ok: true };', 1)
put(p, s)
p = 'src/App.tsx'; s = load(p)
s = s.replace('        const stop = await getCurrentWindow().onCloseRequested(async (event) => {\n', '        const stop = await getCurrentWindow().onCloseRequested((event) => {\n          // 只接收用户意图；绝不把匿名事件当作程序化关闭的回执。\n          event.preventDefault();\n')
s = s.replace('          if (!driver) {\n            // 驱动还没就绪：保守拦住，避免未受保护的销毁。\n            event.preventDefault();\n            return;\n          }\n          // 允许/阻止与所有权判定**全部**在共享驱动里；App 只应用结论\n          // （ST-B08-08-1：Stay 后的旧程序化关闭必须真的被阻止）。\n          const decision = driver.handleNativeCloseRequest();\n          if (!decision.allow) event.preventDefault();\n          if (!disposed) applyEffectRef.current?.(decision.effect);', '          if (!driver || disposed) return;\n          applyEffectRef.current?.(driver.handleNativeCloseRequest());')
s = s.replace('      // Tauri `close()` 只投递 CloseRequested，不确认销毁 → "delivered"。\n      performNative: async () => {\n        await getCurrentWindow().close();\n        return "delivered";\n      },', '      closeWindow: () => getCurrentWindow().destroy(),\n      exitApp: () => ipc.requestExit(),')
s = s.replace('    writeOrchestratorRef.current = new WriteGuardOrchestrator({\n', '    writeOrchestratorRef.current = new WriteGuardOrchestrator({\n      closeDriver,\n      closeBlockedReason: messages.close.closing,\n')
s = s.replace('   * 驱动在 executing/awaitingVerdict 阶段直接返回，不会同步重入。', '   * 驱动不会重复认领已有执行；最终 closing 阶段不会再开启写入或请求。')
put(p,s)
p='src/lib/i18n/zh-CN.ts'; s=load(p)
s=s.replace('    guardNotInstalled: "关闭/退出保护监听尚未就绪",', '    guardNotInstalled: "关闭/退出保护监听尚未就绪",\n    closing: "应用正在关闭或退出，不能开始新的写操作",')
put(p,s)
p='src/lib/ipc.ts'; s=load(p)
s=s.replace('  setExitBlocked: (request: { blocked: boolean; seq: number }) =>\n    invoke<boolean>("set_exit_blocked", request),', '  setExitBlocked: (request: { blocked: boolean; seq: number }) =>\n    invoke<boolean>("set_exit_blocked", request),\n  requestExit: () => invoke<void>("request_exit"),')
put(p,s)
p='src-tauri/src/lib.rs';s=load(p).replace('            commands::set_exit_blocked,','            commands::set_exit_blocked,\n            commands::request_exit,');put(p,s)
p='src-tauri/src/commands.rs';s=load(p)
marker='    /// 已接受的最高序号（诊断与测试用）。'
pos=s.index(marker)
s=s[:pos]+'''    /// 前端已锁住新写入后，最终复核退出保护再投递真正的应用退出。
    fn request_exit(&self, exit: impl FnOnce()) -> Result<()> {
        let blocked = self.state.lock()
            .map_err(|_| AppError::internal("退出保护锁失败"))?.1;
        if blocked {
            return Err(AppError::rejected("仍有写操作或结果待核对，不能退出"));
        }
        exit();
        Ok(())
    }

'''+s[pos:]
marker='#[cfg(test)]\nmod exit_guard_tests'
pos=s.index(marker)
s=s[:pos]+'''/// 仅执行已通过前端最终门禁的退出；不以关闭窗口替代原退出请求。
#[tauri::command]
pub fn request_exit(app: tauri::AppHandle, state: State<'_, AppState>) -> Result<()> {
    state.exit_guard.request_exit(|| app.exit(0))
}

'''+s[pos:]
pos=s.index('    /// 新 true 建立后，旧 false')
s=s[:pos]+'''    #[test]
    fn explicit_exit_dispatches_only_after_guard_release() {
        let guard = ExitGuard::default();
        let calls = std::cell::Cell::new(0);
        assert!(guard.apply(1, true));
        let result = guard.request_exit(|| calls.set(calls.get() + 1));
        assert_eq!(result.unwrap_err().kind, crate::error::ErrorKind::Rejected);
        assert_eq!(calls.get(), 0, "保护未释放时不投递退出");
        assert!(guard.apply(2, false));
        guard.request_exit(|| calls.set(calls.get() + 1)).unwrap();
        assert_eq!(calls.get(), 1, "只投递实际应用退出，不销毁窗口冒充");
    }

'''+s[pos:]
put(p,s)
patch='*** Begin Patch\n'
for name, after in changes.items():
    before=(root/name).read_text()
    diff=list(difflib.unified_diff(before.splitlines(True),after.splitlines(True),n=3))
    assert diff, name
    patch+='*** Update File: '+str(root/name)+'\n'+''.join(diff[2:])
patch+='*** End Patch\n'
Path('/private/tmp/revia-b09-Ztcljf/production.patch').write_text(patch)
print('Prepared patch for', ', '.join(changes))
