// ---------------- 关闭/退出的共享生产驱动（任务 08）----------------

export type CloseDriverPhase = "idle" | "asking" | "waiting" | "executing" | "closing";

export type CloseDriverEffect =
  | { kind: "none" }
  | { kind: "ask"; intent: CloseIntent; writing: string[]; pending: string[] }
  | { kind: "settled" };

export interface CloseDriverDeps {
  coordinator: CloseCoordinator;
  /** 最后可取消的异步准备；这里只解除退出保护，不关闭窗口。 */
  releaseExitGuard: () => Promise<void>;
  /** 不再投递匿名 CloseRequested；仅在最终同步检查通过后销毁窗口。 */
  closeWindow: () => Promise<void>;
  /** 原退出请求走真正的应用退出，而不是用销毁窗口冒充。 */
  exitApp: () => Promise<void>;
  onError: (error: unknown) => void;
  onAsk: (intent: CloseIntent, writing: string[], pending: string[]) => void;
  onSettled: () => void;
}

interface CloseAttempt {
  intent: CloseIntent;
  generation: number;
  claimId: number;
}

/**
 * App 与回归共用的关闭驱动。原生关闭事件只表示用户意图，不充当程序化投递的回执。
 * 每次异步执行持有独立 attempt，所有回包先核对象身份；Stay 可撤销准备阶段，
 * 最终提交则同步锁住所有写入口并隐藏询问，直到销毁/退出完成也不重新开放写入。
 */
export class CloseDriver {
  private readonly deps: CloseDriverDeps;
  private phase: CloseDriverPhase = "idle";
  private attempt: CloseAttempt | null = null;

  constructor(deps: CloseDriverDeps) {
    this.deps = deps;
  }

  currentPhase(): CloseDriverPhase {
    return this.phase;
  }

  canStartWrite(): boolean {
    return this.phase !== "closing";
  }

  handleRequest(intent: CloseIntent): CloseDriverEffect {
    if (this.phase === "closing") return { kind: "none" };
    const coordinator = this.deps.coordinator;
    coordinator.request(intent);
    return this.drive();
  }

  handleChoice(choice: CloseChoice): CloseDriverEffect {
    if (this.phase === "closing") return { kind: "none" };
    const coordinator = this.deps.coordinator;
    coordinator.resolveAsk(choice);
    if (choice === "stay") {
      if (this.attempt) coordinator.abandonExecution(this.attempt.claimId);
      this.attempt = null;
      this.phase = "idle";
      this.deps.onSettled();
      return { kind: "settled" };
    }
    return this.drive();
  }

  handlePendingContinue(): CloseDriverEffect {
    if (this.phase === "closing") return { kind: "none" };
    this.deps.coordinator.confirmPendingContinue();
    return this.drive();
  }

  notifyStateChanged(): CloseDriverEffect {
    return this.drive();
  }

  /** App 对每个 CloseRequested 都 preventDefault，再把用户意图交给此入口。 */
  handleNativeCloseRequest(): CloseDriverEffect {
    return this.handleRequest("close");
  }

  private drive(): CloseDriverEffect {
    if (this.phase === "closing") return { kind: "none" };
    const coordinator = this.deps.coordinator;
    const decision = coordinator.reconcile();
    if (decision.kind === "ask") {
      // 准备仍在途时也可展示新出现的写入/待核对，但不能丢掉执行所有权。
      if (this.attempt === null) this.phase = "asking";
      this.deps.onAsk(decision.intent, decision.writing, decision.pending);
      return { kind: "ask", intent: decision.intent, writing: decision.writing, pending: decision.pending };
    }
    if (this.attempt !== null) return { kind: "none" };
    if (decision.kind === "none") {
      this.phase = "idle";
      this.deps.onSettled();
      return { kind: "settled" };
    }
    const attempt = coordinator.claimExecution();
    if (attempt === null) {
      this.phase = "waiting";
      return { kind: "none" };
    }
    this.attempt = attempt;
    this.phase = "executing";
    void this.execute(attempt);
    return { kind: "none" };
  }

  private async execute(attempt: CloseAttempt): Promise<void> {
    const coordinator = this.deps.coordinator;
    try {
      if (attempt.intent === "exit") await this.deps.releaseExitGuard();
      if (this.attempt !== attempt) return;
      if (!coordinator.isExecutionValid(attempt.generation)) {
        coordinator.abandonExecution(attempt.claimId);
        this.attempt = null;
        this.phase = "idle";
        this.drive();
        return;
      }
      // 从最终复核到锁写、隐藏询问、发出不可撤销的原生动作之间没有 await。
      this.phase = "closing";
      this.deps.onSettled();
      if (attempt.intent === "exit") await this.deps.exitApp();
      else await this.deps.closeWindow();
      if (this.attempt !== attempt) return;
      coordinator.completeExecution(attempt.claimId);
      this.attempt = null;
      // IPC 回包不等于窗口已经销毁；保持 closing，迟到的事件/选择不能重新开放写入。
    } catch (error) {
      if (this.attempt !== attempt) return;
      coordinator.failExecution(attempt.claimId);
      this.attempt = null;
      this.phase = "idle";
      this.deps.onError(error);
      this.drive();
    }
  }
}
