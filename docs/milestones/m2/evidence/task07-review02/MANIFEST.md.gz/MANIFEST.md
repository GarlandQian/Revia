# 任务 07 首轮复核返修检查清单

基线：0dd652505da4b9aa54773ba9e522e27bcb673177
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| cargo test（完整既有套件） | 0 | cargo-test.out / cargo-test.err / cargo-test.exit |

Rust 合计 245 项：lib 99、discard_recovery 71（1 ignored 桌面夹具）、file_staging 20、
hunk_staging 24、refresh_isolation 15、review_marks 13（新增 5 项）、session_flow 3。

## 失败历史

本轮实现过程中 review_marks 新用例有一次编译错误（other_identity 被 move 后仍借用），
修正为 clone 后通过；无测试失败运行。完整套件首次即通过，t13 未复现失败。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
桌面行为（勾选框观感、⌥⌘R 实际按键、折叠展开、全部已审阅提示）未验证。
commit=84a17a8e76440686b48d6c9c6d1c72a7dbb4ee37
