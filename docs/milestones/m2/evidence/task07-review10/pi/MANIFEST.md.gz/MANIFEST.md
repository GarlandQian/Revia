# 任务 07 第九轮限定返修检查清单

基线：90bcc1955e5ec7e804eaf92055476a2ff470929e
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out / refresh-gate.err / refresh-gate.exit（tests 41 / pass 41 / fail 0） |
| cargo test --test review_marks | 0 | review_marks.out / review_marks.err / review_marks.exit（24 passed / 0 failed） |

本轮改了 Rust 核心（review.rs / session.rs）与共享类型（ReviewMarks 增加 seq 与 marks），
所以按影响范围跑了受影响真实 Git 套件与前端检查；未跑其它无关 Rust 套件。

## 敏感性对照（sensitivity/）

按汇总行计数。

| 回退的修复 | exit | tests | pass | fail | 唯一失败用例 |
| --- | --- | --- | --- | --- | --- |
| A-arrival-order | exit=1 | 41 | 40 | 1 | 逆序回执：后执行成功的取消不会被先执行但迟到的勾选回执覆盖（ST07-R9-1） |
| B-seq-not-advanced | exit=101 | — | 22 | 2 | later_success_overrides_earlier_record_by_real_seq；review_seq_advances_with_real_writes |
| C-wrong-bound-version | exit=101 | — | 23 | 1 | review_marks_report_their_own_bound_versions |

说明：
- A：前端改回「按回执到达次序覆盖」（忽略后端 seq）→ 逆序回执用例失败。
- B：后端序号不递增（恒 0）→ 真实 Git 下 `review_seq_advances_with_real_writes` 与
  `later_success_overrides_earlier_record_by_real_seq` 失败。
- C：`marks` 返回占位版本而非实际绑定版本 → `review_marks_report_their_own_bound_versions` 失败。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=04a05cfc6e587464c6a2ea3d3dd5987a6bcb74bb
