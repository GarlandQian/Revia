# 任务 07 第七轮限定返修检查清单

基线：3c8a0b87288900d444383830d8553cb110f6f141
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out / refresh-gate.err / refresh-gate.exit（33 项通过） |

Rust 源码本轮未改动，按交接要求未重跑。

## 敏感性对照（sensitivity/）

每条修复单独回退后运行同一套 Node 测试，确认对应用例真的失败；
每次运行后立即恢复原实现，最终源码 SHA 与检查前一致。

| 回退的修复 | 退出码 | 失败用例数 |
| --- | --- | --- |
| readThroughReview 改成先读后取分界（分界取晚） | 1 | 7 |
| 记账挪到展示门禁之后 | 1 | 3 |
| 未跟踪元数据整条替换 | 1 | 3 |
| 重开仓库直接发布 rawSnapshot | 1 | 3 |
| 只登记本次目标、不按完整成功集合记账 | 1 | 3 |

原始 stdout/stderr 见 sensitivity/2-*.out 与 *.exit；
其中 `sens1-write-baseline-late` 与 `sens4-reopen-bypass` 是第一版测试（只覆盖 helper），
当时**没有**失败，正是这次把测试改成走共享生产入口的原因，原件保留在 sensitivity/ 下。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
Windows 三处 external_path 修复本轮未改动，仍需新 CI 验证。
commit=a96d0e000f67c7f3dca4e57bd0f75a2402245fdc
