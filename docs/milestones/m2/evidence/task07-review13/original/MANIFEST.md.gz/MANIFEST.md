# 任务 07 第十二轮限定返修检查清单

基线：c195f6ae8e4e05f4a3a61ebe812814799afa8e5a

## 实现阶段与最终检查阶段分开

- 实现阶段先改 Rust（RowSlice.reviewSeq）、共享层（mergeEntry 双水位）、App（导航消费合成真值），
  中间多轮跑 Node 调整用例，不作为证据。
- 最终检查阶段：取 `source-sha256-before-check.txt`，跑完全部检查后取
  `source-sha256-after-check.txt`，两者**逐行一致**（已 diff 验证）。

## 最终命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm bindings | 0 | bindings2.out / bindings2.err / bindings2.exit |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out（tests 65 / pass 65 / fail 0） |
| cargo test --test review_marks | 0 | review_marks.out（30 passed） |
| cargo test --lib | 0 | cargo-lib.out（100 passed） |
| git diff --check | 0 | git-diff-check2.out / git-diff-check2.exit |

## 敏感性对照（sensitivity/）

| 回退的修复 | exit | tests | pass | fail | 失败用例 |
| --- | --- | --- | --- | --- | --- |
| 2-B-current-wins | exit=1 | 65 | 64 | 1 | getRows 真实读取水位：回执尚未到达时也必须以后端读取为准（ST07-R12-2 无 override 变体） |
| A-nav-forces-target | exit=1 | 64 | 63 | 1 | 导航消费合成真值：目标被更晚取消时不能补 true，也不能误报全部已审（SP07-R12-1） |
| B-current-wins | exit=0 | 64 | 64 | 0 | （无） |
| C-ignore-loaded-seq | exit=1 | 64 | 62 | 2 | getRows 水位：失效已超越的旧成功不能在补元数据时复活（ST07-R11-3）; getRows 真实读取水位：原 v1→v2→v1 旧成功仍被水位挡住 |
| R1-row-slice-no-seq | exit=101 | — | 28 | 2 | row_slice_reports_the_review_seq_it_read; row_slice_review_seq_tracks_invalidation |

说明：
- `A-nav-forces-target`：导航把目标强行补成已审 → SP07-R12-1 用例失败。
- `B-current-wins`（第一轮）：mergeEntry 无条件优先 current → **未触发**（当时用例里
  override 恰好纠正了结果）。原件保留。
- `2-B-current-wins`（补「回执尚未到达」变体后）：同一回退 → 真实失败。
- `C-ignore-loaded-seq`：忽略后端读取水位 → 两条水位用例失败。
- `R1-row-slice-no-seq`：RowSlice 不报真实读取水位（恒 0）→ 两条 Rust 用例失败。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=1d489fe3ede07e1c0a64d70971a5fc9cb3e75225
