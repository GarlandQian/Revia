import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from evidence import ROOT, ENV, snapshot

source = Path('/Volumes/T7 Shield/project/Revia-m2-ui')
build = Path('/private/tmp/revia-m2-ui-integrated-qnvblzpc/build')
binary_info = json.loads((build / 'binary.json').read_text())
binary = Path(binary_info['path'])
expected_commit = '5f632d661ce5dc37b237c27f60205c8d41fcf86c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source).decode().strip() == expected_commit
assert hashlib.sha256(binary.read_bytes()).hexdigest() == binary_info['sha256']
name = sys.argv[1]
run = ROOT / name
run.mkdir(exist_ok=False)
snapshot(name + '-before')
with (run / 'stdout').open('wb') as stdout, (run / 'stderr').open('wb') as stderr:
    started = time.time()
    process = subprocess.Popen([str(binary)], cwd=source, env=ENV, stdout=stdout, stderr=stderr)
    (run / 'launch.json').write_text(json.dumps(dict(
        pid=process.pid, startedAt=started, argv=[str(binary)], cwd=str(source),
        sourceCommit=expected_commit, binarySha256=binary_info['sha256'],
        environment=ENV, measurementMode=False,
    ), indent=2) + '\n')
    print('PID', process.pid, flush=True)
    code = process.wait()
snapshot(name + '-after')
sources = json.loads((build / 'source-before.json').read_text())
(run / 'exit.json').write_text(json.dumps(dict(
    exitCode=code, endedAt=time.time(),
    binaryUnchanged=hashlib.sha256(binary.read_bytes()).hexdigest() == binary_info['sha256'],
    sourceUnchanged=all(hashlib.sha256((source / p).read_bytes()).hexdigest() == sha for p, sha in sources.items()),
), indent=2) + '\n')
print('EXIT', code, flush=True)
