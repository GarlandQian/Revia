# 任务 05 Windows CI 返修检查清单

基线：1056557c338137de6a61d81ca48212dd57d40d75
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）
改动前 diff：pre-change.diff

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| cargo test（完整既有套件，因改了共享 platform/recovery） | 0 | cargo-test.out / cargo-test.err / cargo-test.exit |

Rust 合计 240 项：lib 99、discard_recovery 71（1 ignored 桌面夹具）、file_staging 20、
hunk_staging 24、refresh_isolation 15、review_marks 8、session_flow 3。

前端本轮未改（只改 Rust 平台边界与测试），按交接要求未重复 tsc/lint/build。

## 平台说明

本轮在 macOS 上运行，只能证明 macOS 未回归。Windows 五项是否真的修好，
需要规划方推送后由真实 Windows CI 验证——本地通过不等于 Windows 通过。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=05513aae522c596a86dbac55dc540f9a265bf016
