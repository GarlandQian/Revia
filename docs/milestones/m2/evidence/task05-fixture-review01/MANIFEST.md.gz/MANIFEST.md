# 任务 05 桌面验收数据准备（test-only 入口）

基线：de8979655f44ceb7531d64e13b6a12a97f7c0417
检查前 src-tauri/tests/discard_recovery.rs SHA-256：7c5ef012d1d572da1e01c8cb50407797b38215b365c0edc3b281bcbad7f4f132  src-tauri/tests/discard_recovery.rs

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| cargo build --tests（最小必要编译） | 0 | 见会话输出（仅有既有 warning） |
| cargo test --test discard_recovery -- --ignored --exact --nocapture prepare_task05_desktop_fixture | 0 | fixture.out / fixture.err / fixture.exit |

解析出的夹具清单：fixture.json（从 fixture.out 的 REVIA_TASK05_DESKTOP_FIXTURE JSON 解析）

## 保留的 fixture

- fixtureRoot: /private/tmp/revia-task05-desktop-QsnQlq
- repositoryPath: /private/tmp/revia-task05-desktop-QsnQlq/repo
- reviaDataDirectory: /private/tmp/revia-task05-desktop-QsnQlq/revia-data
- worktreeId: f6ae088e27b40a84

## 未执行

产品/Rust 全套测试、前端检查、Release、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=56a142500f72a3826b95ed10d7b8711dc650f70b
