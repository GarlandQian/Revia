import datetime
import hashlib
import json
import pathlib
import subprocess
import tempfile

w = pathlib.Path('/Users/garland/.codex/worktrees/revia-m2/Revia')
reviewed = '804d88dbd344b13992e773c34f3403775fe5653c'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=w)
subprocess.run(['git', 'diff', '--quiet', reviewed, '--', 'src', 'src-tauri/src', 'src-tauri/Cargo.toml', 'src-tauri/Cargo.lock', 'src-tauri/tauri.conf.json', 'src-tauri/icons'], cwd=w, check=True)
assert not [line for line in subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True).splitlines() if line.strip().endswith('/revia')]
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip()
out = pathlib.Path(tempfile.mkdtemp(prefix='revia-task05-release02-', dir='/private/tmp'))
path_file = pathlib.Path('/private/tmp/revia-task05-release02-current')
path_file.write_text(str(out) + '\n')
meta = {'source': source, 'productReviewedAt': reviewed, 'productSourceMatchesReviewed': True, 'command': ['pnpm', 'tauri', 'build', '--bundles', 'app'], 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'logDirectory': str(out)}
(out / 'source.json').write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta, indent=2), flush=True)
with (out / 'build.stdout').open('x') as stdout, (out / 'build.stderr').open('x') as stderr:
    result = subprocess.run(meta['command'], cwd=w, stdout=stdout, stderr=stderr)
(out / 'build.exit').write_text(str(result.returncode) + '\n')
if result.returncode:
    raise SystemExit(result.returncode)
bundle = w / 'src-tauri/target/release/bundle/macos/Revia.app'
binary = bundle / 'Contents/MacOS/revia'
meta.update(completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), bundle=str(bundle), binary=str(binary), binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest(), buildExit=0)
(out / 'release.json').write_text(json.dumps(meta, indent=2) + '\n')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=w)
print(json.dumps(meta, indent=2), flush=True)
