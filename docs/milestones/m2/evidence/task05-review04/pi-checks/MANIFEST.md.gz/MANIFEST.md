# 任务 05 第三轮返修检查清单

基线：660b7521cfe3d25d4c316fe8e3f0f0b466e3401a（返修前，见 base-sha.txt）
改动前完整 diff：pre-change.diff
检查前源码 SHA-256：source-sha256-before-check.txt（本次检查实际所测源码）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出文件 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| /opt/homebrew/bin/cargo test --manifest-path src-tauri/Cargo.toml | 0 | cargo-test.out / cargo-test.err / cargo-test.exit |
| node tools/test-ipc-diagnostics.mjs | 0 | test-ipc-diagnostics.mjs.out/.err |
| node tools/test-refresh-gate.mjs | 0 | test-refresh-gate.mjs.out/.err |
| node tools/test-row-window-store.mjs | 0 | test-row-window-store.mjs.out/.err |
| node tools/test-visible-highlight-lines.mjs | 0 | test-visible-highlight-lines.mjs.out/.err |
| python3 -m unittest tools.test_bench_long_running | 0 | python-tests.out/.err/.exit |

Rust 测试合计 223 项：lib 93、discard_recovery 68、file_staging 20、hunk_staging 24、refresh_isolation 15、session_flow 3。

## 失败历史（保留）

- history/fail-*.log：直接保存场景在**加入一致性校验之前**命中「指纹不对应任何真实内容」，证明该场景确实能产生内部不一致的 Git diff。
- history/no-guard-*.log：临时移除「读取前后工作区 stat 一致」校验后，t13_direct_save 在 40 次运行中失败 4 次（已保存 4 份原始输出）；加回校验后 15 次运行 0 失败。

## 未执行（按交接要求）

Release 构建、GUI/open、D06、双平台 CI、30 分钟长测、推送/合并/发布。
commit=73791d61263e6a116da91ef032974f2b599c705d
