import assert from "node:assert/strict";
import { ReviewOverlay, publishReviewSuccess, mergePublishedReview } from "file:///Users/garland/.codex/worktrees/revia-m2/Revia/src/lib/refreshGate.ts";
function run(count, newerA) {
  const overlay = new ReviewOverlay();
  const paths = Array.from({length:count},(_,i)=>`file-${String(i).padStart(4,"0")}.txt`);
  let current = {worktreeId:"fixture-wt",revision:9,entries:paths.map(path=>({path,reviewed:false,headVersion:`h:${path}`,worktreeVersion:`w:${path}`})),review:{paths,reviewed:[],total:count,reviewedCount:0,seq:0}};
  const marks=(a)=>paths.map((path,i)=>({path,reviewed:i===0?a:i===1,head:`h:${path}`,worktree:`w:${path}`}));
  const context={worktreeMatches:true,activationMatches:true,revisionMatches:true,epochMatches:true};
  const newer=publishReviewSuccess({overlay,worktreeId:current.worktreeId,marks:marks(newerA),reviewed:marks(newerA).filter(m=>m.reviewed).map(m=>m.path),seq:2,snapshot:current,context});
  current=mergePublishedReview(current,newer.view,2);
  const before=current.entries[0].reviewed;
  const retainedBefore=overlay.get(current.worktreeId,paths[0])??null;
  const older=publishReviewSuccess({overlay,worktreeId:current.worktreeId,marks:marks(!newerA),reviewed:marks(!newerA).filter(m=>m.reviewed).map(m=>m.path),seq:1,snapshot:current,context:{...context,epochMatches:false}});
  current=mergePublishedReview(current,older.view,1);
  return {count,newerA,before,after:current.entries[0].reviewed,retainedBefore,retainedAfter:overlay.get(current.worktreeId,paths[0])??null};
}
const results=[run(1024,true),run(1025,true),run(1024,false),run(1025,false)];
console.log(JSON.stringify(results,null,2));
for(const result of results) assert.equal(result.after,result.newerA,`default overlay ${result.count} entries must preserve seq2 truth (${result.newerA}) after seq1 receipt`);
