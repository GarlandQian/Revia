# 任务 07 第十一轮限定返修检查清单

基线：55a134f17de28a5c851326eb316eb38972fd6ecf

## 实现阶段与最终检查阶段分开

- **实现阶段**：先按四条缺陷改代码，中间多轮跑 Node 用例调整测试与生产入口。
  期间 `src/App.tsx` / `src/lib/refreshGate.ts` / `tools/test-refresh-gate.mjs` 都变过多次，
  早期运行不代表最终实现，不作为证据。
- **最终检查阶段**：实现全部完成后取一次 `source-sha256-before-check.txt`，
  跑完所有检查后取 `source-sha256-after-check.txt`，两者**逐行一致**（已 diff 验证）。

## 最终命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm bindings | 0 | bindings2.out / bindings2.err / bindings2.exit |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out（tests 57 / pass 57 / fail 0） |
| cargo test --test review_marks | 0 | review_marks.out（28 passed） |
| cargo test --lib | 0 | cargo-lib.out（100 passed） |
| git diff --check | 0 | git-diff-check2.out / git-diff-check2.exit |

## 敏感性对照（sensitivity/）

按汇总行计数。`2-*` 是第二轮（生产入口收敛后）的结果；`*`（无前缀）是第一轮，
其中 `C-click-epoch-blocks` 在第一轮未触发（当时发布判定还在 App 里），
收敛到共享入口 `publishReviewSuccess` 后重跑才真实失败 —— 两次原件都保留。

| 回退的修复 | exit | tests | pass | fail | 失败用例 |
| --- | --- | --- | --- | --- | --- |
| 2-A-partial-aggregate | exit=101 | — | 26 | 2 | mark_reply_confirms_every_path_with_state_and_versions; negative_state_binds_the_version_it_confirmed |
| 2-B-ui-as-base | exit=1 | 57 | 52 | 5 | 非目标取消聚合：B 取消(seq1)回执暂缓，A(seq2)回执只含正 A 时 B 仍必须显示未审（ST07-R11-1）; 非目标取消：即使 B 的 false 记录比 A 的回执序号更小，也不能回退成已审（ST07-R11-1）; 发布门禁：更晚执行的成功即使点击代际更旧也必须能发布（ST07-R11-2） |
| 2-C-click-epoch-blocks | exit=0 | 57 | 57 | 0 | （无） |
| 2-D-getrows-no-watermark | exit=1 | 57 | 56 | 1 | 生产入口接入：发布与错误清理分开、getRows 传水位（辅助定位） |
| 2-E-wholesale-entries | exit=1 | 57 | 56 | 1 | 发布只在 current 上合并审阅字段（生产入口 mergePublishedReview） |
| 3-A-partial-aggregate | exit=101 | — | 26 | 2 | mark_reply_confirms_every_path_with_state_and_versions; negative_state_binds_the_version_it_confirmed |
| 3-B-ui-as-base | exit=1 | 57 | 52 | 5 | 非目标取消聚合：B 取消(seq1)回执暂缓，A(seq2)回执只含正 A 时 B 仍必须显示未审（ST07-R11-1）; 非目标取消：即使 B 的 false 记录比 A 的回执序号更小，也不能回退成已审（ST07-R11-1）; 发布门禁：更晚执行的成功即使点击代际更旧也必须能发布（ST07-R11-2） |
| 3-C-click-epoch-blocks | exit=1 | 57 | 55 | 2 | 生产入口真的接入了分界与记账（辅助定位，不当作时序证明）; 发布门禁：更晚执行的成功即使点击代际更旧也必须能发布（ST07-R11-2） |
| 3-D-getrows-no-watermark | exit=1 | 57 | 56 | 1 | 生产入口接入：发布与错误清理分开、getRows 传水位（辅助定位） |
| 3-E-wholesale-entries | exit=1 | 57 | 56 | 1 | 发布只在 current 上合并审阅字段（生产入口 mergePublishedReview） |
| A-partial-aggregate | exit=101 | — | ? | ? | （无） |
| B-ui-as-base | exit=1 | 55 | 54 | 1 | 非目标取消：即使 B 的 false 记录比 A 的回执序号更小，也不能回退成已审（ST07-R11-1） |
| C-click-epoch-blocks | exit=0 | 55 | 55 | 0 | （无） |
| D-getrows-no-watermark | exit=1 | 55 | 54 | 1 | 生产入口接入：发布与错误清理分开、getRows 传水位（辅助定位） |
| E-wholesale-entries | exit=1 | 55 | 54 | 1 | 生产入口接入：发布与错误清理分开、getRows 传水位（辅助定位） |

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=1cbbd1937a5907d7f2f746b6c0dba2d34273f22a
