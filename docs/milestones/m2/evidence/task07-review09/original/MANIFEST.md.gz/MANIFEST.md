# 任务 07 第八轮限定返修检查清单

基线：8128f7ab6c969fd3a0b51e5770f166c14d5ef1fa
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out / refresh-gate.err / refresh-gate.exit（tests 40 / pass 40 / fail 0） |

Rust 源码本轮未改动，未重跑。

## 敏感性对照（sensitivity/）

按测试汇总计数（tests/pass/fail 来自 `node:test` 汇总行），不数重复 ✖ 行。

| 回退的修复 | exit | tests | pass | fail | 唯一失败用例 |
| --- | --- | --- | --- | --- | --- |
| 2-A-order-ignored | exit=1 | 39 | 38 | 1 | 逆序回执：旧勾选回执晚于取消到达，不能把文件重新勾上（ST07-R8-1 / SP07-R8-1） |
| 2-B-current-version-fill | exit=0 | 39 | 39 | 0 | （无） |
| 3-B2-wrong-entry-version | exit=1 | 40 | 39 | 1 | 版本来源：旧全量回执不能把外部改成新版本的路径认领为已审（ST07-R8-2 / SP07-R8-2） |
| A-order-ignored | exit=1 | 39 | 38 | 1 | 逆序回执：旧勾选回执晚于取消到达，不能把文件重新勾上（ST07-R8-1 / SP07-R8-1） |
| B-current-version-fill | exit=0 | 39 | 39 | 0 | （无） |

说明：
- `A-order-ignored`：把同路径记录改回「按回执到达次序覆盖」，逆序回执用例失败。
- `B2-wrong-entry-version`：聚合记录改为错取请求快照里其它条目的版本，
  「旧全量回执不能把外部改成新版本的路径认领为已审」失败。
- 早期 `B-current-version-fill`（让 App 传入当前条目）在本轮结构下**无法触发失败**，
  因为生产记账入口 `applyReviewSuccess` 不接受当前条目参数；原件保留，
  并另加一条「契约后果」用例说明版本来源错误时的可观察后果。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=3e298800e5053ba497f65c0ac7eae4b00d7a4982
