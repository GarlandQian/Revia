import gzip
import hashlib
import json
from pathlib import Path
import subprocess

source = Path('/private/tmp/revia-task13-dark-x5e4w420')
repo = Path('/Volumes/T7 Shield/project/Revia-m2-ui')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == '0b87fa962b2e5b71b08271cbcd66f872c147ff0c'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
exit_state = json.loads((source / 'exit.json').read_text())
assert exit_state['exitCode'] == 0 and all(exit_state[key] for key in ['binaryUnchanged', 'sourceUnchanged', 'fixtureStatusAndIndexEntriesUnchanged'])
assert json.loads((source / 'appearance-restored.json').read_text())['autoSelected']
target = repo / 'docs/milestones/m2/evidence/task13-desktop02'
target.mkdir(exist_ok=False)
files = sorted(p for p in source.iterdir() if p.is_file()) + [source / 'data/settings.json']
entries = []
for path in files:
    relative = path.relative_to(source)
    data = path.read_bytes()
    compress = path.suffix != '.png'
    stored = target / 'original' / (str(relative) + ('.gz' if compress else ''))
    stored.parent.mkdir(parents=True, exist_ok=True)
    output = gzip.compress(data, mtime=0) if compress else data
    stored.write_bytes(output)
    assert (gzip.decompress(stored.read_bytes()) if compress else stored.read_bytes()) == data
    entries.append(dict(source=str(path), stored=str(stored.relative_to(target)), gzip=compress,
                        sourceBytes=len(data), storedBytes=len(output),
                        sourceSha256=hashlib.sha256(data).hexdigest(), storedSha256=hashlib.sha256(output).hexdigest()))
manifest = dict(sourceCommit='6b3ddf5d3046e5745e65c81076806bbda441b359',
                launchCommit='0b87fa962b2e5b71b08271cbcd66f872c147ff0c',
                binarySha256='b0b2a64e324cda9156a301fd73b9e823094942eb0c16b31691ca758a956efb61',
                boundary='Listed real dark desktop states only; appearance restored to Auto. No new D06, complete error-state acceptance, Windows CI, final M2 acceptance or merge.', files=entries)
(target / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(repo / 'docs/milestones/m2/task13-desktop02.md').write_bytes((source / 'task13-desktop02.md').read_bytes())
issue = repo / 'docs/milestones/m2/issues/13-ui-polish.md'
issue.write_bytes(issue.read_bytes() + (source / 'task13-comment.md').read_bytes())
print('archived', len(entries), 'files; appearance Auto restored')
