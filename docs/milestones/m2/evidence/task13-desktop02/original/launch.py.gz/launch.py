import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/private/tmp/revia-task13-dark-x5e4w420')
repo = Path('/Volumes/T7 Shield/project/Revia-m2-ui')
binary = repo / 'src-tauri/target/release/bundle/macos/Revia.app/Contents/MacOS/revia'
before = hashlib.sha256(binary.read_bytes()).hexdigest()
assert before == 'b0b2a64e324cda9156a301fd73b9e823094942eb0c16b31691ca758a956efb61'
env = {k: v for k, v in os.environ.items() if not k.startswith(('GIT_', 'REVIA_'))}
overrides = dict(HOME=str(root / 'home'), GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
                 REVIA_ACCEPTANCE='1', REVIA_ACCEPTANCE_DIR=str(root / 'data'))
env.update(overrides)
fixture = Path('/private/tmp/revia-task13-final-HW71Io/ui-fixture')
status = subprocess.check_output(['git', 'status', '--porcelain=v2', '-z'], cwd=fixture, env=env)
(root / 'fixture-before.bin').write_bytes(status)
with (root / 'stdout').open('wb') as stdout, (root / 'stderr').open('wb') as stderr:
    started = time.time()
    process = subprocess.Popen([str(binary)], cwd=repo, env=env, stdout=stdout, stderr=stderr)
    (root / 'launch.json').write_text(json.dumps(dict(pid=process.pid, startedAt=started,
        argv=[str(binary)], cwd=str(repo), sourceCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
        binarySha256=before, environmentOverrides=overrides, measurementMode=False), indent=2))
    print('PID', process.pid, flush=True)
    code = process.wait()
after = subprocess.check_output(['git', 'status', '--porcelain=v2', '-z'], cwd=fixture, env=env)
(root / 'fixture-after.bin').write_bytes(after)
source = json.loads((root / 'source-before.json').read_text())
(root / 'exit.json').write_text(json.dumps(dict(exitCode=code, endedAt=time.time(),
    binaryUnchanged=hashlib.sha256(binary.read_bytes()).hexdigest() == before,
    sourceUnchanged=all(hashlib.sha256((repo / p).read_bytes()).hexdigest() == sha for p, sha in source.items()),
    fixtureStatusAndIndexEntriesUnchanged=status == after), indent=2))
print('EXIT', code, flush=True)
