Standards：固定1cd80b6...4dec0b5，唯一提交、8文件非空；仅静态阅读，未修改或运行检查。

确定违反3项，最严重P1；Fowler判断建议0项。

1. P1 监听重装暴露在途写入：App.tsx:799清理关闭/退出监听，effect在:802依赖setAppError，而它随worktree改变（:177）。用户写入中切worktree会先卸载再异步重装；ready只挡新写，无法保护既有写。本地Tauri2.12.4 manager/window.rs:178仅有JS监听时阻止close；空档中窗口可销毁，lib.rs:146放行退出。违反technical-direction.md:52 Q90允许切换与:56 Q96保留窗口和进程。
2. P2 晚Wait按钮被隐藏：写先完成、用户未选时，refreshGate.ts:1191返回none，App.tsx:1152随即隐藏询问但保留requested，真实用户不能再触发新增onWait。违反technical-direction.md:56 Q96选择与原请求闭环。Node:2303手动授权没有覆盖按钮消失。
3. P2 保护失败仍未统一收尾：App.tsx:1118只rollback后抛错；stage/restore/save-as外层catch在:1180/:1258/:1322提前返回或抛出，不经过后续finally。保护IPC挂起期间已Wait后失败，原请求仍悬挂，可能由后续无关写触发。违反technical-direction.md:56 Q96。Node:2328额外reconcile未证明生产接线。

版本化Rust更新、初次监听失败拒绝新写、旧核对隔离、新pending重新展示及原动作展示已有静态改善。乱序Node假接收端没有真实延迟请求，不能当真实乱序证据。
