#!/bin/sh
# 本批检查的精确命令与工作目录（供复核重放）。
cd /Users/garland/.codex/worktrees/m2-close-finish/Revia
pnpm exec tsc -b
pnpm lint
pnpm build
node tools/test-refresh-gate.mjs
cargo test --manifest-path src-tauri/Cargo.toml
pnpm bindings
git diff --check
