# 任务 07 第十六轮限定返修检查清单（恢复编排闭环）

基线：6dea47352fb927af082cf9c08f0287db7a0b8fd0

## 命令 / 退出码 / 原始输出（最终实现）

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out（tests 90 / pass 90 / fail 0） |
| git diff --check | 0 | git-diff-check.out / git-diff-check.exit |

最终源码前后 SHA（source-sha256-before-check.txt / -after-check.txt）逐行一致。
本轮只改前端共享层、App、i18n 与 Node 测试；Rust 未改，未重跑 Rust 套件。

## 敏感性对照（sensitivity/）

| 回退的修复 | exit | tests | pass | fail | 失败用例 |
| --- | --- | --- | --- | --- | --- |
| A-self-wait-shape | exit=0 | 90 | 90 | 0 | （无） |
| A2-recursive-self-wait | exit=1 | 90 | 89 | 1 | 恢复 runner 不递归等待自身：再次拒收时批次仍会结束（ST07-R16-1 / SP07-R16-1） |
| B-no-budget-reset | exit=1 | 90 | 88 | 2 | 完整快照读取：不可信时明确拒收，并按原目标重新核对（ST07-R15-1 / SP07-R15-2）; 耗尽后新批次恢复：预算按批重置，不是终身熔断（ST07-R16-2 / SP07-R16-3） |
| C-silent-exhaust | exit=1 | 90 | 87 | 3 | 重读有界：不前进时停止，不产生请求风暴; 恢复 runner 不递归等待自身：再次拒收时批次仍会结束（ST07-R16-1 / SP07-R16-1） |

- `A-self-wait-shape`（第一版）：只加注释形态，**未触发**（90/90）。原件保留。
- `A2-recursive-self-wait`：让批次在「不可信」时真正 `await this.run(...)` 递归等待自身
  → 「恢复 runner 不递归等待自身」用例失败（自等待形态被检出）。
- `B-no-budget-reset`：批次结束后不重置预算（终身熔断）→ 2 项失败。
- `C-silent-exhaust`：耗尽时报告 `exhausted: false`（静默）→ 3 项失败。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
