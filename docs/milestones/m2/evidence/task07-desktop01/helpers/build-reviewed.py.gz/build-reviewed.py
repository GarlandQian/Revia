import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

w = Path('/Users/garland/.codex/worktrees/revia-m2/Revia')
reviewed = '86b26aa5aaf63ef0d4e0ff92b54dccc8e0fcee28'
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=w, text=True).strip() == 'm2'
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=w)
subprocess.run(['git', 'diff', '--quiet', reviewed, '--', '.', ':!docs', ':!AGENTS.md'], cwd=w, check=True)
active = [line for line in subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True).splitlines()
          if line.strip().endswith('/revia')]
assert not active, active
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip()
out = Path(tempfile.mkdtemp(prefix='revia-m2-0512-release-', dir='/private/tmp'))
meta = {
    'source': source, 'productReviewedAt': reviewed, 'productSourceMatchesReviewed': True,
    'command': ['pnpm', 'tauri', 'build', '--bundles', 'app'],
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'logDirectory': str(out),
}
(out / 'source.json').write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta, indent=2), flush=True)
with (out / 'build.stdout').open('x') as stdout, (out / 'build.stderr').open('x') as stderr:
    result = subprocess.run(meta['command'], cwd=w, stdout=stdout, stderr=stderr)
(out / 'build.exit').write_text(str(result.returncode) + '\n')
if result.returncode:
    raise SystemExit(result.returncode)
bundle = w / 'src-tauri/target/release/bundle/macos/Revia.app'
binary = bundle / 'Contents/MacOS/revia'
meta.update(
    completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    bundle=str(bundle), binary=str(binary),
    binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest(), buildExit=0,
)
(out / 'release.json').write_text(json.dumps(meta, indent=2) + '\n')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=w, text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=w)
print(json.dumps(meta, indent=2), flush=True)
