import base64
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys

W = pathlib.Path('/Users/garland/.codex/worktrees/revia-m2/Revia')
SOURCE = '8f95c26c33a4c2883043a0d4041b87c00c763cc6'
BINARY_SHA = 'bed7f32947ef4d897918c164b788b108a3095d95c309e7f7bd91d5ec6ac41e5f'
RELEASE_METADATA = pathlib.Path('/private/tmp/revia-m2-0512-release-gwf9wvrr/release.json')
BINARY = W / 'src-tauri/target/release/bundle/macos/Revia.app/Contents/MacOS/revia'
manifest_path = pathlib.Path(sys.argv[1]).resolve(strict=True)
assert manifest_path.name == 'fixture.json'
assert manifest_path == pathlib.Path('/private/tmp/revia-m2-0512-fixture-prep-f_sjywui/fixture.json')
manifest = json.loads(manifest_path.read_text())
root = pathlib.Path(manifest['fixtureRoot']).resolve(strict=True)
assert root == pathlib.Path('/private/tmp/revia-task05-desktop-9ixADj')
repo, data, home = (pathlib.Path(manifest[k]).resolve(strict=True) for k in ('repositoryPath', 'reviaDataDirectory', 'isolatedHome'))
assert repo == root / 'repo' and data == root / 'revia-data' and home == root / 'home'
evidence = root / 'desktop-evidence'
evidence.mkdir(exist_ok=True)
env = {k: v for k, v in os.environ.items() if not k.startswith(('GIT_', 'REVIA_')) and k not in ('ZDOTDIR', 'SSH_AUTH_SOCK')}
env.update(HOME=str(home), USERPROFILE=str(home), XDG_CONFIG_HOME=str(home), GIT_CONFIG_GLOBAL=str(home / '.gitconfig'), GIT_CONFIG_NOSYSTEM='1', GIT_TERMINAL_PROMPT='0', PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')

def git(*args):
    return subprocess.check_output(['/opt/homebrew/bin/git', '-C', str(repo), *args], env=env)

action = sys.argv[2]
if action == 'launch':
    release = json.loads(RELEASE_METADATA.read_text())
    assert release['source'] == SOURCE and release['binarySha256'] == BINARY_SHA and release['buildExit'] == 0
    assert hashlib.sha256(BINARY.read_bytes()).hexdigest() == BINARY_SHA
    source_matches = subprocess.run(['git', 'diff', '--quiet', SOURCE, '--', 'src', 'src-tauri/src', 'src-tauri/Cargo.toml', 'src-tauri/Cargo.lock', 'src-tauri/tauri.conf.json', 'src-tauri/icons'], cwd=W, check=False).returncode == 0
    assert source_matches
    active = [line for line in subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True).splitlines() if line.strip().endswith('/revia')]
    assert not active, active
    for name in ['.zshenv', '.zshrc']:
        p = home / name
        if not p.exists():
            p.write_text('export PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin\n')
    attempt = sys.argv[3]
    assert attempt.isdigit()
    out = evidence / ('run-' + attempt)
    out.mkdir()
    env.update(REVIA_ACCEPTANCE='1', REVIA_ACCEPTANCE_DIR=str(data))
    assert not any(k in env for k in ('REVIA_MEASURE_LOG','REVIA_MEASURE','REVIA_SMOKE','REVIA_SOAK_SECONDS'))
    with (out / 'stdout.log').open('x') as log:
        process = subprocess.Popen([str(BINARY)], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    meta = {'buildSource': SOURCE, 'releaseMetadata': str(RELEASE_METADATA), 'checkoutAtLaunch': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(), 'productCheckoutMatchesBuildAtLaunch': source_matches, 'fixedBinaryVerified': True, 'binary': str(BINARY), 'binarySha256': BINARY_SHA, 'pid': process.pid, 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'fixtureManifest': str(manifest_path), 'repo': str(repo), 'data': str(data), 'home': str(home), 'acceptanceEnabled': True, 'automaticMeasurement': False, 'measurementModeVariables': [], 'ordinaryMode': True}
    (out / 'launch.json').write_text(json.dumps(meta, indent=2) + '\n')
    print(json.dumps(meta, indent=2))
elif action == 'snapshot':
    label = sys.argv[3]
    assert label and all(c.isalnum() or c in '-_' for c in label)
    result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'repo': str(repo), 'gitVersion': git('--version').decode().strip(), 'head': git('rev-parse', 'HEAD').decode().strip(), 'indexListingBase64': base64.b64encode(git('ls-files', '--stage', '-z')).decode(), 'status': git('status', '--porcelain=v2').decode(), 'files': [], 'records': {}}
    for entry in manifest['worktreeFiles']:
        path = repo / entry['path']
        if path.exists():
            content = path.read_bytes()
            value = {'path': entry['path'], 'exists': True, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(), 'contentBase64': base64.b64encode(content).decode(), 'executable': bool(path.stat().st_mode & 0o111)}
        else:
            value = {'path': entry['path'], 'exists': False}
        result['files'].append(value)
    for record in sorted((data / 'recovery').glob('record-*')):
        result['records'][record.name] = {str(p.relative_to(record)): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'contentBase64': base64.b64encode(p.read_bytes()).decode()} for p in sorted(record.rglob('*')) if p.is_file()}
    out = evidence / (label + '.json')
    with out.open('x') as f:
        json.dump(result, f, indent=2)
        f.write('\n')
    print(json.dumps({'snapshot': str(out), 'files': len(result['files']), 'records': len(result['records']), 'status': result['status']}, indent=2))
else:
    raise ValueError(action)
