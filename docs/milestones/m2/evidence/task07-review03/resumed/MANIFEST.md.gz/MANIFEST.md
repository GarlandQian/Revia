# 任务 07 第二轮复核返修检查清单

基线：ed0f9b8eca4046fe934464b57e0607507794d487
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 | 说明 |
| --- | --- | --- | --- |
| pnpm exec tsc -b | 0 | 见 /private/tmp/revia-task07-r3-hCxSBf/tsc.* | 源码未变，复用未重跑 |
| pnpm lint | 0 | 见 /private/tmp/revia-task07-r3-hCxSBf/lint.* | 源码未变，复用未重跑 |
| pnpm build | 0 | build.out / build.err / build.exit | 本目录重跑（旧目录被中断、无退出码） |
| cargo test（完整既有套件） | 0 | cargo-test.out / .err / .exit | 本目录 |

Rust 合计 247 项：lib 99、discard_recovery 71（1 ignored 桌面夹具）、file_staging 20、
hunk_staging 24、refresh_isolation 15、review_marks 15（新增 2 项）、session_flow 3。

## 中断历史（保留）

/private/tmp/revia-task07-r3-hCxSBf 的 build 在 transforming 阶段中断、无 build.exit，
cargo 未产出日志。该目录原样保留，见本目录 NOTE-aborted-run.md。

## 敏感性对照

history/sensitivity.md：两处对照实际运行并使对应用例失败，但只保留终端摘要与实现副本，
没有独立 stdout/stderr 归档；不冒称完整原始结果。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
桌面行为未验证。
commit=ff2fc640d3a6fa771d1d6b8a5514a3d7471ab347
