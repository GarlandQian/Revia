# 敏感性对照（实施方运行，仅文字记录 + 实现副本）

本轮两处对照是**实际运行过**的，但只保留了终端摘要与实现副本，没有独立的 stdout/stderr 文件：

1. 子模块版本退回「读不到」实现后，`submodule_version_follows_real_git_including_packed_refs`
   失败于「必须读到真实子模块版本」。
2. `revalidate` 退回「只 stat 缓存路径」实现后，`gitdir_repointed_to_existing_directory_invalidates_identity`
   失败（reviewed_count 仍为 1，期望 0）。

对照后实现均已按原字节恢复（本目录 history/ 下保存对照前后的副本）。
该证据边界：可核「对照确实使对应用例失败」，但**不是**独立归档的原始运行输出。
