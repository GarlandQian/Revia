## Spec

缺失/部分1项，实现错误2项，范围扩张0项；最严重P2，本轮仍不通过。行号对应 `013e1fa`。

### 缺失/部分

- **P2：原生退出的立即放行分支丢失请求。** 违反 `docs/milestones/m2/spec.md:127`“执行原关闭／退出请求”。最后写结束后，解除保护的false IPC尚未落地时，Cmd-Q仍会被Rust拦截并通知前端。此时 `src/lib/refreshGate.ts:1152`在无写、无pending分支清掉请求及授权并返回proceed；但新接线 `src/App.tsx:790`只调用reconcile，得到none，不执行退出。用户此次Quit被吞掉。

### 实现错误

- **P2：执行失败形成无界自动重试。** 违反 `docs/milestones/m2/spec.md:126`提供“等待完成后关闭／退出”和“留在应用”。`src/lib/refreshGate.ts:1478`失败后立即调用真实App reconcile，旧授权仍在，`src/App.tsx:1131`重新认领并执行。释放保护IPC或原生close持续失败时，会不断发起IPC、更新错误，却没有退回可选择Stay的询问。测试reconcile仅计数，没有覆盖实际重新执行链。
- **P2：仍将提交原生关闭请求误当动作完成。** 违反 `docs/milestones/m2/spec.md:127`“执行原关闭／退出请求，不把关闭窗口擅自解释为其他请求”。`src/App.tsx:1109`使用Tauri `close()`，该调用提交可被拦截的CloseRequested，并不确认窗口已销毁；`src/lib/refreshGate.ts:1472`却在IPC返回后直接清授权。原exit提交期间B开始写、关闭事件被 `src/App.tsx:776`阻止，随后成功回包仍清掉原请求，B完成后不再退出；事件迟于回包时还可能重新登记成close。授权必须保留到实际放行，而非仅等invoke成功。

Rust生产接收端回归已静态闭合：生产与测试共用 `ExitGuard`，不再复制算法。本轴未运行检查、GUI、Release或CI；未将测试fake或实施报告视为桌面验收。
