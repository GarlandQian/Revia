# M2整批B06返修：退出事件、失败状态与原生关闭裁决

业务目标：任何worktree仍在写或结果待核对时保留窗口与进程；正常完成后执行原关闭/退出意图，用户选“留在应用”后不得被旧异步回调关闭。Revia是本地Git客户端；验证只用本次唯一临时fixture和独立应用数据，保持文件/路径/权限/暂存区完整，不触用户仓库或凭据。

只在 `/Users/garland/.codex/worktrees/m2-close-finish/Revia` 的m2分支工作。生产起点 `013e1fa631c82e99948efa4d3339e1a79103bad7`，规划方下一提交仅本轮Comments和证据。先读AGENTS、`docs/agents/local-validation.md`、任务08最新ST-B06-08-1..3 / SP-B06-08-1..3、规格Q90/91/96和`batch05-repair-validation.md`。保留B04/B05已闭合修复，不碰m2-ui或main，不改变Q107/rev3外观或产品决策。

## 三项成批修复，不逐项停等

1. **原生Quit立即放行契约**：Rust拦Quit时A仍写，但JS退出事件执行前A结束；当前request清requested/auth并返回proceed，App只reconcile得到none，吞Quit。统一请求事件与决策驱动，立即可执行的原exit也必须完整执行，不能只改测试helper。窗口close允许原生默认行为与已被Rust阻止的exit通知不应混淆。
2. **失败后停止自动重试**：release/native持续失败时，catch→真实App reconcile→claim又执行，目前无界循环。失败进入明确可见、用户可选择等待/重试或Stay的状态，保留原意图但取消自动执行授权；不得以隐藏/吞错误、自动退出或无限重试代替。沿用现有询问与错误展示，避免新增产品范围。用户下一次明确决定才可重试；原Git操作绝不重跑。
3. **投递不是完成；原生裁决才可清账**：核对锁定版本本地Tauri的close语义，它仅投递CloseRequested，不确认窗口销毁。A Quit→Wait→完成，close投递期间B开始写，关闭事件必须被B拦住并保留原exit；成功IPC不能清原请求/改成close。分别覆盖事件先于IPC回包和后于回包。执行claim必须排他，异步旧claim只可撤销/完成自身，不能清新claim；不能只按requestGeneration判有效。修排他时去掉App claim失败立即递归reconcile的同步重入。仍用最小明确的生产编排，不能禁止浏览/切worktree或绕过写保护，不能用无条件destroy掩盖原生裁决。

## 回归与生产同源

沿用已有Node与Rust体系，不增测试框架。共享驱动必须由App真实使用，测试只注入可控deferred IPC/native适配层；请求事件、Wait/Stay、reconcile、claim、错误、重新进入与原生裁决都走生产驱动。不要reconcile仅计数/native仅push后额外手拼补调用，把App漏接线掩盖成绿灯。

最少覆盖：写结束先于native-exit回调仍执行原exit；release/native持续失败只发生一次自动尝试且真实可Stay，明确再次Wait才重试；原close投递的事件前/后回包期间B开始写都保留exit，B结束后执行原动作；重复reconcile在旧claim未结束时不重复投递；旧claim晚回/失败不清新claim；已有A/B→Stay反例继续通过。监听安装/卸载、rollback、晚Wait、pending代际等已闭合路径不回退。

所有修改完成后集中跑受影响Node回归、tsc/lint/build、diff-check；Rust生产不再改则不无故重跑完整Rust，如改变跨层关闭契约则跑相应生产接收端/必要lib测试与绑定检查。失败后只重跑受影响项，保留首次原件。不要GUI/Release/D06/CI/长测/推送/合并。

## 原始证据与交付

沿用真实执行记录器（可复用上一轮record.py），日志目录mktemp唯一分配，实际路径写任务Comments，不建固定指针。逐条真实argv/cwd、显式非敏感环境覆盖、start/end/exit/stdout/stderr，不能事后补造。受测生产/测试/构建配置/锁文件逐份检查前后SHA与明确排除范围；不抓凭据和无关环境。敏感性实验如报告必须附原始改动/失败日志，否则明确仅实施方叙述；无需为报告扩大验证范围。

先完成整批相关修改，再集中检查、明确文件暂存提交m2。08到ready-for-human仅表示等待规划方；08/10/11/M2不得done。汇报提交SHA、改动、真实命令结果、唯一日志目录与未测边界，完成后停止等复核。
