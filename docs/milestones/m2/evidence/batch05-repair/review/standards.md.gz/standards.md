## Standards

固定 `1dd509ab476a9f279a23074368ec46177b566fb7...013e1fa`，唯一提交、5 文件非空；只读，未运行检查。

### 确定违反

1. **P2／吞掉正常 Quit。** `src/lib/refreshGate.ts:1152` 在无 writing/pending 时清除请求与授权并返回 proceed，但 `src/App.tsx:790` 现在只调用 reconcile，后者得到 none，不执行退出。确定交错：Rust 在 A 写入期间拦截 Quit；A 完成先于前端退出事件回调，原 Quit 因而丢失。违反 `docs/technical-direction.md:56` Q96“完成并记录结果后执行用户原请求”。
2. **P2／执行失败形成无界自动重试。** `src/lib/refreshGate.ts:1478` 的 catch 调用真实 App reconcile，却仍保留有效授权；`src/App.tsx:1128` 随即再次认领并执行。保护释放 IPC 或 native close 持续失败时，产生“失败→reconcile→执行→失败”的循环，询问保持隐藏，无法回到可控的留在应用状态。违反 `docs/technical-direction.md:56` Q96 的等待／留在应用闭环。失败应进入明确可见、由用户决定是否重试的状态，而非立即再执行。
3. **P2／将 close IPC 回包误作窗口已关闭。** `src/App.tsx:1109` 使用 `window.close()`，`src/lib/refreshGate.ts:1472` 在其返回后直接 complete，清除原请求与授权。本地 Tauri 实现仅向事件循环投递 CloseRequested，并不确认销毁。若期间 B 开始写入、真实监听拦截关闭：回包在事件前会使原 exit 被重新登记成 close；事件在回包前则保留的原请求随后被 complete 清掉。违反 `docs/technical-direction.md:56` Q96“保留在途写、执行原动作”。需以实际原生关闭裁决确认所有权，不能以投递成功清账。

### 判断与边界

Fowler 判断建议 **0 项**。真实生产 `ExitGuard` 共享实现与回归接线已静态闭合；旧 release await 后的 Stay 校验已有修复。

`tools/test-refresh-gate.mjs:2631` 的 reconcile 仅计数，native 仅记录动作，不能证明上述真实回调闭环；按 `docs/agents/local-validation.md:16` 保留此证据边界，不另计验证缺陷。

**确定违反 3 项，均为运行时 P2；最严重 P2；判断建议 0 项。**
