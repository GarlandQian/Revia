import gzip
import hashlib
import json
import pathlib

source = pathlib.Path('/private/tmp/revia-task13-final-HW71Io')
repo = pathlib.Path('/Volumes/T7 Shield/project/Revia-m2-ui')
target = repo / 'docs/milestones/m2/evidence/task13-desktop01'
target.mkdir(exist_ok=False)
files = [p for p in source.iterdir() if p.is_file() and p.name not in {
    'batch02-review08.md', 'batch02-review10.md', 'pi-close-batch.md',
}]
files += [source / f'ui-data-{theme}/settings.json' for theme in ['light', 'dark']]
entries = []
for path in sorted(files):
    relative = path.relative_to(source)
    data = path.read_bytes()
    compress = path.suffix != '.png'
    stored = target / 'original' / (str(relative) + ('.gz' if compress else ''))
    stored.parent.mkdir(parents=True, exist_ok=True)
    output = gzip.compress(data, mtime=0) if compress else data
    stored.write_bytes(output)
    assert (gzip.decompress(output) if compress else output) == data
    entries.append({
        'source': str(path), 'stored': str(stored.relative_to(target)), 'gzip': compress,
        'sourceBytes': len(data), 'storedBytes': len(output),
        'sourceSha256': hashlib.sha256(data).hexdigest(),
        'storedSha256': hashlib.sha256(output).hexdigest(),
    })
manifest = {
    'sourceCommit': (source / 'source.txt').read_text().strip(),
    'binarySha256': json.loads((source / 'binary.json').read_text())['sha256'],
    'boundary': 'Partial task13 light desktop and D06; no dark desktop, final M2, Windows CI or merge. ui-dark-main.png is a failed light screenshot attempt, not dark evidence.',
    'files': entries,
}
(target / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(repo / 'docs/milestones/m2/task13-desktop01.md').write_bytes((source / 'task13-desktop01.md').read_bytes())
print('archived', len(entries), 'files')
