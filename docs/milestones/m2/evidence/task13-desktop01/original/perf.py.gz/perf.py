import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/private/tmp/revia-task13-final-HW71Io');case=sys.argv[1]; view=sys.argv[2]; cold=case.startswith('cold');data=root/f'data-{case}-{view}';data.mkdir(exist_ok=False)
output=root/f'perf-{case}-{view}.json'; binary=pathlib.Path('/Volumes/T7 Shield/project/Revia-m2-ui/src-tauri/target/release/bundle/macos/Revia.app/Contents/MacOS/revia')
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_') and not k.startswith('REVIA_')}
env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',REVIA_MEASURE='1',REVIA_MEASURE_ONLY=view,REVIA_MEASURE_KEEP_OPEN='1',REVIA_MEASURE_REPO=str(root/'cold' if cold else root/'fixtures/diffs'),REVIA_MEASURE_PATH='cold.ts' if cold else 'src/generated.ts',REVIA_MEASURE_DATA_DIR=str(data),REVIA_MEASURE_LOG=str(output))
start=time.time();before=hashlib.sha256(binary.read_bytes()).hexdigest()
with (root/f'perf-{case}-{view}.stdout').open('wb') as stdout,(root/f'perf-{case}-{view}.stderr').open('wb') as stderr:
    p=subprocess.Popen([str(binary)],env=env,stdout=stdout,stderr=stderr)
    (root/f'perf-{case}-{view}.launch.json').write_text(json.dumps(dict(pid=p.pid,binarySha256=before,startedAt=start,environment={k:v for k,v in env.items() if k.startswith(('GIT_CONFIG','REVIA_'))}),indent=2))
    print('PID',p.pid,'output',output,flush=True)
    code=p.wait()
(root/f'perf-{case}-{view}.exit.json').write_text(json.dumps(dict(exitCode=code,endedAt=time.time(),binaryUnchanged=hashlib.sha256(binary.read_bytes()).hexdigest()==before),indent=2))
print('EXIT',code,flush=True)
