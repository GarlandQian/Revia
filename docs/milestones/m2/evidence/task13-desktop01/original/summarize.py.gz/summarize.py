import hashlib
import json
import pathlib
import subprocess

root = pathlib.Path('/private/tmp/revia-task13-final-HW71Io')
repo = pathlib.Path('/Volumes/T7 Shield/project/Revia-m2-ui')
before = json.loads((root / 'source-before.json').read_text())
after = json.loads((root / 'source-after.json').read_text())
current = {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in before}
rows = []
for case, view in [('standard', 'split'), ('standard', 'unified'), ('cold', 'split'), ('cold', 'unified')]:
    stem = f'perf-{case}-{view}'
    data = json.loads((root / f'{stem}.json').read_text())
    combo = data['combos'][0]
    probe = combo['jumpDom']
    exit_data = json.loads((root / f'{stem}.exit.json').read_text())
    rows.append({
        'case': case, 'view': view, 'ok': data['ok'], 'visibility': data['visibility'],
        'firstScreen': combo['firstScreen'], 'jump': combo['jump'],
        'jumpDomError': combo['jumpDomError'], 'sourceReady': probe['sourceReady'],
        'preparationError': probe['preparationError'],
        'outward': probe['outward'], 'return': probe['return'], 'scroll': combo['scroll'],
        'exit': exit_data,
    })
result = {
    'sourceCommit': (root / 'source.txt').read_text().strip(),
    'trackedFiles': len(before), 'sourceUnchanged': before == after == current,
    'binary': json.loads((root / 'binary.json').read_text()),
    'worktreeStatusBeforeEvidenceArchival': subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).decode(),
    'results': rows,
    'boundary': 'Original appear/warm and independent DOM probes target different jumps. Keep all original over-frame values; do not substitute. Cold first-screen load is not part of the standard 150ms gate. Screenshots were captured after measurement, not during timed jumps. No dark desktop or final M2 acceptance claimed.',
}
assert result['sourceUnchanged']
assert all(r['exit']['exitCode'] == 0 and r['exit']['binaryUnchanged'] for r in rows)
(root / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('sourceUnchanged', result['sourceUnchanged'], 'trackedFiles', len(before))
for r in rows:
    print(r['case'], r['view'], 'first', r['firstScreen']['fromListChangesMs'],
          'appear/warm', r['jump']['appearMs'], r['jump']['warmAppearMs'],
          'DOM text', r['outward']['textDomMs'], r['return']['textDomMs'],
          'firstRAF', r['outward']['firstFrame']['checkedMs'], r['return']['firstFrame']['checkedMs'],
          'color', r['return']['colorDomMs'], 'scroll max', r['scroll']['frameMaxMs'])
