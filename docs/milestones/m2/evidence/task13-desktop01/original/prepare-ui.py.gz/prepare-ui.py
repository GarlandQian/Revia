import hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/private/tmp/revia-task13-final-HW71Io'); repo=root/'ui-fixture';repo.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_AUTHOR_NAME='Revia Acceptance',GIT_AUTHOR_EMAIL='fixture@invalid',GIT_COMMITTER_NAME='Revia Acceptance',GIT_COMMITTER_EMAIL='fixture@invalid')
log=[]
def git(*args,allowed=(0,)):
    p=subprocess.run(['/usr/bin/git','-C',str(repo),'-c','commit.gpgsign=false','-c','core.hooksPath=/dev/null',*args],env=env,capture_output=True)
    log.append(dict(args=args,exitCode=p.returncode,stdout=p.stdout.decode(errors='replace'),stderr=p.stderr.decode(errors='replace')))
    if p.returncode not in allowed:raise RuntimeError(log[-1])
    return p.stdout

def write(name,text): (repo/name).write_text(text)
git('init','--quiet','--initial-branch=main')
base=''.join(f'export const item_{i} = {i};\n' for i in range(1,81))
write('00-review.ts',base);write('01-staged.ts',base);write('02-empty.txt','old text\n');write('04-pnpm-lock.yaml','lockfileVersion: 9\n');write('06-permission.sh','#!/bin/sh\necho fixture\n');write('07-deleted.txt','deleted content\n');write('08-before.txt','rename content\n');write('09-conflict.txt','base\n');write('中文 空格.ts','export const label = "旧";\n');(repo/'03-binary.bin').write_bytes(b'\0before\0');(repo/'05-link').symlink_to('00-review.ts')
git('add','-A');git('commit','--quiet','-m','fixture baseline')
git('checkout','--quiet','-b','conflict-side');write('09-conflict.txt','side\n');git('add','09-conflict.txt');git('commit','--quiet','-m','side conflict')
git('checkout','--quiet','main');write('09-conflict.txt','main\n');git('add','09-conflict.txt');git('commit','--quiet','-m','main conflict');git('merge','--no-edit','conflict-side',allowed=(1,))
write('00-review.ts',base.replace('item_5 = 5','item_5 = 500').replace('item_40 = 40','item_40 = 4000').replace('item_75 = 75','item_75 = 7500'))
write('01-staged.ts',base.replace('item_5 = 5','item_5 = 501'));git('add','--','01-staged.ts');write('01-staged.ts',(repo/'01-staged.ts').read_text().replace('item_40 = 40','item_40 = 4001'))
write('02-empty.txt','');(repo/'03-binary.bin').write_bytes(b'\0after\0longer');write('04-pnpm-lock.yaml','lockfileVersion: 10\n');(repo/'05-link').unlink();(repo/'05-link').symlink_to('01-staged.ts');(repo/'06-permission.sh').chmod(0o755);(repo/'07-deleted.txt').unlink();git('mv','--','08-before.txt','08-renamed.txt');write('中文 空格.ts','export const label = "新";\n');write('untracked.txt','untracked fixture\n')
for theme in ['light','dark']:
    data=root/f'ui-data-{theme}';data.mkdir();(data/'settings.json').write_text(json.dumps(dict(repos=[str(repo)],lastWorktreeId=hashlib.sha256(str(repo.resolve()).encode()).hexdigest()[:16],diffFontSize=12)))
(root/'home').mkdir();(root/'ui-preparation.json').write_text(json.dumps(dict(repo=str(repo),commands=log,status=git('status','--porcelain=v2','-z').decode()),ensure_ascii=False,indent=2))
print(repo)
