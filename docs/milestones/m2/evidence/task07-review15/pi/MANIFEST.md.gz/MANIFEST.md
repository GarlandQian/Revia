# 任务 07 容量边界返修检查清单（R07-CAP-1）

基线：30faf96cc2afcf8a41ea7b41084cc50516325ea8

## 命令 / 退出码 / 原始输出（最终实现）

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out（tests 79 / pass 79 / fail 0） |
| 规划方原脚本 capacity.mjs 复跑 | 0 | capacity-replay.out / .err / .exit（4 组全通过） |
| git diff --check | 0 | git-diff-check.out / git-diff-check.exit |

本轮只改 `src/lib/refreshGate.ts` 与 `tools/test-refresh-gate.mjs`，
未改 Rust 生产代码与绑定，所以未重跑 Rust 套件与 `pnpm bindings`。

最终源码前后 SHA（source-sha256-before-check.txt / -after-check.txt）逐行一致。

## 复跑规划方原脚本

`/private/tmp/revia-task07-capacity-j737sl5j/capacity.mjs`（只调用生产函数，无 Git 操作）
在修复后 4 组全部通过：

```
1024 newerA True  before True  after True
1025 newerA True  before True  after True
1024 newerA False before False after False
1025 newerA False before False after False
```

第一次复跑时该脚本因直接 `mergePublishedReview(current, older.view, 1)` 传入 `null` 而崩溃
（拒绝发布后 `view` 为 `null`）。据此让 `mergePublishedReview` 对 `null` 安全降级为
「不改变界面」，符合「拒绝过时发布、等重新读取」的语义；原崩溃输出保留在
`sensitivity/` 之外的同名 `.out/.err` 之前一版日志已随初始目录删除，
本轮只保留修复后的成功复跑。

## 敏感性对照（sensitivity/）

| 回退的修复 | exit | tests | pass | fail | 失败用例 |
| --- | --- | --- | --- | --- | --- |
| 2-B-allow-reinsert | exit=1 | 79 | 78 | 1 | 已淘汰路径的旧状态不能重新认领（record 层直接验证，R07-CAP-1） |
| A-no-evicted-watermark | exit=1 | 78 | 73 | 5 | 容量 1025：先 seq2 后旧 seq1，新状态 已审 不回退（R07-CAP-1）; 容量 1025：先 seq2 后旧 seq1，新状态 未审 不回退（R07-CAP-1）; 容量 1025：旧回执被拒绝并要求重新读取（不是静默猜） |
| B-allow-reinsert | exit=0 | 78 | 78 | 0 | （无） |
| C-no-trust-check | exit=1 | 78 | 74 | 4 | 容量 1025：先 seq2 后旧 seq1，新状态 已审 不回退（R07-CAP-1）; 容量 1025：先 seq2 后旧 seq1，新状态 未审 不回退（R07-CAP-1）; 容量 1025：旧回执被拒绝并要求重新读取（不是静默猜） |

说明：
- `A-no-evicted-watermark`：淘汰时不记录水位 → 1025 两条方向与「需重新读取」失败。
- `B-allow-reinsert`（第一轮）：去掉 record 的重插入拦截 → **未触发**（发布检查仍挡住）。
  原件保留。
- `2-B-allow-reinsert`：补「record 层直接验证」用例后，同一回退真实失败。
- `C-no-trust-check`：发布时不检查可信度 → 1025 两条方向与「需重新读取」失败。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=fb468c23944f764d7c8fc01ec1ada2e2066e4daa
