#!/usr/bin/env python3
"""Reconstructed now, not the original saved inline script.

Three original main() error cases plus the original helper-combination case.
The helper case does NOT claim to execute main(). Its inputs are an equivalent
reconstruction; the original in-memory input objects were not saved.
All commands/signals are mocked, and no existing evidence is overwritten.
"""

import argparse
from contextlib import ExitStack, redirect_stdout
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent
SOURCE = "0a2d842004e65587e4e0b5a3bacc02745edade63"
CASES = ("parse_failure", "cleanup_terminate_error", "cleanup_wait_error")


def load_driver():
    spec = importlib.util.spec_from_file_location("bench_fixed_edges", ROOT / "bench-fixed.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def forbidden(*_args, **_kwargs):
    raise AssertionError("External commands or real process signals are forbidden")


def sample_memory(_pid, _evidence):
    return {"rustRssMb": 100.0, "webContentRssMb": 100.0,
            "networkingRssMb": 2.0, "gpuRssMb": 2.0,
            "webContentPids": [1234], "networkingPids": [1235], "gpuPids": [1236]}


class FakeProc:
    pid = 1212
    returncode = None

    def __init__(self, case):
        self.case = case
        self.polls = 0
        self.terminate_calls = 0
        self.wait_calls = 0

    def poll(self):
        self.polls += 1
        if self.case == "parse_failure" and self.polls > 1:
            self.returncode = 0
        return self.returncode

    def terminate(self):
        self.terminate_calls += 1
        if self.case == "cleanup_terminate_error":
            raise OSError("mock terminate rejected")

    def wait(self, timeout=None):
        self.wait_calls += 1
        raise OSError("mock wait unavailable")

    kill = forbidden


def run_main_case(module, case, destination):
    directory = destination / case
    directory.mkdir()
    binary = directory / "Revia.app/Contents/MacOS/revia"
    binary.parent.mkdir(parents=True)
    binary.write_bytes(b"not-executable")
    repo = directory / "fixture"
    repo.mkdir()
    data = directory / "data"
    data.mkdir()
    output = directory / "result.json"
    proc = FakeProc(case)

    def fake_popen(argv, **_kwargs):
        assert argv == [str(binary)]
        return proc

    def fake_run(argv, **_kwargs):
        assert argv in (["vmmap", "-summary", "1212"], ["vmmap", "-summary", "1234"])
        stdout = "Physical footprint: 123M\n" if argv[-1] == "1212" else "Physical footprint missing\n"
        return subprocess.CompletedProcess(argv, 0, stdout=stdout, stderr="")

    argv = [str(ROOT / "bench-fixed.py"), "--app", str(directory / "Revia.app"),
            "--repo", str(repo), "--output", str(output), "--seconds", "1800"]
    exit_code, exception = None, None
    with ExitStack() as stack:
        for function in ("check_output", "check_call", "call"):
            stack.enter_context(patch.object(module.subprocess, function, side_effect=forbidden))
        for function in ("kill", "killpg", "system"):
            stack.enter_context(patch.object(module.os, function, side_effect=forbidden))
        stack.enter_context(patch.object(module.subprocess, "run", side_effect=fake_run))
        stack.enter_context(patch.object(module.subprocess, "Popen", side_effect=fake_popen))
        stack.enter_context(patch.object(module.platform, "system", return_value="Darwin"))
        stack.enter_context(patch.object(module.platform, "platform", return_value="mocked-macOS"))
        stack.enter_context(patch.object(module.tempfile, "mkdtemp", return_value=str(data)))
        stack.enter_context(patch.object(module.time, "monotonic", side_effect=itertools.count(0, 10)))
        stack.enter_context(patch.object(module.time, "sleep", return_value=None))
        stack.enter_context(patch.object(module, "sample_memory", side_effect=sample_memory))
        stack.enter_context(patch.object(sys, "argv", argv))
        stream = stack.enter_context((directory / "driver.stdout").open("x"))
        stack.enter_context(redirect_stdout(stream))
        try:
            exit_code = module.main()
        except OSError as error:
            exception = f"{type(error).__name__}: {error}"
    report = json.loads(output.read_text()) if output.exists() else None
    evidence = Path(str(output) + ".evidence.jsonl").read_text()
    records = [json.loads(line) for line in evidence.splitlines()]
    return {"case": case, "exit": exit_code, "exception": exception,
            "reportExists": report is not None,
            "partialCandidates": report["partialCandidates"] if report is not None else None,
            "recordKinds": [record["kind"] for record in records],
            "hasRust123Raw": "Physical footprint: 123M" in evidence,
            "terminateCalls": proc.terminate_calls, "waitCalls": proc.wait_calls}


def run_helper_case(module, destination):
    frontend = {"ok": True, "phaseCheckpoints": []}
    checkpoints = []
    phases = []
    regular = []
    for cycle, elapsed in enumerate((200, 300, 400), start=1):
        minute = cycle * 5
        checkpoints.append({"kind": "checkpoint", "runId": "r1", "cycle": cycle,
                            "file": "src/staged.ts", "view": "split", "pressure": True,
                            "hiddenDuringHold": False,
                            "startedAt": f"2026-10-25T00:{minute:02d}:00+00:00",
                            "endedAt": f"2026-10-25T00:{minute:02d}:16+00:00"})
        phases.append({"checkpointId": cycle, "pressure": True, "errors": [],
                       "samplingStartedElapsedSec": elapsed,
                       "timestamp": f"2026-10-25T00:{minute:02d}:10+00:00",
                       "samplingEndedAt": f"2026-10-25T00:{minute:02d}:11+00:00",
                       "webContentFootprintMb": 100.0,
                       "webContentMallocAllocatedMb": 50.0})
        regular.append({"elapsedSec": elapsed, "rustFootprintMb": 100.0})

    class ClosedBoundaries:
        def has_ended(self, checkpoint_id):
            return checkpoint_id in (1, 2, 3)

    inputs = {"frontend": frontend, "progressCheckpoints": checkpoints,
              "phaseSamples": phases, "regularSamples": regular}
    (destination / "helper-reconstructed-inputs.json").write_text(json.dumps(inputs, indent=2) + "\n")
    module.finalize_phase_samples(phases, ClosedBoundaries(), frontend, checkpoints)
    verdict = module.analyze_q98(regular, phases, 0)
    result = {"case": "incomplete_final_falls_back_to_progress",
              "phaseSources": [sample["checkpointSource"] for sample in phases],
              "phaseValid": [sample["valid"] for sample in phases],
              "phaseAuthoritative": [sample["authoritative"] for sample in phases],
              "q98Passed": verdict["passed"],
              "q98MemoryVerdictAuthoritative_as_in_main": bool(frontend.get("ok") is True)}
    (destination / "helper-reconstructed-details.json").write_text(json.dumps(
        {"phaseSamples": phases, "q98Verdict": verdict,
         "executionScope": "finalize_phase_samples + analyze_q98 + matching main boolean expression; NOT main"},
        indent=2) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("destination", type=Path, help="New directory only; never overwrite old evidence")
    args = parser.parse_args()
    destination = args.destination.resolve()
    destination.mkdir(parents=True, exist_ok=False)
    module = load_driver()
    results = [run_main_case(module, case, destination) for case in CASES]
    results.append(run_helper_case(module, destination))
    (destination / "edge-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    old = json.loads((ROOT / "edge-results.json").read_text())
    assert results == old, "Reconstructed outcomes differ from the original result summary"
    metadata = {"provenance": "reconstructed now; not original inline source",
                "sourceCommit": SOURCE,
                "driverSha256": hashlib.sha256((ROOT / "bench-fixed.py").read_bytes()).hexdigest(),
                "matchesOriginalSummary": True, "mainCases": list(CASES),
                "helperOnlyCase": "incomplete_final_falls_back_to_progress",
                "realExternalCommands": False, "realSignals": False}
    (destination / "reconstruction.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(destination)


if __name__ == "__main__":
    main()
