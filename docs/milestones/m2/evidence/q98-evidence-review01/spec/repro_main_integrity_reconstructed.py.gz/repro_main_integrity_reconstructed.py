#!/usr/bin/env python3
"""Reconstructed now, not the original saved inline script.

Equivalent reconstruction from bench-fixed.py and the retained first-run artifacts.
Exercises only the four original main() integrity cases. All process and sampling
calls are mocked; the fake application is never executable or launched.
"""

import argparse
from contextlib import ExitStack, redirect_stdout
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import sys
from unittest.mock import patch


ROOT = Path(__file__).resolve().parent
SOURCE = "0a2d842004e65587e4e0b5a3bacc02745edade63"
CASES = {
    "bad_json": '[SOAK_PROGRESS] {bad json}\n',
    "missing_anchor": '[SOAK_CHECKPOINT_END] 1\n',
    "duplicate_anchor": '[SOAK_PROGRESS] {"kind":"run","runId":"r1"}\n' * 2,
    "unfinished_tail": '[SOAK_PROGRESS] {"kind":"run","runId":"r1"}\n'
                       '[SOAK_PROGRESS] {"kind":"checkpoint"',
}
FRONTEND = {
    "ok": True, "actualDurationSeconds": 1800, "totalFileSwitches": 7,
    "totalViewSwitches": 12, "totalScrolls": 33, "totalJumps": 6,
    "minimalSoakLogging": False,
}


def load_driver():
    spec = importlib.util.spec_from_file_location("bench_fixed_integrity", ROOT / "bench-fixed.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sample_memory(_pid, _evidence):
    return {"rustRssMb": 100.0, "webContentRssMb": 100.0,
            "networkingRssMb": 2.0, "gpuRssMb": 2.0,
            "webContentPids": [1234], "networkingPids": [1235], "gpuPids": [1236]}


def forbidden(*_args, **_kwargs):
    raise AssertionError("External commands or real process signals are forbidden")


class FakeProc:
    pid = 1212
    returncode = None

    def __init__(self):
        self.polls = 0

    def poll(self):
        self.polls += 1
        if self.polls > 2:
            self.returncode = 0
        return self.returncode

    terminate = forbidden
    kill = forbidden
    wait = forbidden


def run_case(module, case, payload, destination):
    directory = destination / case
    directory.mkdir()
    binary = directory / "Revia.app/Contents/MacOS/revia"
    binary.parent.mkdir(parents=True)
    binary.write_bytes(b"mocked-app-not-executable")
    repo = directory / "fixture"
    repo.mkdir()
    data = directory / "data"
    data.mkdir()
    output = directory / "result.json"

    def fake_popen(argv, *, env, stdout, stderr):
        assert argv == [str(binary)]
        frontend = Path(env["REVIA_MEASURE_LOG"])
        frontend.write_text(json.dumps(FRONTEND))
        frontend.with_suffix(".log").write_text(payload)
        return FakeProc()

    argv = [str(ROOT / "bench-fixed.py"), "--app", str(directory / "Revia.app"),
            "--repo", str(repo), "--output", str(output), "--seconds", "1800"]
    with ExitStack() as stack:
        for function in ("run", "check_output", "check_call", "call"):
            stack.enter_context(patch.object(module.subprocess, function, side_effect=forbidden))
        for function in ("kill", "killpg", "system"):
            stack.enter_context(patch.object(module.os, function, side_effect=forbidden))
        stack.enter_context(patch.object(module.subprocess, "Popen", side_effect=fake_popen))
        stack.enter_context(patch.object(module.platform, "system", return_value="Darwin"))
        stack.enter_context(patch.object(module.platform, "platform", return_value="mocked-macOS"))
        stack.enter_context(patch.object(module.tempfile, "mkdtemp", return_value=str(data)))
        stack.enter_context(patch.object(module.time, "monotonic", side_effect=itertools.count(0, 10)))
        stack.enter_context(patch.object(module.time, "sleep", return_value=None))
        stack.enter_context(patch.object(module, "sample_memory", side_effect=sample_memory))
        stack.enter_context(patch.object(module, "physical_footprint", return_value=100.0))
        stack.enter_context(patch.object(sys, "argv", argv))
        stream = stack.enter_context((directory / "driver.stdout").open("x"))
        stack.enter_context(redirect_stdout(stream))
        exit_code = module.main()
    report = json.loads(output.read_text())
    return {"case": case, "exit": exit_code, "runCompleted": report["runCompleted"],
            "errors": report["errors"], "progressProblems": report["progressEvidence"]["problems"],
            "anchor": report["progressEvidence"]["anchor"],
            "q98MemoryVerdictAuthoritative": report["q98MemoryVerdictAuthoritative"]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("destination", type=Path, help="New directory only; never overwrite old evidence")
    args = parser.parse_args()
    destination = args.destination.resolve()
    destination.mkdir(parents=True, exist_ok=False)
    module = load_driver()
    results = {"source": SOURCE, "results": [run_case(module, name, text, destination)
                                               for name, text in CASES.items()]}
    (destination / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    old = json.loads((ROOT / "results.json").read_text())
    assert results == old, "Reconstructed outcomes differ from the original result summary"
    metadata = {"provenance": "reconstructed now; not original inline source",
                "sourceCommit": SOURCE,
                "driverSha256": hashlib.sha256((ROOT / "bench-fixed.py").read_bytes()).hexdigest(),
                "matchesOriginalSummary": True, "mainCases": list(CASES),
                "realExternalCommands": False, "realSignals": False}
    (destination / "reconstruction.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(destination)


if __name__ == "__main__":
    main()
