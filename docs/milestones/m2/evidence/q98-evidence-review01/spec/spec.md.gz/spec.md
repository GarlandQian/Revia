# Spec 轴：Q98 留证修复复核

- 固定范围：`1849ff8c2462f3179edc58daa0d69d0ab862e68e...0a2d842004e65587e4e0b5a3bacc02745edade63`；只审提交 `0a2d842`，不把后续工作树或验证报告当提交事实。
- 结论：2 项 P1、3 项 P2，需返修后复审；未发现范围扩张。未启动 GUI、Release、真实采样或长测，未修改仓库。

## 发现

1. **SP-Q98-1 / P1：进度完整性未进入失败资格。** `tools/bench-long-running.py:749` 取得 `progress_problems` 后只在 `:770` 报告，未加入 `errors`；`:243` 丢弃未闭合尾行，`:261` 接受同 runId 重复锚点，没有进度锚点也不报错，锚点未绑定本轮输出。实际生产 `main()` 的坏 JSON、缺锚点、重复锚点、截断尾行四例均 `exit=0/runCompleted=true`。需求：修复说明第 3 项（`:15`）“缺/损坏/重复/跨运行/未闭合记录均fail-closed”。这些是同一完整性链，须同时修解析和最终判定。

2. **SP-Q98-2 / P1：诊断阶段可取得权威 Q98 判定。** `tools/bench-long-running.py:425` 在最终报告存在但 `phaseCheckpoints=[]` 时仍回退增量；`:513` 的 `analyze_q98` 不排除 `authoritative=false`，`:778` 仅依据 `frontend.ok` 标记整体权威。`finalize_phase_samples` + `analyze_q98` 的组合复现得到三段 `progress-log/authoritative=false`，却 `q98.passed=true`；对应 main 布尔表达式为 true。**此项不是完整 `main()` 复现**。需求：修复说明 `:15` “部分记录不能冒充frontend最终完成”，增量只用于诊断。与 SP1 同属最终资格但输入、错误机制独立，不应仅加 `errors.extend` 后视为解决。

3. **SP-Q98-3 / P2：清理异常使留证和汇总一起丢失。** `tools/bench-long-running.py:720` 先设置 `terminateSent=true`，直到 `:736` 才一次落盘。实际 `main()` 中分别 mock `terminate()` / `wait()` 抛 `OSError`，均直接逸出，无 cleanup 记录、无最终报告。需求：修复说明 `:13` 记录“实际terminate/kill调用和wait结果”，未知如实记录。应区分尝试与成功并逐步落盘，异常仍有终态汇总。

4. **SP-Q98-4 / P2：解析错误漏存结构化部分候选。** `tools/bench-long-running.py:689` 只捕获 `SubprocessError`；vmmap 退出 0 但缺 footprint 抛 `RuntimeError`，跳过部分候选保全。实际 `main()` 已取 Rust 123 MiB、后 WebContent 解析失败，`partialCandidates=[]`。Rust 原始 stdout 仍在，丢失的是候选及失败时状态的结构化关联，非所有原件。需求：修复说明 `:13` “失败候选已取得的部分数据单独保存，不能无痕丢失”。

5. **SP-Q98-5 / P2：命令原件覆盖不完整。** `tools/bench-long-running.py:138` 的 ps 使用 `CommandEvidence.run`，timeout 在记录前抛出，不保存部分输出；`:366` 的 notifyutil 直接 `subprocess.run`，绕过记录器且不捕获 stdout/stderr。静态代码证据，未另做动态案例。需求：`ownership-log-boundary.md:5` 明确要求 vmmap/ps/notifyutil 原始输出及 timeout 已得输出；不涉及要求保存 launchctl 全量环境。

## 证据及边界

- 要求原件：`/private/tmp/revia-pi-model-order.LJ0ek9/q98-evidence-repair.md:13`、`:15`、`:16`；`/private/tmp/revia-q98-resume-chain.keaPgV/ownership-log-boundary.md:5`。长期门槛仍按 `docs/milestones/m2/spec.md:62`、`docs/milestones/m2/benchmark.md:24`；此次复核不能证明 Q98/M2 通过。
- 固定代码：本目录 `bench-fixed.py`。旧第一组：`results.json` 及四用例目录，调用实际 `main()`，只模拟进程、采样和时间等边界；旧第二组：`edge-results.json` 及三个 main 用例目录。SP2 是独立的生产 helper 组合，未经过完整 main。
- **源码留存更正：** 旧两次内联 Python 未单独保存；本轮新增 `repro_main_integrity_reconstructed.py` 与 `repro_edges_reconstructed.py`，依据固定源码、保留的输入/输出和审查记录现在重建，不能冒称旧时已保存或逐字相同。SP2 的重建输入为等价构造，旧输入对象未留存。
- 重建脚本只含原有案例，使用假二进制和假 fixture；所有外部命令和信号路径均 mock/禁止，没有真实 launchctl、ps、vmmap、notifyutil 或应用启动。新执行原件只写全新目录；旧 58 个文件的哈希记录在 `old-artifact-sha256-before-archive.json`。
- 两份重建脚本已原样各执行一次，退出均为 0，输出位于 `reconstructed-run-01/integrity/`、`reconstructed-run-01/edges/`；脚本内断言确认分别与旧 `results.json`、`edge-results.json` 的结果摘要完全相同。此处脚本退出 0 表示反例复现成功，不表示受审代码通过。
- 残余风险：mock 不证明 macOS 实际采样/退出竞态已修复；本轮未做真实长测，既有 Rust +82 MiB 振幅仍未定位。SP1 的测试不证明内存门槛通过，SP2 不宣称完整 main 或桌面验收通过。
