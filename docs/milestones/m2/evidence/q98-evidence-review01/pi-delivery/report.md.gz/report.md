# M2 Q98 留证修复：交付报告（待双轴审查）

**这不是 M2 或 Q98 通过报告。** 本次只修测量失败的可观察性与证据保全；
vmmap 底层错误、Rust 内存振幅、两轮 Q98 失败判定均未改变。

## 提交

| 项 | 值 |
| --- | --- |
| 分支 | `m2`（worktree `/Users/garland/.codex/worktrees/m2-close-finish/Revia`） |
| 起点 | `1849ff8c2462f3179edc58daa0d69d0ab862e68e` |
| 实现提交 | **`0a2d842004e65587e4e0b5a3bacc02745edade63`**（4 文件，+541 / −30） |
| 补交提交 | **`5e9b86215a1bca90a6b217929648c79a90592636`**（仅任务 10 文档，补检查原件路径） |
| 合计 | 4 文件，+558 / −30 |
| 状态 | tracked clean（忽略 `.codex/`）；未 amend、未推送、未合并 |
| 产品源码 | 仍为 `2a51b16`；测试为 `f10`；**未重新构建 Release** |

改动文件：`tools/bench-long-running.py`、`tools/test_bench_long_running.py`、
`src/App.tsx`（仅原 soak 测量分支）、`docs/milestones/m2/issues/10-integrated-verification.md`。

**未新增测量辅助模块**：增量 checkpoint 直接复用既有 `ipc.debugLog` 非退出通道，
因此不需要新的前端模块，职责边界保持最小。

## 两处旧诊断更正

保留原件 `/private/tmp/revia-q98-pi-diagnosis.G1herl/report.md` 不删，其第 3 条与最后日志时间按以下更正：

1. **退出码 0 不能推断「driver 没有发送 terminate」或「应用在清理前自行退出」。**
   SIGTERM 可能被进程处理并以 0 正常退出，单独的码 0 不足以排除 terminate；
   实际 cleanup 动作、第二次 `poll()` 结果均无独立原件，**仍为未知**。
   这正是本次增加清理留证的原因。
2. **最后前端日志时间应为 `2026-10-25T08:31:11.243Z` / `16:31:11.243 CST`**，
   不是 `16:31:11.243Z`（原文把 UTC 与本地时区混写）。

另：缺最终报告会导致额外的「前端日志模式不匹配」错误，这是报告噪音，
**不构成放宽通过条件的理由**；两轮历史长测均保持失败。

## 修复内容

### 1. 采样命令与清理留证（`tools/bench-long-running.py`）

- `CommandEvidence.run/run_timeout`：逐条记录实际 argv、purpose、起止时间、耗时、
  退出码或异常、**完整 stdout/stderr**；`TimeoutExpired` 额外保存
  `partialStdout`/`partialStderr`（timeout 已取得的输出）。
- **launchctl 凭据边界**：`launchctl print pid/<pid>` 的完整 stdout 可能含进程环境
  （含凭据），因此只保留解析出的 **WebKit services 行**，不保存原始 stdout；
  每条记录写入 `redaction` 说明裁剪范围与原因，**不冒称未裁剪原件**。
  launchctl 失败/超时返回 `None`，调用方按「归属证据缺失」处理，
  绝不当作成功（`sample_memory` 会显式抛错）。
- **部分样本保全**：常规采样的 RSS 阶段成功后，若 footprint 阶段失败，
  已取得的字段连同 `failure`、`reviaPid`、`pollAtFailure`、`servicesAtFailure`、
  `capturedAt` 一起进入 `partialCandidates` 并写入 `*.evidence.jsonl`，
  不再随异常无痕丢失。
- **清理动作留证**：`pollBeforeCleanup`、`terminateSent`/`terminateSentAt`、
  `waitAfterTerminate`、必要时 `killSent`/`waitAfterKill`、`pollAfterCleanup`、
  `servicesBeforeCleanup`。清理前已退出时记 `terminateSent:false` 并注明原因。
  取不到的状态如实留空，**不为取证重启进程或杀其他进程**。
- 失败即失败：不静默重试、不用 RSS 替代 footprint、不 sudo、不加权限。

### 2. 增量 checkpoint（`src/App.tsx`，仅原 soak 测量分支）

- setup 完成后经 `ipc.debugLog` 写运行锚点：
  `[SOAK_PROGRESS] {kind:"run", runId, targetSeconds, repo, outputPath, setupSeconds}`。
  `runId` 由 `operationsStartedAt` + `outputPath` 组成，作为运行关联锚点。
  **不调用 `writeMeasurement`**（它会在 500ms 后结束进程）。
- 每个 checkpoint **闭合后**立即写
  `{kind:"checkpoint", cycle, file, view, pressure, startedAt, endedAt,
  hiddenDuringHold, checkpointPauseSeconds, visibilityPauseSeconds,
  cycles, fileSwitches, viewSwitches, scrolls, jumps}`。
  **未闭合的段不写**，不伪造进度。
- 既有 `[SOAK_CHECKPOINT_BEGIN]/[SOAK_CHECKPOINT_END]` 保持不变，仍是驱动判定
  静置窗口闭合的依据。

### 3. 严格读取与 fail-closed（`ProgressLog`）

- 未终止的尾行**不解析**（按 `\n` 切分，最后一段丢弃）。
- 计入 `problems` 并导致失败的完整性违规：非法 JSON、非对象、未知类型、
  checkpoint 早于锚点、与锚点不同运行、**第二个锚点**、`cycle` 非整数、
  **重复 cycle**、**未闭合**（缺 `endedAt`）、日志文件不存在。
- 阶段最终校验新增 `checkpointSource`（`final-report` / `progress-log` / `missing`）
  与 `authoritative`：**只有真实最终前端报告是权威来源**。
  仅进度记录时 `authoritative:false`，报告另设 `q98MemoryVerdictAuthoritative:false`，
  控制台打印「非权威：缺最终前端报告，仅诊断」。
- 最终成功条件**完全不变**：真实 `.frontend.json`、`ok:true`、1800 主动秒、
  完整负载计数、同 PID/可见性证据、原 Q98 阈值（+10 MiB / 0.5 MiB/min / ≥3 有效压力样本）。
  未放松任何阶段起止区间或 `hiddenDuringHold` 核验。

### 4. 回归测试（`tools/test_bench_long_running.py`）

复用既有 unittest，**20 → 32 项**，新增 12 项：命令留证（argv/退出/stdout/stderr）、
timeout 部分输出、归属证据不含凭据哨兵、归属失败不等于成功、进度只暴露已闭合唯一段、
7 类完整性违规 fail-closed、缺进度文件如实报告、进度不得替代最终报告（`authoritative`
区分）、仅进度记录时整轮仍失败、部分样本保全、清理动作区分 terminate 与已退出、
以及 `completion_errors` 在缺 `ok` 时仍失败。

## 检查结果

**原件目录（本轮独占，未覆盖旧输出）**：
`/private/tmp/revia-q98-evidence-repair.Qvsbwg/final-checks-20261025-184247`
—— 29 件原件 + `invocations.json` + `manifest.json` + `record.py`。

`record.py` 在**执行时**记录真实 argv、cwd、显式非敏感环境变量、起止时间、
退出码与完整 stdout/stderr（未导出完整继承环境，避免凭据）；逐条落为
`NN-<name>.{out,err,exit,json}`，并汇总到 `invocations.json`。没有事后补填的命令清单。

| 命令 | 退出码 | 结果 | 原件 |
| --- | --- | --- | --- |
| `python3 tools/test_bench_long_running.py` | 0 | **32 passed** | `01-python-unittest.*` |
| `pnpm exec tsc -b` | 0 | — | `02-tsc.*` |
| `pnpm lint` | 0 | 仅既存 warning | `03-lint.*` |
| `pnpm build` | 0 | — | `04-build.*` |
| `git diff --check HEAD~1 HEAD` | 0 | 无输出 | `05-diff-check.*` |

受测源码 SHA-256 在检查前后一致（`tested-source-sha256-before.txt` /
`tested-source-sha256-after.txt`）；HEAD 与工作树状态在检查前后未变
（`head.txt` / `head-after.txt`、`status-before.txt` / `status-after.txt`）。

三份受测代码文件（`tools/bench-long-running.py`、`tools/test_bench_long_running.py`、
`src/App.tsx`）自 `0a2d842` 起**未变**，提交后 SHA 与检查时一致
（`committed-code-sha256.txt`）。补交提交 `5e9b862` **只改任务 10 文档**，
因此文档 SHA 与检查时不同，如实标注、不冒充同一版。

未重跑全量 Rust 或无关 Node（本次未改 Rust 与 Git/恢复/关闭核心逻辑）；
未做 GUI / Release 构建 / D06 / CI / 长测。

### 证据边界

本轮更早一次同类检查（在 `0a2d842` 提交前）确实执行且五项均退出 0，
但其原始流**只在会话内、未落盘**，因此**不称其已留存**，也不把会话输出
当作原件。上表是对已提交源码 `0a2d842` 集中重跑后的真实原件。

## 首次失败（保留，不覆盖）

- 新增测试初次运行 1 项失败：fake `webcontent_memory` 签名仍是单参
  （`snapshot(_)`），而生产函数已改为 `(pid, evidence=None)` → `TypeError`。
  修正测试替身签名后 32 项通过；**生产语义与断言未改**。
- 另有一次自建测试因 `ps` 与 `launchctl` 共用同一 mock 返回值导致 RSS 解析为空
  （「Revia/WebKit 进程不完整」），改为按 argv 分派后通过；同上，断言未放松。

## 未解决（不猜测、不放宽）

1. **vmmap `-summary` exit 255 的系统级根因**（端口/权限/生命周期）仍未确定。
   本次只保证下次失败有完整原件。
2. **Rust 热身后常规 footprint 最大抬升 82.0 MiB > 10 MiB 门槛**，单列待定位。
   斜率 −0.9827 MiB/min 在上限内、序列明显回落（最小 116.0 MiB），
   现有日志不足以区分存活分配与 allocator 高水位。
   **未**改缓存/分配策略、未挑首点、未延长暖机、未减少负载、
   未用同阶段样本替代常规样本。
3. WebContent footprint / malloc 两项仍缺有效压力后样本（0 个，要求 ≥3），
   3 笔未获最终有效性的原值仅作线索。
4. 增量记录依赖 `ipc.debugLog`；Rust 侧当前**吞掉写日志错误**，
   因此 `await` 返回不等于已持久化。缺记录时驱动明确失败，但「写失败静默」
   这一 Rust 行为不在本次授权范围内，未修改。

## 边界声明

- 未改阈值、暖机、采样间隔/窗口、负载、既有 fixtures、old evidence、`main`、`m2-ui`。
- 未操作真实用户仓库/配置/凭据；所有测试只在本轮独占临时目录与既有 fixture 边界内。
- 任务 10 **保持 `ready-for-agent`**，未标 done；M2 未通过，未合 main，未启动 M3。
- 提交后停止，等待 Codex Standards / Spec 双轴审查；后续固定 Release、
  诊断与最终完整 30 分钟长测由规划方决定。
