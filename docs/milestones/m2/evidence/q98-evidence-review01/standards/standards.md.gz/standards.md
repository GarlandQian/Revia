# Standards：1849ff8...0a2d842

## ST-Q98-1 / P2：新增清理与失败留证回归没有执行生产入口

`tools/test_bench_long_running.py:499` 明写“Mirror the production cleanup block”，在测试里重新实现判断和 terminate 分支，未调用生产清理代码，也未调用 `evidence.record`；`tools/test_bench_long_running.py:460` 只顺次调用 RSS/footprint 函数，没有进入生产候选保全、poll 或自然退出竞态路径。因此删除或破坏 `main()` 的新增清理/部分样本逻辑，两项回归仍可通过，不能支持交付记录所称覆盖。违反 `docs/agents/local-validation.md:8` 的生产入口验证及 `docs/agents/local-validation.md:16` 的结论须对应生产入口/实际可观察结果。复制清理块同时是 possible Duplicated Code（判断性 smell，不另计发现）。应通过真实生产函数/入口、在外部命令和进程信号边界 mock。

最小复核从固定提交在内存加载两项测试，把 `bench.main` 替换成必抛错函数：2/2 通过，生产入口调用0次。原件 `result.txt`、`facts.json`；没有执行真实外部采样、信号或GUI。

## ST-Q98-2 / P2：固定交付把未保存的检查流称为原件

`docs/milestones/m2/issues/10-integrated-verification.md:240` 宣称一次集中检查及指定目录原件，但交付时该目录只有源码hash/patch。Paseo工具记录显示tsc/lint/build/diff-check输出经 `tail` 过滤且没有保存完整stdout/stderr。违反 `docs/agents/local-validation.md:9`“保存源码SHA、精确命令、真实退出码、原始stdout/stderr，过滤摘要仅辅助”。不否定检查曾执行，但固定提交的可核验证据不足；应明确初次缺件，并另记后补检查来源，不能把后补流回填成原来那次。

后补 `final-checks-20261025-184247/` 正在准备，与本次固定提交原始陈述分开核验。

结论：2项确定标准发现，最高P2；Duplicated Code仅作为第1项的判断性说明，不另增计数。仅审固定提交，未做完整测试、Release或真实桌面验收。
