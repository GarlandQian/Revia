#!/usr/bin/env python3
"""Reconstructed now from the prior executed heredoc, not saved at that time.

The fixed-source test setup is unchanged. This rerun writes new output names and
refuses to replace the original facts.json/result.txt or an earlier rerun.
"""

import ast
import hashlib
import io
import json
import pathlib
import subprocess
import tempfile
import types
import unittest
from unittest import mock

root = pathlib.Path.cwd()
commit = "0a2d842004e65587e4e0b5a3bacc02745edade63"


def source(path):
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], text=True)


bench_src = source("tools/bench-long-running.py")
bench = types.ModuleType("fixed_bench")
bench.__file__ = str(root / "tools/bench-long-running.py")
exec(compile(bench_src, bench.__file__, "exec"), bench.__dict__)
tree = ast.parse(source("tools/test_bench_long_running.py"))
klass = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == "BenchmarkSafetyTests")
names = {
    "test_sample_failure_keeps_partial_candidate_and_polls_app",
    "test_cleanup_evidence_distinguishes_terminate_from_already_exited",
}
klass.body = [n for n in klass.body if isinstance(n, ast.FunctionDef) and n.name in names]
ns = {
    "unittest": unittest,
    "mock": mock,
    "bench": bench,
    "tempfile": tempfile,
    "Path": pathlib.Path,
    "json": json,
}
exec(compile(ast.Module(body=[klass], type_ignores=[]), "<fixed tests>", "exec"), ns)
stream = io.StringIO()
with mock.patch.object(bench, "main", side_effect=AssertionError("production main unavailable")) as production_main:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(ns["BenchmarkSafetyTests"])
    )
    called = production_main.call_count

out = pathlib.Path(__file__).resolve().parent
with (out / "result-recheck.txt").open("x") as file:
    file.write(stream.getvalue())
with (out / "facts-recheck.json").open("x") as file:
    json.dump({
        "commit": commit,
        "driverSha256": hashlib.sha256(bench_src.encode()).hexdigest(),
        "testsRun": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "productionMainCallCount": called,
        "scope": "Only two fixed-commit tests; all external calls and signals mocked.",
        "reconstructionNote": "Script reconstructed after original run from its executed heredoc; this is a new rerun.",
    }, file, indent=2)
    file.write("\n")
print(out)
print(stream.getvalue())
print("production main calls:", called)
