import datetime,hashlib,json,os,pathlib,subprocess,sys
w=pathlib.Path('/Users/garland/.codex/worktrees/revia-m2/Revia')
r=pathlib.Path('/private/tmp/revia-task05-mbnrk698')
source='de8979655f44ceb7531d64e13b6a12a97f7c0417'
expected='05316c294400392019e7215cd1f329041d48082fd8d9f527e178a026fed20268'
binary=w/'src-tauri/target/release/bundle/macos/Revia.app/Contents/MacOS/revia'
kind,view,attempt=sys.argv[1:]
assert kind in ('normal','cold') and view in ('split','unified') and attempt.isdigit()
assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
subprocess.run(['git','diff','--quiet',source,'--','src','src-tauri/src','src-tauri/Cargo.toml','src-tauri/Cargo.lock','src-tauri/tauri.conf.json','src-tauri/icons'],cwd=w,check=True)
active=[line for line in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines() if line.strip().endswith('/revia')]
assert not active,active
out=r/'perf-runs'/f'{kind}-{view}-{attempt}'
out.mkdir(parents=True,exist_ok=False)
data=out/'data';data.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith(('GIT_','REVIA_'))}
env.update(HOME=str(r/'home'),USERPROFILE=str(r/'home'),GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=str(r/'home/.gitconfig'),REVIA_MEASURE='1',REVIA_MEASURE_ONLY=view,REVIA_MEASURE_KEEP_OPEN='1',REVIA_MEASURE_DATA_DIR=str(data),REVIA_MEASURE_REPO=str(r/('perf-fixtures/diffs' if kind=='normal' else 'perf-cold')),REVIA_MEASURE_PATH='src/generated.ts' if kind=='normal' else 'cold.ts',REVIA_MEASURE_LOG=str(out/'result.json'))
with (out/'stdout.log').open('x') as log:
    p=subprocess.Popen([str(binary)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
value={'buildSource':source,'checkoutAtLaunch':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'productSourceMatchesBuild':True,'binary':str(binary),'binarySha256':expected,'pid':p.pid,'kind':kind,'view':view,'output':str(out),'launchedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dataDir':str(data),'repo':env['REVIA_MEASURE_REPO'],'path':env['REVIA_MEASURE_PATH'],'keepOpen':True}
(out/'launch.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
