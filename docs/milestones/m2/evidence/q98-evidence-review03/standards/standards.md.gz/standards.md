# Standards

固定范围：`git diff 85a2f5c569302ee43af07f0bd768f995478bc2df...ddb9da5bda35162131b3f0011a56303f4937685f`；提交 `22809f2`、`ddb9da5`。仅依据固定提交及对应原件，不把后续工作树作为交付事实。

## 文档规范违例

**新发现0项。** 依据 AGENTS/CLAUDE、local-validation、issue-tracker、GLOSSARY、technical-direction、ADR0007、README Q92/Q109-Q113；未发现本轮确定违反文档规范的改动。

## 原发现闭合

- **ST-Q98-R2-1：闭合。** `tools/bench-long-running.py:901` 每轮重置 `sample`，已取得的本轮 services 独立保存；`tools/test_bench_long_running.py:487` 通过真实 `main()` 分别模拟首次、后续 ps 超时，检查候选保留、原异常、无上一轮 RSS/footprint/timestamp，以及超时原始输出。没有复制生产保全分支代替调用。
- **ST-Q98-R2-2：闭合。** 原同名候选测试已改为上述真实入口验证；任务10最新 Comments 明确指出旧删除陈述不实，保留旧历史，不倒改为当时已通过。
- **possible Duplicated Code：闭合。** 九份同名副本已删除；固定源码对应的 AST 检查为46定义、46唯一、0同名。新增夹具/检查函数服务实际复现，无确定需要报告的新 smell。

## 证据与边界

`/private/tmp/revia-q98-root-takeover.3EEtAR/checks.SZuTne` 的 recorder、实际调用元数据与完整流支持 Python46通过、源码契约、两次 diff-check 均exit0；本次独立核对四文件固定提交SHA与检查前/后一致。App.tsx未改，未重复前端、Rust、Node或GUI检查。

归档manifest按 Pi、双轴复现、root 分组保留231件；root误追加并恢复Pi目录的事件及后补检查时点单列，没有冒称原目录从未修改，也未归为Pi错误。

本次审查材料：本目录 `review.diff`、`fixed-source-sha256.txt`；未新增生产行为复现或改仓库。静态校验首次因 zsh 保留变量 `path` 被当作循环变量而无法解析命令，已改用 `filename` 重新核对；这不是受测代码失败。

**本轴结论：0项硬性违例、0项新增启发式；原三项闭合。** 残余风险：未执行新版Release、真实采样或完整30分钟长测；本结论不代表M2/Q98验收通过，也不证明Rust振幅或vmmap255根因解决。
