#!/usr/bin/env python3
"""Fixed-commit Spec review reproductions; never run a real app or sampler.

Adapted from the prior independent review harness and saved before this execution.
Final checkpoints deliberately use the actual App shape without cumulative fields.
Only subprocess/process/time/platform boundaries
are mocked. Main cases execute production main(); helper cases are labelled.
"""

import argparse
from contextlib import ExitStack, redirect_stdout
import copy
import datetime
import importlib.util
import itertools
import json
from pathlib import Path
import subprocess
import sys
from unittest import mock


ROOT = Path(__file__).resolve().parent
SOURCE = "ddb9da5bda35162131b3f0011a56303f4937685f"
DOMAIN = ("pid/4242 = {\n environment = {\n SECRET => SENTINEL_NEVER_RETAIN\n }\n"
          " services = {\n 45 - com.apple.WebKit.WebContent.A\n"
          " 47 - com.apple.WebKit.Networking.B\n 46 - com.apple.WebKit.GPU.C\n }\n}")
RSS = "4242 102400\n45 204800\n47 2048\n46 2048\n"


def load_driver():
    spec = importlib.util.spec_from_file_location("fixed_bench", ROOT / "bench-fixed.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def forbidden(*_args, **_kwargs):
    raise AssertionError("Real command/process/signal boundary is forbidden in this reproduction")


def add_guards(stack, bench):
    for name in ("Popen", "run", "check_call", "call", "check_output"):
        stack.enter_context(mock.patch.object(bench.subprocess, name, side_effect=forbidden))
    for name in ("kill", "killpg", "system"):
        stack.enter_context(mock.patch.object(bench.os, name, side_effect=forbidden))


def metadata():
    checkpoints = []
    phases = []
    regular = []
    for cycle, elapsed in enumerate((200, 400, 600), 1):
        minute = cycle * 5
        checkpoints.append({"cycle": cycle, "file": "src/staged.ts", "view": "split",
                            "pressure": True, "hiddenDuringHold": False,
                            "startedAt": f"2026-10-25T00:{minute:02d}:00+00:00",
                            "endedAt": f"2026-10-25T00:{minute:02d}:16+00:00"})
        phases.append({"checkpointId": cycle, "pressure": True, "errors": [], "valid": False,
                       "timestamp": f"2026-10-25T00:{minute:02d}:10+00:00",
                       "samplingEndedAt": f"2026-10-25T00:{minute:02d}:11+00:00",
                       "samplingStartedElapsedSec": elapsed,
                       "webContentFootprintMb": 200.0, "webContentMallocAllocatedMb": 40.0})
        regular.append({"elapsedSec": elapsed, "rustFootprintMb": 123.0})
    frontend = {"ok": True, "actualDurationSeconds": 1800, "setupSeconds": 1.234,
                "operationsStartedAt": "2026-10-25T00:00:00.000Z",
                "minimalSoakLogging": False, "totalCycles": 4, "totalFileSwitches": 21,
                "totalViewSwitches": 36, "totalScrolls": 99, "totalJumps": 18,
                "checkpointPauseSeconds": 51.75, "visibilityPauseSeconds": 0,
                "phaseCheckpoints": checkpoints}
    return frontend, phases, regular


def progress_records(frontend):
    return [{**item, "cycles": item["cycle"], "fileSwitches": item["cycle"] * 7,
             "viewSwitches": item["cycle"] * 12, "scrolls": item["cycle"] * 33,
             "jumps": item["cycle"] * 6, "checkpointPauseSeconds": item["cycle"] * 17.25,
             "visibilityPauseSeconds": 0}
            for item in frontend["phaseCheckpoints"]]


class FakeProc:
    pid = 4242

    def __init__(self):
        self.returncode = None
        self.polls = 0
        self.calls = []

    def poll(self):
        self.polls += 1
        if self.polls >= 3:
            self.returncode = 0
        return self.returncode

    def terminate(self):
        self.calls.append({"call": "terminate", "mock": True})

    def wait(self, timeout=None):
        self.calls.append({"call": "wait", "timeout": timeout, "mock": True})
        self.returncode = 0
        return 0

    kill = forbidden


def main_case(bench, destination, name):
    directory = destination / name
    directory.mkdir()
    binary = directory / "Revia.app/Contents/MacOS/revia"
    binary.parent.mkdir(parents=True)
    binary.write_bytes(b"mock non-executable binary")
    repo = directory / "fixture"
    repo.mkdir()
    data = directory / "data"
    data.mkdir()
    output = directory / "result.json"
    frontend_path = Path(str(output) + ".frontend.json")
    frontend, _, _ = metadata()
    run_id = f"{frontend['operationsStartedAt']}/{frontend_path}"
    progress = [{"kind": "checkpoint", "runId": run_id, **item}
                for item in progress_records(frontend)]
    anchor = {"kind": "run", "runId": run_id, "outputPath": str(frontend_path),
              "targetSeconds": 1800, "setupSeconds": frontend["setupSeconds"], "repo": str(repo)}
    if name == "missing_final_checkpoints":
        frontend.pop("phaseCheckpoints")
    if name == "missing_all_progress_checkpoints":
        progress = []
    if name == "mismatched_progress_metadata":
        for item in progress:
            item.update(file="src/foreign.ts", view="unified", startedAt="2027-01-01T00:00:00Z",
                        endedAt="2027-01-01T00:00:16Z")
    records = [anchor] + progress
    if name == "duplicate_same_anchor":
        records.insert(1, copy.deepcopy(anchor))
    text = "".join("[SOAK_PROGRESS] " + json.dumps(item) + "\n" for item in records)
    if name == "unterminated_tail":
        text += '[SOAK_PROGRESS] {"kind":"checkpoint"'
    if name == "bad_json_control":
        text += "[SOAK_PROGRESS] {bad json}\n"
    if name == "anchor_path_control":
        text = text.replace(str(frontend_path), "/not-this-run.frontend.json")
    proc = FakeProc()
    counts = {"ps": 0, "vmmap": 0}
    commands = []

    def fake_popen(argv, **kwargs):
        assert argv == [str(binary)]
        assert kwargs["env"]["REVIA_MEASURE_LOG"] == str(frontend_path)
        frontend_path.write_text(json.dumps(frontend))
        frontend_path.with_suffix(".log").write_text(text)
        return proc

    def fake_run(argv, **kwargs):
        commands.append({"argv": argv, "kwargs": kwargs, "mock": True})
        if argv[0] == "launchctl":
            assert argv == ["launchctl", "print", "pid/4242"]
            return subprocess.CompletedProcess(argv, 0, stdout=DOMAIN, stderr="")
        if argv[0] == "ps":
            counts["ps"] += 1
            if ((name == "first_rss_timeout" and counts["ps"] == 1)
                    or (name == "later_rss_timeout" and counts["ps"] == 2)):
                raise subprocess.TimeoutExpired(argv, 5, output=b"partial-ps", stderr=b"partial-ps-error")
            return subprocess.CompletedProcess(argv, 0, stdout=RSS, stderr="")
        if argv[0] == "vmmap":
            counts["vmmap"] += 1
            value = "Physical footprint: 123M\n" if argv[-1] == "4242" else "Physical footprint: 200M\n"
            if name == "webcontent_parse_failure" and argv[-1] == "45":
                value = "Physical footprint missing\n"
            return subprocess.CompletedProcess(argv, 0, stdout=value, stderr="")
        forbidden(argv, kwargs)

    argv = [str(ROOT / "bench-fixed.py"), "--seconds", "1800", "--app", str(directory / "Revia.app"),
            "--repo", str(repo), "--output", str(output)]
    exit_code = exception = None
    with ExitStack() as stack:
        add_guards(stack, bench)
        stack.enter_context(mock.patch.object(bench.subprocess, "Popen", side_effect=fake_popen))
        stack.enter_context(mock.patch.object(bench.subprocess, "run", side_effect=fake_run))
        stack.enter_context(mock.patch.object(bench.time, "monotonic", side_effect=itertools.count(0, 10)))
        stack.enter_context(mock.patch.object(bench.time, "sleep", return_value=None))
        stack.enter_context(mock.patch.object(bench.platform, "system", return_value="Darwin"))
        stack.enter_context(mock.patch.object(bench.platform, "platform", return_value="mocked-platform"))
        stack.enter_context(mock.patch.object(bench.tempfile, "mkdtemp", return_value=str(data)))
        stack.enter_context(mock.patch.object(sys, "argv", argv))
        stream = stack.enter_context((directory / "driver.stdout").open("x"))
        stack.enter_context(redirect_stdout(stream))
        try:
            exit_code = bench.main()
        except Exception as error:
            exception = f"{type(error).__name__}: {error}"
    (directory / "mock-calls.json").write_text(json.dumps({"commands": commands, "processCalls": proc.calls}, indent=2))
    report = json.loads(output.read_text()) if output.exists() else {}
    evidence = Path(str(output) + ".evidence.jsonl").read_text()
    assert "SENTINEL_NEVER_RETAIN" not in evidence
    return {"case": name, "scope": "production main; external boundaries mocked",
            "exit": exit_code, "exception": exception, "reportExists": output.exists(),
            "runCompleted": report.get("runCompleted"), "errors": report.get("errors"),
            "progressProblems": report.get("progressEvidence", {}).get("problems"),
            "tail": report.get("progressEvidence", {}).get("unterminatedTail"),
            "partialCandidates": report.get("partialCandidates"),
            "q98Passed": report.get("q98MemoryVerdict", {}).get("passed"),
            "q98Authoritative": report.get("q98MemoryVerdictAuthoritative")}


def phase_helper_case(bench, destination, name):
    directory = destination / ("helper_" + name)
    directory.mkdir()
    frontend, phases, regular = metadata()
    progress = progress_records(frontend)
    if name == "missing_all_progress_checkpoints":
        progress = []
    elif name == "mismatched_progress_metadata":
        for item in progress:
            item.update(file="src/foreign.ts", view="unified", startedAt="2027-01-01T00:00:00Z",
                        endedAt="2027-01-01T00:00:16Z")
    elif name == "missing_final_checkpoints":
        frontend.pop("phaseCheckpoints")
    (directory / "inputs.json").write_text(json.dumps({"frontend": frontend, "progress": progress,
                                                      "phases": phases, "regular": regular}, indent=2))
    log = directory / "boundaries.log"
    log.write_text("".join(f"[SOAK_CHECKPOINT_END] {cycle}\n" for cycle in (1, 2, 3)))
    with ExitStack() as stack:
        add_guards(stack, bench)
        boundaries = bench.CheckpointLog(log)
        boundaries.poll()
        bench.finalize_phase_samples(phases, boundaries, frontend, progress)
        consistency = bench.progress_consistency_errors(frontend, progress)
        q98 = bench.analyze_q98(regular, phases, 0)
    result = {"case": name, "scope": "production finalize/consistency/analyze_q98 helpers; NOT main",
              "consistencyErrors": consistency, "phaseSources": [item["checkpointSource"] for item in phases],
              "phaseValid": [item["valid"] for item in phases],
              "phaseAuthoritative": [item["authoritative"] for item in phases],
              "q98Passed": q98["passed"], "pressureSampleCount": q98["pressureSampleCount"]}
    (directory / "results.json").write_text(json.dumps({"summary": result, "phases": phases, "q98": q98}, indent=2))
    return result


def cleanup_case(bench, destination):
    directory = destination / "cleanup_failed_kill"
    directory.mkdir()
    path = directory / "evidence.jsonl"
    evidence = bench.CommandEvidence(path)
    observations = []

    class CleanupProc:
        pid = 4242
        returncode = None
        waits = 0

        def snapshot(self, name, timeout="not_applicable"):
            observations.append({"during": name, "timeout": timeout,
                                 "persistedRecords": path.read_text().splitlines() if path.exists() else []})

        def poll(self):
            return self.returncode

        def terminate(self):
            self.snapshot("terminate")

        def kill(self):
            self.snapshot("kill")
            raise OSError("mock kill denied")

        def wait(self, timeout=None):
            self.waits += 1
            self.snapshot("wait" + str(self.waits), timeout)
            if self.waits == 1:
                raise subprocess.TimeoutExpired(["mock-app"], timeout)
            self.returncode = 0
            return 0

    cleanup = {}
    with ExitStack() as stack:
        add_guards(stack, bench)
        bench.terminate_and_record(CleanupProc(), evidence, cleanup, {"WebContent": [45]})
    result = {"scope": "production terminate_and_record helper; every process method mocked",
              "observations": observations, "cleanup": cleanup,
              "finalRecordCount": len(path.read_text().splitlines()),
              "blockingNotExecuted": "second wait returns mock 0; no real waiting or signal"}
    (directory / "result.json").write_text(json.dumps(result, indent=2))
    return result


def command_controls(bench, destination):
    directory = destination / "command_timeout_controls"
    directory.mkdir()
    results = []
    for command in ("ps", "notifyutil"):
        evidence = bench.CommandEvidence(directory / (command + ".evidence.jsonl"))
        timeout = subprocess.TimeoutExpired([command], 5, output=b"partial-out", stderr=b"partial-err")

        def fake_run(argv, **_kwargs):
            if argv[0] == "launchctl":
                return subprocess.CompletedProcess(argv, 0, stdout=DOMAIN, stderr="")
            assert argv[0] == command
            raise timeout

        with ExitStack() as stack:
            add_guards(stack, bench)
            stack.enter_context(mock.patch.object(bench.subprocess, "run", side_effect=fake_run))
            if command == "ps":
                try:
                    bench.sample_memory(4242, evidence)
                except subprocess.TimeoutExpired:
                    pass
            else:
                log = directory / "checkpoint.log"
                log.write_text("[SOAK_CHECKPOINT_BEGIN] 1 pressure\n")
                checkpoints = bench.CheckpointLog(log)
                checkpoints.poll()
                checkpoint = checkpoints.pending.popleft()
                proc = mock.Mock(pid=4242)
                proc.poll.return_value = None
                bench.sample_phase_memory(proc, checkpoints, checkpoint, None, checkpoint["observedAt"], evidence)
        records = [json.loads(line) for line in evidence.path.read_text().splitlines()]
        last = records[-1]
        results.append({"command": command, "exception": last["exception"],
                        "partialStdout": last["partialStdout"], "partialStderr": last["partialStderr"],
                        "scope": "sample_memory" if command == "ps" else "sample_phase_memory"})
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    destination = args.destination.resolve()
    destination.mkdir(exist_ok=False)
    bench = load_driver()
    names = ("valid_progress_control", "bad_json_control", "anchor_path_control",
             "duplicate_same_anchor", "unterminated_tail", "missing_final_checkpoints",
             "missing_all_progress_checkpoints", "mismatched_progress_metadata",
             "first_rss_timeout", "later_rss_timeout", "webcontent_parse_failure")
    results = {"source": SOURCE, "main": [main_case(bench, destination, name) for name in names],
               "phaseHelpers": [phase_helper_case(bench, destination, name) for name in (
                   "valid_progress_control", "missing_final_checkpoints", "missing_all_progress_checkpoints",
                   "mismatched_progress_metadata")],
               "cleanup": cleanup_case(bench, destination), "commandControls": command_controls(bench, destination)}
    for item in results["main"]:
        expected = 0 if item["case"] == "valid_progress_control" else 1
        assert item["exit"] == expected, item
        assert item["runCompleted"] == (expected == 0), item
        if expected:
            assert item["q98Authoritative"] is False, item
        if item["case"] in ("first_rss_timeout", "later_rss_timeout"):
            partial = item["partialCandidates"][0]
            assert "rustRssMb" not in partial and "rustFootprintMb" not in partial, partial
            assert partial["servicesAtFailure"]["WebContent"] == [45], partial
    for item in results["phaseHelpers"]:
        if item["case"] != "valid_progress_control":
            assert item["consistencyErrors"], item
    observed = results["cleanup"]["observations"]
    assert all(item["persistedRecords"] for item in observed), observed
    assert [item["timeout"] for item in observed if item["during"].startswith("wait")] == [5, 5], observed
    (destination / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
