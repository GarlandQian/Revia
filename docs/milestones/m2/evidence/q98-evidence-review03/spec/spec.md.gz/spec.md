# Spec 复核：Codex 接管版

固定范围：`85a2f5c569302ee43af07f0bd768f995478bc2df...ddb9da5bda35162131b3f0011a56303f4937685f`，含获授权的 Q113 流程提交及接管修复。对照 `repair-prompt.md:15` 至 `:20`、`q98-evidence-review01.md`、`q98-evidence-review02.md`、任务10 Comments、M2 spec/benchmark。

**新发现 0；本轴未见阻塞。** 未发现遗漏/错误实现或未授权范围扩张。此结论只针对固定源码的留证与资格修复，不代表 Release、Q98 或 M2 已通过。

## 闭合表

| 项目 | 结论与新源码依据 |
| --- | --- |
| R2-SP1 | 闭合。`tools/bench-long-running.py:328` 拒绝任何第二锚点，`:358` 将尾行列为错误，`:320` 绑定 output/target/fixture，`:987` 接入失败资格；重复同ID、尾行的真实 main 反例均改为 exit1。 |
| R2-SP2 | 闭合。`tools/bench-long-running.py:543` 不再跳过空最终集合，`:565` 核集合，`:575` 核 file/view/时间/压力/遮挡，`:585` 核累计值；`:547` 核操作开始/setup，`:989` 纳入 errors，`:1019` 禁止失败或诊断运行标权威。 |
| R2-SP3 | 闭合。`tools/bench-long-running.py:731`、`:750`、`:761` 在动作前持久化；`:733` 两次 wait 都限5秒，`:777` 保留终态，`:957` 将清理错误带入汇总。mock 边界四次均看到已有记录，失败 kill 后也有界。 |
| R2-SP4 | 闭合。`tools/bench-long-running.py:901` 逐轮初始化，`:186` 在 ps 前保存归属，`:990` 失败候选阻止成功；首次/后续 ps 超时不再串旧值，Rust123 后解析失败仍保全，含自然退出竞态。 |
| 原 SP-Q98-5 | 保持闭合。`tools/bench-long-running.py:191`、`:441` 的实际采样入口保留 ps/notifyutil timeout 双流；归属证据没有凭据哨兵。 |

**真实协议兼容性：** 核对 `src/App.tsx:2103`、`src/App.tsx:2224`、`src/App.tsx:2454`：最终 checkpoint 不含累计字段、增量含累计字段，driver 按最终 totals 核验而非要求两者字段全集相同；Rust 原样传入 output/repo。依此形状构造的正对照 main exit0，未见过严拒绝正常长测协议。

**验证边界：** 一次独立小型 mock 复核成功，脚本执行前保存；真实 main 11例、生产 helper/命令边界另验，源码前后 hash 相同。正对照流程完成但 Q98=false，明确没有混同；错误进度均流程失败且整体非权威。未机械重跑全套，未做 GUI、真实通知/vmmap/信号或长测。原件和作用域详见同目录 `evidence.md`，后续仍须固定新版 Release 后真实桌面/完整30分钟验收；Rust振幅及vmmap255根因未验证。
