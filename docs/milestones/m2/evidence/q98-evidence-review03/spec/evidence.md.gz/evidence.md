# 第三轮 Spec 独立验证原件

## 固定源码

- 比较命令：`git diff 85a2f5c569302ee43af07f0bd768f995478bc2df...ddb9da5bda35162131b3f0011a56303f4937685f`。
- `bench-fixed.py` 是目标提交 driver，blob `c60b106086314151683df82dd91c7391e3630fd8`；与 `git hash-object` 核对一致。
- `test-fixed.py` 和 `App-fixed.tsx` 均由目标提交 `git show` 保存。App blob `f7e781794abe9d81d84a7caa293700dc9abf614e`，本轮没有 App/Rust 产品源码差异。
- 需求沿用本轮 repair-prompt、review01/review02、任务10 Comments 和 M2 spec/benchmark；不根据实施方“检查通过”替代独立判断。Q113流程变更有明确授权，未当作范围扩张。

## 执行原件

`reproduce.py` 由上轮独立 harness 改成新固定版本及实际 App 协议字段，**在本轮执行前已存盘**；`record-run.py` 同时预存。未改旧轮源或原件。

唯一执行：`python3 -B /private/tmp/revia-q98-spec-review03.UD0IJZ/record-run.py`。

- 目录：`execution-ix5h0yfp/`，`tempfile.mkdtemp` 独占分配。
- `invocation-start.json`：执行前 argv/cwd/显式非敏感环境/源码hash/起始时刻。
- `invocation.json`：确切 Python 可执行路径、argv/cwd、起止、exit0、前后hash及原件hash。
- `stdout.txt`、`stderr.txt`：完整原始流；stderr为空。
- `cases/results.json`：完整结果摘要；各 main 目录保存输入报告、前端日志、生产报告/采样/evidence、driver stdout和模拟边界调用。

源码 hash 执行前后相同。没有 GUI、真实 Revia、launchctl/ps/vmmap/notifyutil、真实信号或真实等待。真实子进程仅是记录器启动预存的 Python 验证脚本；受审 driver 的所有命令/进程均模拟。未许可的 subprocess 入口与 os.kill/killpg/system 均显式禁止。

## 独立动态结果

main 的11例实际执行固定版本生产 `main()`，没有替换解析、最终资格、清理、采样或候选保全函数：

| main 用例 | exit / runCompleted / 整体权威 |
| --- | --- |
| 实际 App 字段形状正对照 | 0 / true / true；Q98=false，因本测试没有真实阶段采样，不是长测通过。 |
| 坏JSON、错误输出锚点 | 均 1 / false / false。 |
| 同ID重复锚点、未闭合尾行 | 均 1 / false / false。 |
| 缺最终checkpoint、增量完全无checkpoint、阶段元数据不一致 | 均 1 / false / false。 |
| 首次ps超时、后续ps超时 | 均 1 / false / false；候选保有 WebContent[45] 归属，但没有上一轮 RSS/footprint/timestamp。 |
| Rust123成功、WebContent footprint解析失败 | 1 / false / false；Rust123及错误/归属保留。 |

进程模拟包含采样失败与自然退出交错；错误候选不会因随后exit0被消去。对照的1800秒字段为构造值，不宣称真实运行了1800秒。

阶段 helper 组合通过实际 CheckpointLog、finalize_phase_samples、progress_consistency_errors、analyze_q98：正确三段得一致性空、Q98=true；缺最终报告时权威false/Q98=false；缺增量或时间/文件/视图不符时一致性明确报错。后两者仍可保留 Q98 数值结果true，但 main 已将一致性错误接入 runCompleted及整体权威资格，**不再形成上轮的通过漏洞**。helper结果不冒称完整main的Q98通过。

清理通过真实 `terminate_and_record`：terminate、第一次wait、kill、第二次wait四个模拟边界均观察到动作前记录；两次 timeout 参数均5；kill抛OSError后仍产生终态和共10条清理记录。没有真实阻塞。

ps/notifyutil timeout分别通过真实 `sample_memory` / `sample_phase_memory`，两者均保存partial-out和partial-err；launchctl模拟域含凭据哨兵，生产证据不包含该值。

## 实际 App 格式与静态核对

- `src/App.tsx:2103` 生成 `operationsStartedAt/outputPath` runId；`:2107` 用原 config.repoPath/outputPath和setup。`src-tauri/src/commands.rs:981` 原样传入两项环境路径，与driver resolve后传给子进程的路径匹配。
- `src/App.tsx:2203` 的最终checkpoint只有cycle/file/view/pressure/start/end/hidden及可选IPC；`:2224` 的增量另外带累计负载/暂停。独立正对照故意保持这种非相同字段集合，而不是复用测试中含冗余累计字段的最终checkpoint。
- `src/App.tsx:2454` 的最终暂停值和`:2466`的totals与新driver映射一致。时间用ISO时区字符串，setup同一数值序列化；未见新精度或字段名不匹配。
- 已读新回归：生产main覆盖记录损坏/绑定/不完整报告、首次后续ps、自然退出、解析失败、清理异常；生产清理测试在调用边界读取已落盘step，并验证两次wait timeout=5。没有再执行整套46项。

## 结论边界

本轴新发现0，R2-SP1～4闭合，SP5保持闭合。未验证真实平台故障消失、Rust内存阈值达标、长测负载/UI可见性或Release源码匹配；这些仍需接管版独立双轴通过后由root固定Release执行。未联系Standards代理，未修改仓库。
