# 任务 07 第十轮限定返修检查清单

基线：fc57ab90bc47b93e828823c8dadab5777d52c532
检查前源码 SHA-256：source-sha256-before-check.txt；最终：source-sha256-final2.txt（一致）

## 命令 / 退出码 / 原始输出（最终一轮）

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm bindings（含行尾空白后处理） | 0 | bindings-zz.out / bindings-zz.err / bindings-zz.exit |
| pnpm exec tsc -b | 0 | tsc-zz.out / tsc-zz.exit |
| pnpm lint | 0 | lint-z.out / lint-z.err / lint-z.exit |
| pnpm build | 0 | build-z.out / build-z.err / build-z.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate-zz.out（tests 48 / pass 48 / fail 0） |
| cargo test --test review_marks | 0 | review_marks-z.out / review_marks-z.err / review_marks-z.exit（26 passed） |
| git diff --check | 0 | git-diff-check-z.out / git-diff-check-z.exit |

另跑了 `cargo test --lib`（100 passed），因为改了 review.rs / session.rs。

## 生成绑定行尾空白

原始失败保留：`git-diff-check.out` / `.exit`（exit=2，ReviewMark.ts:10,14 与 ReviewMarks.ts:17,24）。
根因：ts-rs 生成的多行注释排版在行尾留空格，`cargo test --lib` 也会重跑 export_bindings
把绑定写回带空白的版本，所以后处理必须跟在生成之后。
修法：新增 `tools/strip-binding-whitespace.mjs`，并把它接进现有 `pnpm bindings` 脚本。
最终 `git diff --check` 退出 0。

## 敏感性对照（sensitivity/）

按汇总行计数。

| 回退的修复 | exit | tests | pass | fail | 失败用例 |
| --- | --- | --- | --- | --- | --- |
| 2-A-cancel-no-false | exit=101 | — | 25 | 1 | cancel_returns_confirmed_false_with_versions |
| 2-B-invalidation-no-seq | exit=101 | — | 25 | 1 | invalidation_advances_review_seq |
| 2-C-display-raw | exit=1 | 48 | 47 | 1 | 展示按真实进度合成：B(seq1) 回执晚到不能把 A(seq2) 的已审显示掉（ST07-R10-2 / SP07-R10-2） |
| 2-D-no-watermark | exit=1 | 48 | 47 | 1 | 读取水位：读取已观察到该序号时，旧成功不能再覆盖它的真值（ST07-R10-3 / SP07-R10-3） |
| A-cancel-no-false | exit=101 | — | 25 | 1 | cancel_returns_confirmed_false_with_versions |
| B-invalidation-no-seq | exit=101 | — | 25 | 1 | invalidation_advances_review_seq |
| C-display-raw | exit=0 | 48 | 48 | 0 | （无） |
| D-no-watermark | exit=1 | 48 | 47 | 1 | 读取水位：读取已观察到该序号时，旧成功不能再覆盖它的真值（ST07-R10-3 / SP07-R10-3） |

说明：
- 第一轮 `C-display-raw` 只改 App 未触发（当时合成逻辑内联在 App 里，测试没走真实入口）；
  因此把「记账 + 合成」收敛为唯一生产入口 `applyReviewSuccessAndCompose`，
  重跑后 C 组真实失败。两次原件都保留。
- `A-cancel-no-false`、`B-invalidation-no-seq` 是 Rust 真实 Git 套件的失败。
- `D-no-watermark` 是读取水位不参与合并时的失败。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=47f23a6036b846971ca081b6613349bd3050ec62
