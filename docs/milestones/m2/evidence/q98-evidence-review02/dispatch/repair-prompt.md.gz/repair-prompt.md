# M2 Q98 留证第一轮审查返修

业务目标：保证完整有效运行才有资格判定 Q98，通过不了或取证中断时仍保存真实失败、部分数据和清理终态。本轮不是 Rust 内存振幅修复，也不是 M2 验收通过。

## 目录与所有权

所有命令显式在 `/Users/garland/.codex/worktrees/m2-close-finish/Revia` 执行。分支 `m2`，干净基点 `43e4ff51f7466f6ce3db763fa5392b55a2414d5c`。你的默认会话目录是 main，不能在那里实施。规划方已完成审查文档提交，现已停止仓库编辑，你可以开始本轮返修。保留所有已有提交与原件。

继续当前原会话与 `magpie/cpa/deepseek-v4.1-flash` / max。模型顺序以 Q112 为准；前两档已三次独立渠道失败，审查返修不算渠道失败，不回退模型、不切 Gemini。

## 先读及必须修复

先读 `docs/agents/local-validation.md`，然后读 `docs/milestones/m2/q98-evidence-review01.md` 和任务10末尾 Comments。这两处是本轮发现与验收门槛的权威来源，无需重新扩大根因调查。一次性修完 ST-Q98-1 与 SP-Q98-1 至 SP-Q98-5：

1. 增量缺失、坏 JSON、重复锚点或 checkpoint、跨运行、锚点前记录、未闭合尾行均必须阻断最终成功；锚点绑定本轮输出路径和目标，保留未闭合原始尾行。把问题真正接进最终错误资格，不只写诊断字段。
2. 最终报告缺 checkpoint 时不能借增量成为权威样本。诊断样本与验收样本严格分开，完整最终报告与进度必须一致；`frontend.ok` 单独不证明权威或完成。
3. 清理逐步落盘尝试、返回、异常和 wait 结果；terminate/kill/wait 抛异常仍有汇总和终态。区分实际调用、成功返回、信号发送未知，不能提前把调用意图写成已发送，不能从 exit=0 推断没有信号。
4. 常规采样不仅 SubprocessError，解析 RuntimeError 等失败也保留此前取得的 Rust/其他候选值，以及可取得的 poll/PID 归属。
5. ps 和 notifyutil 接统一受控命令留证边界，含 timeout 部分 stdout/stderr。launchctl 仍仅保存必要的 WebKit services 片段并注明裁剪，不落环境秘密；补充边界见 `/private/tmp/revia-q98-resume-chain.keaPgV/ownership-log-boundary.md`。
6. 回归必须真实经过生产 main 或生产清理/候选保全辅助函数，只 mock 外部命令、进程、采样、时钟/信号边界。移除复制生产分支的假覆盖，保持原有效断言。覆盖完整最终报告正对照、缺/坏/重复/跨运行/尾行与缺最终checkpoint、自然退出竞态、terminate/kill/wait异常、解析失败、ps/notifyutil timeout。测试不会启动 GUI、实际发送系统通知或向真实进程发信号。

ST-Q98-2 已后补原件实质闭合，仅精确化历史文案：更早会话只有过滤摘要，完整原始流未留存；后补检查是独立重跑，不回填为原检查。本轮 App 测量源已经改变，旧 Release 仍来自2a51b160，两者分清。

## 范围与检查

允许修改原 `tools/bench-long-running.py`、现有 `tools/test_bench_long_running.py`、`src/App.tsx` 原 soak 分支、确有必要的小测量辅助模块、任务10 Comments 和已有 benchmark 记录格式文档。保持普通 UI、Git/恢复/关闭产品逻辑、Q98 阈值、暖机、负载、窗口和采样间隔不变。Rust +82MiB 振幅仍待定位，不猜测性改缓存。不启动 Release、GUI、D06、CI 或长测，不推送/合并。

改完本轮全部相关内容后集中最小检查：现有 Python unittest、diff-check；若改前端再跑 tsc/lint/build。使用 mktemp/tempfile 新建独占真实路径、自建 fixture/独立应用数据；在执行时逐条保存真实 argv/cwd/显式非敏感 env/起止/exit/完整 stdout/stderr 和源码前后 SHA。失败原件保留，修失败只重跑受影响项；无需全量 Rust 或无关 Node。禁止删除、覆盖、重建来冒充历史失败输出。

按明确文件暂存，新增 m2 提交（不 amend）。在任务10末 Comments 和独占目录报告逐项修复、实际检查与未测边界，Status 保持 ready-for-agent。交付最终 HEAD、改动文件、源码哈希与原件路径后停止，等待 Codex 固定版本双轴复核。
