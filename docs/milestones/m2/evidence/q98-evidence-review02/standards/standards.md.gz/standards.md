# Standards

固定范围：`43e4ff51...85a2f5c5`，仅审这一个提交，未读取后续工作树作为交付事实。

## 文档规范违例

- **P2 / ST-Q98-R2-1：候选保全结论仍未被真实失败入口支持。** `tools/bench-long-running.py:809` 将尚未赋值或上一轮遗留的 `sample` 传入保全函数；`tools/test_bench_long_running.py:879` 总让 `ps` 成功，仅在后面的 vmmap 解析失败处验证候选。隔离驱动真实 `main()`：首次 `ps` 超时变成 `UnboundLocalError`、`partialCandidates=[]`；第二轮超时则把上一轮 RSS、footprint、timestamp 填入本轮失败候选。这不是要求增加覆盖率，而是可复现的丢证/错配。违反 `docs/agents/local-validation.md:8` 的生产入口验证及 `docs/agents/local-validation.md:16` 的结论须对应实际可观察结果；与任务 Comments 第285行“所有异常类型…保留已取得值”不符。每轮开始隔离本轮候选状态，并以两个故障时点做真实入口回归。
- **P3 / ST-Q98-R2-2：删除假测试的陈述不实。** `docs/milestones/m2/issues/10-integrated-verification.md:287` 声称已删除原候选语义假测试，但 `tools/test_bench_long_running.py:606` 仍保留同名测试，仍只顺序调用 RSS/footprint，不检查候选或 poll。违反 `docs/agents/local-validation.md:16` 的结论可核验规则。删除/改名并限缩其说明，或改成所声称的实际入口验证。

## 启发式

- **P3 / possible Duplicated Code：** `tools/test_bench_long_running.py:462` 起新增九个与第318行起同名的测试。AST 有52个测试定义但仅43个唯一名字；后定义静默遮蔽前定义，今后修改前一份不会运行。当前43通过计数属实，但应去掉副本，避免隐藏失效测试。这是判断性 smell，不是硬性格式规则。

## 闭合与证据

ST-Q98-1部分闭合：新增测试确实进入 `main()`，清理函数亦直接覆盖；上述候选缺口及错误删除声明尚在。ST-Q98-2闭合：新增历史更正明确只有过滤摘要，后补时点独立保留。

Pi目录 `/private/tmp/revia-q98-r2.rAebmt` 的30件原件现均匹配manifest；5条调用exit0，Python43，三份源码前/后/提交hash与固定目标一致。root另有一次误追加后恢复事件，不能描述为原件从未被改动；该事件不归为Pi交付错误。

复现：本目录 `reproduce.py`、`reproduction.json`、`reproduction.stdout`、`reproduction.stderr` 及两个 `ps-timeout-*` 子目录；脚本执行前保存，argv/cwd/起止/exit/前后hash齐全，仅mock外部命令、进程、时钟和平台；无真实系统命令/信号、GUI或构建。

本轴：2项文档规范违例（最高P2），1项启发式P3。残余风险：未进行真实桌面或最终长测，不据静态结果判断M2通过。
