#!/usr/bin/env python3
"""Fixed-source review only; application/system boundaries are simulated."""
import ast
from collections import Counter
import contextlib
import datetime
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest import mock

ROOT = Path(__file__).resolve().parent
TARGET = "85a2f5c569302ee43af07f0bd768f995478bc2df"
PI = Path("/private/tmp/revia-q98-r2.rAebmt")
spec = importlib.util.spec_from_file_location("bench", ROOT / "bench-long-running.py")
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)


def run_case(fail_at):
    root = Path(tempfile.mkdtemp(prefix=f"ps-timeout-{fail_at}-", dir=ROOT)).resolve()
    app = root / "Revia.app"
    binary = app / "Contents/MacOS/revia"
    binary.parent.mkdir(parents=True)
    binary.write_bytes(b"inert-test-fixture-not-executed")
    repo = root / "repo"
    repo.mkdir()
    out = root / "run.json"
    counters = Counter()
    proc = mock.Mock(pid=4242)
    proc.returncode = None

    def fake_wait(*args, **kwargs):
        proc.returncode = 0
        return 0

    proc.poll.side_effect = lambda: proc.returncode
    proc.wait.side_effect = fake_wait
    domain = ("pid/4242 = {\n services = {\n 45 - com.apple.WebKit.WebContent.A\n"
              " 47 - com.apple.WebKit.Networking.B\n 46 - com.apple.WebKit.GPU.C\n }\n}")

    def dispatch(argv, **kwargs):
        counters[argv[0]] += 1
        if argv[0] == "ps":
            if counters["ps"] == fail_at:
                raise subprocess.TimeoutExpired(argv, 5, output=b"partial-ps", stderr=b"timed-out")
            text = "4242 102400\n45 204800\n47 51200\n46 61440\n"
        elif argv[0] == "launchctl":
            text = domain
        elif argv[0] == "vmmap":
            text = "Physical footprint: 150.0M\n"
        else:
            raise AssertionError(f"Unexpected external command: {argv}")
        return subprocess.CompletedProcess(argv, 0, text, "")

    def fake_popen(*args, **kwargs):
        anchor = {"kind": "run", "runId": "r1", "targetSeconds": 60,
                  "outputPath": str(out) + ".frontend.json"}
        Path(str(out) + ".frontend.log").write_text(
            "[SOAK_PROGRESS] " + json.dumps(anchor) + "\n")
        return proc

    clock = iter(float(i * 10) for i in range(1000))
    argv = ["bench-long-running.py", "--seconds", "60", "--interval", "10",
            "--app", str(app), "--repo", str(repo), "--output", str(out)]
    captured = io.StringIO()
    with mock.patch("sys.argv", argv), \
            mock.patch.object(bench.subprocess, "Popen", side_effect=fake_popen), \
            mock.patch.object(bench.subprocess, "run", side_effect=dispatch), \
            mock.patch.object(bench.subprocess, "check_output", side_effect=AssertionError("Unaudited external call")), \
            mock.patch.object(bench.time, "monotonic", side_effect=lambda: next(clock)), \
            mock.patch.object(bench.time, "sleep"), \
            mock.patch.object(bench.platform, "system", return_value="Darwin"), \
            mock.patch.object(bench.platform, "platform", return_value="mock-platform"), \
            contextlib.redirect_stdout(captured):
        code = bench.main()
    (root / "main-stdout.txt").write_text(captured.getvalue())
    report = json.loads(out.read_text())
    result = {"case": fail_at, "output": str(out), "simulatedArgv": argv, "code": code,
              "errors": report["errors"], "partialCandidates": report["partialCandidates"],
              "memoryTimeSeries": report["memoryTimeSeries"], "externalCommandCounts": dict(counters),
              "simulatedTerminateCalls": proc.terminate.call_count,
              "simulatedKillCalls": proc.kill.call_count}
    print(json.dumps(result, ensure_ascii=False))
    return result


def main():
    tempfile.tempdir = str(ROOT)
    first = run_case(1)
    later = run_case(2)
    assert any("UnboundLocalError" in error for error in first["errors"])
    assert first["partialCandidates"] == []
    assert len(later["memoryTimeSeries"]) == 1
    assert later["partialCandidates"][0]["timestamp"] == later["memoryTimeSeries"][0]["timestamp"]
    assert later["partialCandidates"][0]["rustRssMb"] == later["memoryTimeSeries"][0]["rustRssMb"]

    tree = ast.parse((ROOT / "test_bench_long_running.py").read_text())
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef))
    names = [node.name for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
    duplicate_names = {name: count for name, count in Counter(names).items() if count > 1}
    print(json.dumps({"testDefinitions": len(names), "uniqueTests": len(set(names)),
                      "duplicatedNames": duplicate_names}, indent=2))
    manifest = json.loads((PI / "manifest.json").read_text())
    mismatches = []
    for entry in manifest["files"]:
        raw = (PI / entry["file"]).read_bytes()
        if len(raw) != entry["bytes"] or hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            mismatches.append(entry["file"])
    print(json.dumps({"piManifestFileCount": len(manifest["files"]), "piManifestMismatches": mismatches,
                      "piInvocations": len(json.loads((PI / "invocations.json").read_text()))}))
    assert not mismatches


if __name__ == "__main__":
    main()
