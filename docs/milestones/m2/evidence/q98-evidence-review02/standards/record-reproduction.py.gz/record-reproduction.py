#!/usr/bin/env python3
"""One read-only review invocation; never writes to the Pi evidence directory."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
argv = [sys.executable, "-B", str(root / "reproduce.py")]
hashes = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
          for name in ("reproduce.py", "record-reproduction.py", "bench-long-running.py", "test_bench_long_running.py")}
started = datetime.datetime.now().astimezone().isoformat()
begin = time.monotonic()
with (root / "reproduction.stdout").open("xb") as stdout, (root / "reproduction.stderr").open("xb") as stderr:
    completed = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr,
                               env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": str(root)})
record = {"argv": argv, "cwd": str(root), "startedAt": started,
          "endedAt": datetime.datetime.now().astimezone().isoformat(),
          "durationSeconds": time.monotonic() - begin, "exitCode": completed.returncode,
          "stdout": "reproduction.stdout", "stderr": "reproduction.stderr",
          "environmentOverrides": {"PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": str(root)},
          "sourceSha256Before": hashes,
          "sourceSha256After": {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in hashes}}
with (root / "reproduction.json").open("x") as handle:
    json.dump(record, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps(record, ensure_ascii=False, indent=2))
sys.exit(completed.returncode)
