# Spec 复审：85a2f5c

固定 `43e4ff51f7466f6ce3db763fa5392b55a2414d5c...85a2f5c569302ee43af07f0bd768f995478bc2df`。结论：**仍不通过，4 项（2 P1、2 P2）**；无范围扩张，未改阈值、暖机、负载或 Rust。

## 发现

1. **R2-SP1 / P1：重复锚点、截断尾行仍成功。** `tools/bench-long-running.py:285` 只拒绝不同 runId 的第二锚点；`:311` 返回尾行却不报错。真实 main 的同 runId 重复、尾行两例均 exit0、`runCompleted=true`。违反 `repair-prompt.md:15`：“重复锚点……未闭合尾行均必须阻断最终成功”。测试 `tools/test_bench_long_running.py:735` 只测不同 runId，`:774` 反而断言尾行无问题。

2. **R2-SP2 / P1：最终报告与进度仍可不一致。** `tools/bench-long-running.py:498` 任一 checkpoint 集合为空便跳过核对，`:512` 只比较压力/遮挡，漏 file/view/真实起止。main 在全部进度 checkpoint 缺失或元数据相矛盾时仍 exit0；生产 helper 组合仍将对应三段判权威、Q98=true（**非完整 main 的内存通过复现**）。缺最终 checkpoint 的 main 亦 exit0，但该例 Q98=false。违反 `repair-prompt.md:16`“完整最终报告与进度必须一致”及 `q98-evidence-review01.md` SP-Q98-2“最终报告缺checkpoint必须失败”。

3. **R2-SP3 / P2：清理未逐步落盘，失败 kill 后可能卡住。** `tools/bench-long-running.py:669` 在 kill 抛错后仍无期限 wait；`:682` 才唯一落盘。生产 helper 的 mock 边界观察显示 terminate、两次 wait、kill 时均无清理记录，第二次 wait 无 timeout。违反 `repair-prompt.md:17`“清理逐步落盘……抛异常仍有汇总和终态”。实际阻塞为代码推论，未执行真实等待/信号。

4. **R2-SP4 / P2：新增候选调用复用未初始化/旧 sample。** `tools/bench-long-running.py:809` 的 sample 只在成功采样后赋值；首次 ps 超时实际 main 报 `UnboundLocalError`、部分候选为空；第二轮 ps 超时则把上一轮 Rust/WebContent footprint 伪附到新候选。违反 `repair-prompt.md:18`“保留此前取得的……候选值”和原授权“失败候选已取得的部分数据单独保存”。原 vmmap 解析失败已修，不抵消该新回归。

## 旧项闭合

| 旧项 | 结论 |
| --- | --- |
| SP-Q98-1 | 部分：坏 JSON、错输出锚点会失败；见 R2-SP1。 |
| SP-Q98-2 | 部分：非权威样本不再计入 Q98；一致性及最终完整性未闭合，见 R2-SP2。 |
| SP-Q98-3 | 部分：返回/异常/未知区分改善；逐步持久化未闭合，见 R2-SP3。 |
| SP-Q98-4 | 原例闭合：Rust123 后 WebContent 解析失败可保全；新调用回归见 R2-SP4。 |
| SP-Q98-5 | 闭合：生产 sample_memory/sample_phase_memory 的 ps/notifyutil timeout 原始流保全，凭据哨兵不外泄。 |

复现脚本执行前已保存，仅 mock 外部命令、进程、信号/时钟等边界。一次最小复现退出0、源码 hash 未变；不等于被审代码通过。完整原件及作用域见 `evidence.md`。未运行全套测试、GUI、Release 或长测；`runCompleted` 与 Q98 内存判定分开记录，未混同。
