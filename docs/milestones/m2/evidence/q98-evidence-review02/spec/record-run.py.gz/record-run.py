#!/usr/bin/env python3
"""Record one isolated reproduction, retaining complete streams and source hashes."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time


root = Path(__file__).resolve().parent
execution = Path(tempfile.mkdtemp(prefix="execution-", dir=root)).resolve()
argv = [sys.executable, "-B", str(root / "reproduce.py"), str(execution / "cases")]
cwd = Path("/Users/garland/.codex/worktrees/m2-close-finish/Revia")
sources = ("bench-fixed.py", "test-fixed.py", "App-fixed.tsx", "reproduce.py", "record-run.py")


def hashes():
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sources}


metadata = {"argv": argv, "cwd": str(cwd), "explicitEnv": {"PYTHONDONTWRITEBYTECODE": "1"},
            "sourceCommit": "85a2f5c569302ee43af07f0bd768f995478bc2df", "hashBefore": hashes(),
            "startedAt": datetime.datetime.now().astimezone().isoformat()}
(execution / "invocation-start.json").write_text(json.dumps(metadata, indent=2) + "\n")
start = time.monotonic()
with (execution / "stdout.txt").open("xb") as stdout, (execution / "stderr.txt").open("xb") as stderr:
    completed = subprocess.run(argv, cwd=cwd, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
                               stdout=stdout, stderr=stderr, timeout=30)
metadata.update(endedAt=datetime.datetime.now().astimezone().isoformat(),
                elapsedSeconds=time.monotonic() - start, exit=completed.returncode, hashAfter=hashes())
metadata["artifactHashes"] = {str(path.relative_to(execution)): hashlib.sha256(path.read_bytes()).hexdigest()
                              for path in sorted(execution.rglob("*")) if path.is_file()}
(execution / "invocation.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps({"execution": str(execution), "exit": completed.returncode,
                  "sourceUnchanged": metadata["hashBefore"] == metadata["hashAfter"]}))
sys.exit(completed.returncode)
