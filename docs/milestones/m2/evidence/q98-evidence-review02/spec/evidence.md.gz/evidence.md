# 固定提交复现原件

## 版本与执行

- 审查范围：`git diff 43e4ff51f7466f6ce3db763fa5392b55a2414d5c...85a2f5c569302ee43af07f0bd768f995478bc2df`。
- 固定 driver：`bench-fixed.py`，Git blob `97499a51d4431e9baac787e997f838392e11b59e`，与目标提交 `tools/bench-long-running.py` 一致。
- 固定测试：`test-fixed.py`，Git blob `c399fd2563384e7110039e39c0d2eefa508eab62`，与目标提交 `tools/test_bench_long_running.py` 一致。
- 前端协议源：`App-fixed.tsx`，来自目标提交；本轮 diff 未改 App。锚点确实使用 `config.outputPath` 与目标秒数。
- 预先保存的执行源码：`reproduce.py`，记录器：`record-run.py`。不是事后重建。
- 唯一执行目录：`execution-akx4b8l_/`，由 `tempfile.mkdtemp` 分配；包含实际 argv/cwd、显式非敏感 env、起止、exit、完整 stdout/stderr、源码前后 SHA-256 与各原件 hash。
- 实际运行：`python3 -B /private/tmp/revia-q98-spec-review02.WF0fvy/record-run.py`。记录器启动的确切 Python 可执行路径及参数见 `execution-akx4b8l_/invocation.json`。退出0，源码前后哈希一致。原件没有覆盖旧轮证据。

## 边界

`main` 用例加载固定 driver，实际执行其 `main()`；没有替换 parser、ProgressLog、completion_errors、finalize_phase_samples、analyze_q98、sample_memory、footprint、清理或保全函数。只模拟 subprocess.run/Popen、假进程方法、时间、platform 和本轮独立数据目录分配；未许可的命令及 os.kill/killpg/system 均设为禁止边界。假二进制不具备可执行内容，fixture/应用数据均新建在该执行目录内。

前端最终报告与增量日志是本测试构造的数据，不声称真正执行了1800秒。main 的进度资格用例不生成实时阶段采样，故其 Q98=false 不构成另一个发现；`runCompleted` 仅按流程资格解释。完整阶段资格由另行标注的生产 helper 组合验证，绝不冒称其走完整 main。

## 结果摘要

完整 JSON：`execution-akx4b8l_/cases/results.json`。每个 main 用例有报告、前端输入、evidence、标准输出、真实生产采样日志与模拟边界调用记录。

| 用例 | 真实入口 | 可观察结果 |
| --- | --- | --- |
| valid_progress_control | main | exit0 / runCompleted=true；Q98=false（没有阶段样本）。 |
| bad_json_control | main | exit1 / runCompleted=false，坏 JSON 进入 errors。 |
| anchor_path_control | main | exit1 / runCompleted=false，输出路径不匹配进入 errors。 |
| duplicate_same_anchor | main | 两个相同 runId 锚点，problems=[]、exit0 / runCompleted=true。 |
| unterminated_tail | main | 尾部 `[SOAK_PROGRESS] {"kind":"checkpoint"` 被保留，却 problems=[]、exit0 / runCompleted=true。 |
| missing_final_checkpoints | main | 最终报告无 phaseCheckpoints、进度含三段；exit0 / runCompleted=true，Q98=false、整体非权威。 |
| missing_all_progress_checkpoints | main | 最终报告含三段，进度仅锚点；exit0 / runCompleted=true。 |
| mismatched_progress_metadata | main | 进度 file/view/start/end 与最终报告不符，仍 exit0 / runCompleted=true。 |
| first_rss_timeout | main | 首个 ps 超时原始流已存，外层 errors 却是 UnboundLocalError，partialCandidates=[]。 |
| later_rss_timeout | main | 新候选 elapsed=80 带上一轮 elapsed=10 取得的 Rust123/WebContent200 footprint；当轮 ps 没有成功值。进程自然退出使 main exit0；本报告以旧值串候选为新增发现，不将 Q98=false 误当内存通过。 |
| webcontent_parse_failure | main | Rust123 保留在 partialCandidates，RuntimeError、poll、services 均保留；旧 SP-Q98-4 原例已闭合。 |

## 阶段 helper 组合

入口为实际 `CheckpointLog`、`finalize_phase_samples`、`progress_consistency_errors`、`analyze_q98`。END 使用本次新建的边界日志，输入阶段采样明确为构造数据；输入/输出保存于四个 `helper_*` 目录。

- 正对照：最终与进度相同，三段 valid/authoritative=true，Q98=true。
- 缺最终 checkpoint：三段标 progress-log/authoritative=false，Q98=false、压力点0；旧“增量借权威”路径已受阻。
- 最终三段但增量完全没有 checkpoint：consistencyErrors=[]，三段 valid/authoritative=true，Q98=true。
- 增量同 cycle/pressure/hidden，但 file=`src/foreign.ts`、view=`unified`、时间为2027年；最终是 src/staged.ts/split/2026年：consistencyErrors=[]，仍三段 valid/authoritative=true，Q98=true。

这两项反例证明一致性门槛遗漏；Q98=true 是 helper 组合结论，不是完整 main 输出的 Q98=true。

## 清理与命令边界

`cleanup_failed_kill/result.json`：实际调用生产 `terminate_and_record`。模拟 terminate 返回、首个 wait 超时、kill 抛 OSError、第二个 wait 返回0。每个方法进入时读取磁盘 journal：四次均空；第二个 wait 的 timeout 为 null；函数完成后只有一条 cleanup。没有真实阻塞，只有代码的无界 wait 风险推论，模拟返回只为可终止地采集边界事实。

`command_timeout_controls/`：ps 通过实际 sample_memory，notifyutil 通过实际 sample_phase_memory（不是只直接测记录器）；两者均保留 `partial-out`/`partial-err`。launchctl 测试域含凭据哨兵，生产证据不含该哨兵。

## 回归用例审阅

- `tools/test_bench_long_running.py:725` 名称称 production main，但正文只调用 ProgressLog.read；same-runId 重复未覆盖（`:735` 换成 r2）。
- `tools/test_bench_long_running.py:774` 将尾行 `problems=[]` 作为通过断言，与返修要求冲突。
- `tools/test_bench_long_running.py:949` 的“完整报告正对照”输入实际没有 phaseCheckpoints，日志也只有锚点，因此保护了不完整流程仍成功的行为。
- `tools/test_bench_long_running.py:669` 确实调用生产清理，但 `:672` 只要求最终一条记录，不检查方法调用过程中已落盘，也不覆盖第二次 wait 不能返回的情形。
- `tools/test_bench_long_running.py:932` 确实经过 main 并测到 vmmap 解析失败后的候选；没有覆盖 first/later RSS 失败触发 `sample` 未初始化或复用。

上述测试缺口用于解释四项 Spec 发现，没有合并或代替另一轴 Standards 结论。未联系 Standards 代理，未以实施方43项通过结论替代代码/实际入口证据。
