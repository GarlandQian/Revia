# M2 Q98 留证第一轮审查返修：交付报告（待双轴复核）

**不是 M2/Q98 通过报告。** 本轮只修测量工具的成功资格与失败留证；未定位或修复
vmmap exit 255 的系统根因，未处理 Rust +82 MiB 振幅，两轮历史长测仍为失败。

## 提交

| 项 | 值 |
| --- | --- |
| 分支 | `m2`（`/Users/garland/.codex/worktrees/m2-close-finish/Revia`） |
| 基点 | `43e4ff51f7466f6ce3db763fa5392b55a2414d5c` |
| 本轮提交 | **`85a2f5c569302ee43af07f0bd768f995478bc2df`** |
| 改动 | 3 文件，+738 / −130 |
| 状态 | tracked clean（忽略 `.codex/`）；未 amend、未推送、未合并 |
| App 测量源 | 当前工作区 `src/App.tsx`（本轮未改） |
| 受测 Release | 仍为 `2a51b160…` 构建，二进制 `fd5ffc86…696988d`，**未重建** |

改动文件：`tools/bench-long-running.py`、`tools/test_bench_long_running.py`、
`docs/milestones/m2/issues/10-integrated-verification.md`。

## 逐项修复

### SP-Q98-1 / P1：增量损坏必须阻断成功

- `progress_problems` **进入 `errors`**（前缀「前端进度记录问题：」），不再是只读诊断字段。
- 新增 `progress_consistency_errors`：最终报告与进度并存时校验 cycle 集合、
  压力标记、`hiddenDuringHold` 一致，不一致同样进入 `errors`。
- `ProgressLog.read(expected_output, expected_target)` 绑定**本轮输出路径**
  （`config.outputPath`，即 `REVIA_MEASURE_LOG`）与**目标秒数**，不匹配即失败。
- 缺锚点、第二锚点、锚点前记录、跨运行、重复 cycle、未闭合、未知类型、坏 JSON
  全部计入 `problems`。
- **未终止尾行原文保留**在 `progressEvidence.unterminatedTail`，不解析为进度。

### SP-Q98-2 / P1：不完整报告不得借增量取得权威

- `finalize_phase_samples` 仅在**最终报告含非空 `phaseCheckpoints`** 时产出权威样本；
  否则 `authoritative=false`，且最终报告缺 checkpoint 时直接追加错误。
- `analyze_q98` **只统计 `authoritative` 的压力后样本**，进度派生的样本无法进入验收。
- `q98MemoryVerdictAuthoritative` 要求 `ok=true` **且**最终报告含 checkpoint；
  非权威时控制台只打印诊断错误，不表述为「通过」。
- 正/负对照均有测试：同一阶段样本在「最终报告」下 `valid+authoritative`，
  在「仅进度」下不 valid 且不能提供验收压力点。

### SP-Q98-3 / P2：清理异常不再丢失证据

生产函数 `terminate_and_record(proc, evidence, cleanup, services)`：

- 分别记录**尝试**（`terminateAttempted` / `killAttempted`）、
  **返回**（`terminateReturned` / `killReturned`）、**异常**
  （`terminateError` / `waitAfterTerminateError` / `killError` / `waitAfterKillError`）、
  `wait` 结果与 `pollAfterCleanup`。
- `signalDelivery` 只写 `unknown` / `not_attempted`；**不从退出码推断是否发过信号**。
- `finally` 外层再兜底记录，连 `evidence.record` 失败也不吞掉终态。

### SP-Q98-4 / P2：解析失败保留部分候选

生产函数 `preserve_partial_candidate(...)` 捕获**所有异常类型**：
`RuntimeError`（vmmap 退出 0 但缺 footprint 行）、`CalledProcessError`、`TimeoutExpired`。
已取得的 RSS/footprint 与可观测的 `pollAtFailure`/`reviaPid`/`servicesAtFailure`
一并写入 `partialCandidates` 与 `*.evidence.jsonl`。

### SP-Q98-5 / P2：命令留证覆盖完整

- `ps`、`notifyutil` 统一走 `CommandEvidence.run`：记录 argv/purpose/起止/退出或异常，
  `TimeoutExpired` 保留 `partialStdout`/`partialStderr`，`OSError` 单独记录。
- `run_timeout` 已并入 `run`，**不存在第二条未受控命令路径**。
- `launchctl` 仍只保留 WebKit services 行并写明裁剪原因，不落环境秘密。

### ST-Q98-1 / P2：回归真实经过生产路径

- 新增 `_run_production_main` 驱动**真实 `bench.main()`**，只 mock 外部边界
  （`subprocess.Popen`/`run`、`launchctl_ownership`、时钟、`platform`）：
  1. 坏进度 / 缺锚点 + `ok=true` 最终报告 → **仍失败**，错误含「进度记录」；
  2. vmmap 输出无 footprint → 失败，但 `partialCandidates` 保留 `rustRssMb` 等，
     `cleanup` 含 `terminateAttempted` 与 `pollAfterCleanup`，`*.evidence.jsonl` 存在；
  3. 完整报告 + 干净进度 → **成功**（正对照）。
- 清理与候选保全另由生产函数 `terminate_and_record`、`preserve_partial_candidate`
  直接覆盖（含 `already_exited`、`terminate_ok`、`wait_timeout_kill_ok`、
  `terminate_raises`、`wait_raises`、`kill_raises` 六种情形）。
- **已删除**原先复制清理分支与候选语义的假测试。

## 检查（一次集中运行）

独占目录：**`/private/tmp/revia-q98-r2.rAebmt`**
（`record.py` 在执行时记录真实 argv/cwd/显式非敏感 env/起止/exit/完整 stdout+stderr，
汇总 `invocations.json`）。

| 命令 | 退出码 | 结果 | 原件 |
| --- | --- | --- | --- |
| `python3 tools/test_bench_long_running.py` | 0 | **43 passed** | `01-python-unittest.*` |
| `pnpm exec tsc -b` | 0 | — | `02-tsc.*` |
| `pnpm lint` | 0 | 仅既存 warning | `03-lint.*` |
| `pnpm build` | 0 | — | `04-build.*` |
| `git diff --check` | 0 | 无输出 | `05-diff-check.*` |

受测源码 SHA-256 检查前后与提交后三次一致
（`tested-source-sha256-before/after.txt`、`committed-source-sha256.txt`）：

| 文件 | SHA-256 |
| --- | --- |
| `tools/bench-long-running.py` | `58f1f7e5…7f1adfbd` |
| `tools/test_bench_long_running.py` | `23510924…de04b4cf` |
| `src/App.tsx` | `7d6c6253…f950b0be`（本轮未改） |

未跑全量 Rust 或无关 Node；未做 GUI / Release / D06 / CI / 长测。

## 首次失败（保留，不覆盖）

1. 新增 `ProgressLog` 测试仍用旧的 3 元组解包 → `ValueError: too many values to unpack`；
   改为 4 元组（新增 `tail`），断言未变。
2. 清理测试中 `Mock.wait()` 返回 `Mock`，`json.dumps` 无法序列化 → 设为返回 `0`
   （真实返回值形状），断言未变。
3. `main()` 正对照最初把 fixture 写进驱动日志而非前端日志；生产读的是
   `REVIA_MEASURE_LOG` 换扩展名后的 `.frontend.log` → 修正写入位置。
4. 锚点路径比较暴露 macOS `/var` 与 `/private/var` 别名 → 测试改用 `resolve()` 后的路径；
   **生产仍保持严格比较**（不一致即失败，fail-closed）。
5. 既有 `test_q98_verdict_…` 的 `phase()` 需补 `authoritative: True`（最终报告样本的
   真实形状），**断言未改**。

## 未测边界

- 未启动 GUI、未发送真实 `notifyutil` 系统通知、未向任何真实进程发送信号。
- vmmap exit 255 的系统根因仍未确定；本轮只保证下次失败有完整原件。
- Rust 热身后 footprint `maxRise 82.0 MiB > 10 MiB` 仍单列待定位，
  **未**改缓存/分配、未挑首点、未延长暖机、未减少负载。
- 增量记录依赖 `ipc.debugLog`，Rust 侧仍吞写日志错误；缺记录时驱动明确失败，
  但「写失败静默」这一 Rust 行为不在本轮授权范围。
- WebContent footprint / malloc 仍缺有效压力后样本（0 个，要求 ≥3）。

## 边界声明

- 未改 Q98 阈值、暖机、负载、采样窗口/间隔、既有 fixtures、old evidence、`main`、`m2-ui`。
- 未操作真实用户仓库/配置/凭据；测试只在本轮独占临时目录内，外部边界全部 mock。
- 任务 10 保持 `ready-for-agent`；M2 未完成、未合 main、未启动 M3。
- 提交后停止，等待 Codex 固定版本双轴复核；通过后才由规划方固定新 Release
  与完整 30 分钟长测。
