import ast
from pathlib import Path
import textwrap

path = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia/tools/test_bench_long_running.py')


def replace(name, body):
    source = path.read_text()
    tree = ast.parse(source)
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef))
    method = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == name)
    lines = source.splitlines(True)
    lines[method.lineno - 1:method.end_lineno] = [textwrap.indent(textwrap.dedent(body).strip(), '    ') + '\n']
    path.write_text(''.join(lines))


replace('_run_production_main', '''
def _run_production_main(self, directory, frontend=None, log_text=None, polls=None,
                         vmmap_text=None, ps_fail_at=None, process_setup=None):
    """Drive actual main() with only OS/process/clock/allocation boundaries mocked."""
    root = Path(directory)
    app = root / "Revia.app"
    (app / "Contents" / "MacOS").mkdir(parents=True)
    (app / "Contents" / "MacOS" / "revia").write_bytes(b"fake build")
    repo, data = root / "repo", root / "data"
    repo.mkdir()
    data.mkdir()
    out = root / "run.json"
    domain = ("pid/4242 = {\\n services = {\\n 45 - com.apple.WebKit.WebContent.A\\n"
              " 47 - com.apple.WebKit.Networking.B\\n 46 - com.apple.WebKit.GPU.C\\n }\\n}")
    ps_calls = 0

    def dispatch(argv, **kwargs):
        nonlocal ps_calls
        if argv[0] == "launchctl":
            text = domain
        elif argv[0] == "ps":
            ps_calls += 1
            if ps_calls == ps_fail_at:
                raise bench.subprocess.TimeoutExpired(argv, 5, output=b"partial ps", stderr=b"timeout")
            text = "4242 100\\n45 200\\n47 50\\n46 60\\n"
        else:
            text = vmmap_text if vmmap_text is not None else VMMAP_SAMPLE
        return bench.subprocess.CompletedProcess(argv, 0, text, "")

    proc = mock.Mock(pid=4242)
    proc.poll.side_effect = list(polls if polls is not None else [None, None, None, 0]) + [0] * 100
    proc.wait.return_value = 0
    proc.returncode = 0
    if process_setup:
        process_setup(proc)
    clock = iter(float(i) for i in range(4000))
    argv = ["bench-long-running.py", "--seconds", "60", "--interval", "10",
            "--app", str(app), "--repo", str(repo), "--output", str(out)]

    def fake_popen(*args, **kwargs):
        body = log_text(out, repo) if callable(log_text) else log_text
        if body is None and frontend is not None:
            body = "".join(f"[SOAK_PROGRESS] {json.dumps(record)}\\n"
                           for record in clean_progress(frontend, out, repo))
        if body is not None:
            Path(str(out) + ".frontend.log").write_text(body)
        if frontend is not None:
            Path(str(out) + ".frontend.json").write_text(json.dumps(frontend))
        return proc

    with mock.patch("sys.argv", argv), \\
            mock.patch.object(bench.subprocess, "Popen", side_effect=fake_popen), \\
            mock.patch.object(bench.subprocess, "run", side_effect=dispatch), \\
            mock.patch.object(bench.tempfile, "mkdtemp", return_value=str(data)), \\
            mock.patch.object(bench.time, "monotonic", side_effect=lambda: next(clock)), \\
            mock.patch.object(bench.time, "sleep"), \\
            mock.patch.object(bench.platform, "platform", return_value="test-platform"), \\
            mock.patch.object(bench.platform, "system", return_value="Darwin"), \\
            mock.patch("builtins.print"):
        code = bench.main()
    return code, out
''')

replace('test_sample_failure_keeps_partial_candidate_and_polls_app', '''
def test_sample_failure_keeps_partial_candidate_and_polls_app(self):
    """First/subsequent ps failures must preserve this attempt, never previous RSS."""
    for failure_at in (1, 2):
        with self.subTest(failure_at=failure_at), tempfile.TemporaryDirectory() as directory:
            code, out = self._run_production_main(directory, completed_frontend(),
                                                 ps_fail_at=failure_at, polls=[None] * 10 + [0])
            report = json.loads(out.read_text())
            self.assertEqual(code, 1)
            self.assertFalse(report["runCompleted"])
            self.assertFalse(report["q98MemoryVerdictAuthoritative"])
            kept = report["partialCandidates"][0]
            self.assertIn("TimeoutExpired", kept["failure"])
            self.assertNotIn("UnboundLocalError", " ".join(report["errors"]))
            for field in ("rustRssMb", "rustFootprintMb", "timestamp"):
                self.assertNotIn(field, kept)
            self.assertEqual(kept["servicesAtFailure"]["WebContent"], [45])
            if failure_at == 2:
                self.assertIn("rustFootprintMb", report["memoryTimeSeries"][0])
            records = [json.loads(line) for line in Path(report["commandEvidence"]).read_text().splitlines()]
            failure = next(row for row in records if row.get("exception") == "TimeoutExpired")
            self.assertEqual(failure["partialStdout"], "partial ps")
            self.assertEqual(failure["partialStderr"], "timeout")
''')

replace('test_progress_problems_block_success_in_production_main', '''
def test_progress_problems_block_success_in_production_main(self):
    cases = ("bad_json", "duplicate_anchor", "foreign_anchor", "duplicate_cycle", "cross_run",
             "before_anchor", "unclosed", "tail", "unknown_kind", "missing_anchor",
             "missing_progress_checkpoint", "wrong_output", "wrong_target", "wrong_repo",
             "wrong_file", "wrong_view", "wrong_start", "wrong_end", "wrong_pause", "missing_counter")
    for case in cases:
        with self.subTest(case=case), tempfile.TemporaryDirectory() as directory:
            frontend = completed_frontend()

            def corrupted(out, repo):
                records = clean_progress(frontend, out, repo)
                if case == "duplicate_anchor": records.insert(1, dict(records[0]))
                elif case == "foreign_anchor": records.insert(1, {**records[0], "runId": "other"})
                elif case == "duplicate_cycle": records.append(dict(records[-1]))
                elif case == "cross_run": records[-1]["runId"] = "other"
                elif case == "before_anchor": records.reverse()
                elif case == "unclosed": records[-1].pop("endedAt")
                elif case == "unknown_kind": records[-1]["kind"] = "unknown"
                elif case == "missing_anchor": records.pop(0)
                elif case == "missing_progress_checkpoint": records.pop()
                elif case == "wrong_output": records[0]["outputPath"] = "other"
                elif case == "wrong_target": records[0]["targetSeconds"] = 1800
                elif case == "wrong_repo": records[0]["repo"] = "other"
                elif case == "wrong_file": records[-1]["file"] = "other.ts"
                elif case == "wrong_view": records[-1]["view"] = "unified"
                elif case == "wrong_start": records[-1]["startedAt"] = "2026-10-25T08:00:02Z"
                elif case == "wrong_end": records[-1]["endedAt"] = "2026-10-25T08:00:05Z"
                elif case == "wrong_pause": records[-1]["checkpointPauseSeconds"] = 999
                elif case == "missing_counter": records[-1].pop("scrolls")
                text = "".join(f"[SOAK_PROGRESS] {json.dumps(record)}\\n" for record in records)
                if case == "bad_json": text += "[SOAK_PROGRESS] {bad\\n"
                if case == "tail": text += '[SOAK_PROGRESS] {"kind":"checkpoint"'
                return text

            code, out = self._run_production_main(directory, frontend, corrupted)
            report = json.loads(out.read_text())
            self.assertEqual(code, 1, case)
            self.assertFalse(report["runCompleted"], case)
            self.assertFalse(report["q98MemoryVerdictAuthoritative"], case)
            self.assertTrue(any("进度" in error for error in report["errors"]), report["errors"])
            if case == "tail": self.assertTrue(report["progressEvidence"]["unterminatedTail"])
''')

replace('test_final_report_and_progress_must_agree', '''
def test_final_report_and_progress_must_agree(self):
    frontend = completed_frontend()
    report = frontend["phaseCheckpoints"]
    progress = [dict(record) for record in report]
    self.assertEqual(bench.progress_consistency_errors(frontend, progress), [])
    self.assertTrue(bench.progress_consistency_errors(frontend, []))
    self.assertTrue(bench.progress_consistency_errors({}, progress))
    for field, value in (("pressure", True), ("hiddenDuringHold", True), ("file", "other.ts"),
                         ("view", "unified"), ("startedAt", "2026-10-25T08:00:02Z"),
                         ("endedAt", "2026-10-25T08:00:05Z")):
        with self.subTest(field=field):
            changed = [{**progress[0], field: value}]
            self.assertTrue(bench.progress_consistency_errors(frontend, changed))
''')

replace('test_terminate_and_record_covers_success_timeout_and_raising_wait', '''
def test_terminate_and_record_covers_success_timeout_and_raising_wait(self):
    cases = ("already_exited", "terminate_ok", "wait_timeout_kill_ok", "terminate_raises",
             "wait_raises", "kill_raises", "kill_wait_raises", "kill_wait_timeout", "poll_raises")
    for case in cases:
        with self.subTest(case=case), tempfile.TemporaryDirectory() as directory:
            journal = Path(directory) / "evidence.jsonl"
            proc = mock.Mock(pid=99)
            cleanup = {}
            proc.poll.side_effect = [OSError("poll failed") if case == "poll_raises" else
                                     (0 if case == "already_exited" else None), 0]

            def require_step(step):
                record = json.loads(journal.read_text().splitlines()[-1])
                self.assertEqual(record["step"], step)

            def terminate():
                require_step("terminate-attempt")
                if case == "terminate_raises": raise OSError("terminate failed")

            def kill():
                require_step("kill-attempt")
                if case == "kill_raises": raise OSError("kill failed")

            waits = 0
            def wait(timeout):
                nonlocal waits
                self.assertEqual(timeout, 5)
                waits += 1
                require_step("wait-after-terminate-attempt" if waits == 1 else "wait-after-kill-attempt")
                if waits == 1:
                    if case == "wait_raises": raise OSError("wait failed")
                    if case in ("wait_timeout_kill_ok", "kill_raises", "kill_wait_raises", "kill_wait_timeout"):
                        raise bench.subprocess.TimeoutExpired(["mock"], timeout)
                elif case == "kill_wait_raises": raise OSError("wait after kill failed")
                elif case == "kill_wait_timeout": raise bench.subprocess.TimeoutExpired(["mock"], timeout)
                return 0

            proc.terminate.side_effect, proc.kill.side_effect, proc.wait.side_effect = terminate, kill, wait
            bench.terminate_and_record(proc, bench.CommandEvidence(journal), cleanup, {"WebContent": [45]})
            records = [json.loads(line) for line in journal.read_text().splitlines()]
            record = records[-1]
            self.assertEqual(record["step"], "final")
            self.assertEqual(record["pollAfterCleanup"], 0)
            if case in ("already_exited", "poll_raises"):
                self.assertFalse(record["terminateAttempted"])
                proc.terminate.assert_not_called()
                proc.wait.assert_not_called()
            else:
                self.assertTrue(record["terminateAttempted"])
                self.assertEqual(record["signalDelivery"], "unknown")
                if case == "terminate_raises": self.assertFalse(record["terminateReturned"])
                if case == "wait_timeout_kill_ok": self.assertEqual(record["waitAfterKill"], 0)
                if case == "kill_raises": self.assertFalse(record["killReturned"])
                if case in ("wait_raises", "kill_wait_raises", "kill_wait_timeout"):
                    self.assertTrue(record["errors"])
''')

replace('test_production_main_completes_with_full_report_and_clean_progress', '''
def test_production_main_completes_with_full_report_and_clean_progress(self):
    """Flow completion is a control, not a claim of 30-minute/Q98 acceptance."""
    with tempfile.TemporaryDirectory() as directory:
        code, out = self._run_production_main(directory, completed_frontend())
        report = json.loads(out.read_text())
        self.assertEqual(code, 0, report["errors"])
        self.assertTrue(report["runCompleted"])
        self.assertFalse(report["cleanup"]["terminateAttempted"])
        self.assertEqual(report["progressEvidence"]["problems"], [])
        self.assertFalse(report["q98MemoryVerdict"]["passed"], "60-second mocks cannot pass Q98")
''')

# Tail retention remains tested, but a retained incomplete line is no longer accepted.
source = path.read_text()
source = source.replace('self.assertEqual(problems, [])\n            self.assertEqual(tail,',
                        'self.assertTrue(problems)\n            self.assertEqual(tail,')
old = 'self.assertEqual([item["cycle"] for item in closed], [1])\n            self.assertEqual(problems, [])'
new = 'self.assertEqual([item["cycle"] for item in closed], [1])\n            self.assertTrue(any("尾行未闭合" in item for item in problems))'
assert old in source
source = source.replace(old, new, 1)
while '\n\n\n\n' in source:
    source = source.replace('\n\n\n\n', '\n\n\n')
path.write_text(source)
