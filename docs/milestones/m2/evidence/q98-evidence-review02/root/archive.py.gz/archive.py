from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil
import subprocess

root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
run = Path('/private/tmp/revia-q98-root-takeover.3EEtAR')
shutil.copy2(run / 'review02.md', root / 'docs/milestones/m2/q98-evidence-review02.md')
task = root / 'docs/milestones/m2/issues/10-integrated-verification.md'
with task.open('a', encoding='utf-8') as handle:
    handle.write('\n' + (run / 'task10-comment.md').read_text(encoding='utf-8'))
report = root / 'docs/milestones/m2/report.md'
text = report.read_text(encoding='utf-8')
old = next(line for line in text.splitlines() if line.startswith('- **Q98') and '0a2d842' in line)
report.write_text(text.replace(old, (run / 'report-current-line.md').read_text(encoding='utf-8').strip(), 1), encoding='utf-8')
(run / 'root-fix.patch').write_bytes(subprocess.check_output([
    'git', 'diff', '--', 'tools/bench-long-running.py', 'tools/test_bench_long_running.py',
    'docs/milestones/m2/benchmark.md'], cwd=root))
archive = root / 'docs/milestones/m2/evidence/q98-evidence-review02'
assert not archive.exists()
archive.mkdir(parents=True)
roots = {
    'pi': Path('/private/tmp/revia-q98-r2.rAebmt'),
    'standards': Path('/private/tmp/revia-q98-r2-standards.NqHnlm'),
    'spec': Path('/private/tmp/revia-q98-spec-review02.WF0fvy'),
    'root': run,
    'dispatch': Path('/private/tmp/revia-q98-review01-repair.ENWD8s'),
}
entries, excluded = [], []
for label, base in roots.items():
    for source in sorted(base.rglob('*')):
        if not source.is_file():
            continue
        relative = source.relative_to(base)
        if source.is_symlink() or '__pycache__' in relative.parts or any(part.endswith('.app') for part in relative.parts):
            excluded.append({'source': str(source), 'reason': 'Mock executable/cache/symlink; not original command evidence'})
            continue
        raw = source.read_bytes()
        destination = archive / label / (str(relative) + '.gz')
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(gzip.compress(raw, mtime=0))
        assert gzip.decompress(destination.read_bytes()) == raw
        entries.append({'source': str(source), 'archive': str(destination.relative_to(archive)),
                        'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
manifest = {
    'recordedAt': datetime.datetime.now().astimezone().isoformat(),
    'piReviewBase': '43e4ff51f7466f6ce3db763fa5392b55a2414d5c',
    'piReviewTarget': '85a2f5c569302ee43af07f0bd768f995478bc2df',
    'rootWorkingBase': '22809f2',
    'note': 'Pi review failed; root code checked but awaiting independent fixed-version review. '
            'Pi/reproduction/root evidence kept separate. Root append-and-restore event is recorded, not attributed to Pi.',
    'fileCount': len(entries), 'files': entries, 'excluded': excluded,
}
(archive / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Archived and verified', len(entries), 'files; excluded', len(excluded))
