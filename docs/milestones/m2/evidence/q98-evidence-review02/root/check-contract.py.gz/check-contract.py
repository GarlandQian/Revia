import ast
import collections
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
baseline = '85a2f5c569302ee43af07f0bd768f995478bc2df'
paths = ('tools/bench-long-running.py', 'tools/test_bench_long_running.py', 'src/App.tsx')
hashes = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in paths}


def source_at(name):
    return subprocess.check_output(['git', 'show', f'{baseline}:{name}'], cwd=root)


def constants(source):
    tree = ast.parse(source)
    names = {'PHASE_HOLD_SECONDS', 'PRESSURE_HOLD_SECONDS', 'PRESSURE_SETTLE_SECONDS',
             'Q98_WARMUP_SECONDS', 'Q98_MAX_RISE_MB', 'Q98_MAX_SLOPE_MB_PER_MINUTE',
             'Q98_MIN_PRESSURE_SAMPLES'}
    return {node.targets[0].id: ast.literal_eval(node.value) for node in tree.body
            if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in names}


before = constants(source_at(paths[0]))
after = constants((root / paths[0]).read_bytes())
assert before == after
assert source_at('src/App.tsx') == (root / 'src/App.tsx').read_bytes()
tree = ast.parse((root / paths[1]).read_bytes())
cls = next(node for node in tree.body if isinstance(node, ast.ClassDef))
names = [node.name for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
duplicates = {name: count for name, count in collections.Counter(names).items() if count != 1}
assert not duplicates, duplicates
print(json.dumps({'baseline': baseline, 'sourceSha256': hashes, 'q98ConstantsUnchanged': after,
                  'appMeasurementSourceUnchanged': True, 'testDefinitions': len(names),
                  'uniqueTests': len(set(names)), 'duplicateMethods': duplicates}, indent=2))
