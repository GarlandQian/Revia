# 任务 07 R07-D1 + R07-CI01 检查清单

基线：4915f6df3f01e90a5053b5da481a754976d2fa6b
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out / refresh-gate.err / refresh-gate.exit（24 项通过） |
| cargo test --test review_marks | 0 | review_marks.out / review_marks.err / review_marks.exit（21 项通过） |

只跑了受影响检查：R07-D1 是前端（tsc/lint/build + 既有 Node 契约测试），
R07-CI01 是测试夹具路径（只跑 review_marks），未重跑完整 Rust。

## 失败历史

R07-CI01 的三处失败来自规划方 CI（Windows，固定 8f95c26）：
`deinitialized_submodule_is_not_confirmed_and_cannot_be_claimed`、
`packed_refs_symbolic_branch_switch_invalidates_submodule_mark`、
`submodule_with_directory_git_dir_tracks_real_version`，
都失败在 `git submodule add <临时源目录>`——Windows 上 canonicalize 给出 verbatim 路径
`\\?\C:\...`，Git 报 `hostname contains invalid characters`。
本机（macOS）无法复现，修复只能靠新 CI 验证；本轮未声称已修好 Windows。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
