# 任务 07 R07-D1 + R07-CI01 检查清单

基线：4915f6df3f01e90a5053b5da481a754976d2fa6b

## 日志目录历史（如实说明）

1. 最初创建的目录：`/private/tmp/revia-task07-r7-4kxrhu`。
   该目录**只写入了** `base-sha.txt` / `changed-files.txt` / `source-sha256-before-check.txt`，
   当时**没有任何检查执行**（尚未跑 tsc/lint/build）。随后我发现 App.tsx 还没接入叠加层，
   需要继续改代码，于是删掉了这个只含元数据的目录，改用新的独占目录重跑。
   其内容已不可提供；它从未包含任何检查输出，因此不影响任何结论。未核该目录是否有其他残留。
2. 第一次真正跑完五份检查的目录：`/private/tmp/revia-task07-r7b-xHHPNF`。
   tsc/lint/build/refresh-gate/review_marks 五份 exit 均为 0（Node 24 项、Rust review_marks 21 项）。
   **原件完整保留**，未删除、未覆盖。
3. 之后我做了一处代码调整（把 `ReviewOverlay.apply` 的泛型从 `E extends ReviewMarkEntryLike`
   改为 `S extends ReviewSnapshotLike<...>`，去掉调用点的 `as ChangesSnapshot` 断言），
   源码因此变化，`r7b` 的检查不再对应最终源码，于是在新目录重跑全部五项：
   `/private/tmp/revia-task07-r7c-gqdxcj`（本清单所在目录）。所有交付结论以这个目录为准。

## 命令 / 退出码 / 原始输出（最终源码）

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out / refresh-gate.err / refresh-gate.exit（24 项通过） |
| cargo test --test review_marks | 0 | review_marks.out / review_marks.err / review_marks.exit（21 项通过） |

只跑受影响检查：R07-D1 是前端（tsc/lint/build + 既有 Node 契约测试），
R07-CI01 是测试夹具路径（只跑 review_marks）。未重跑完整 Rust，未新增前端测试框架。

## 失败历史

- R07-D1：无失败运行。缺陷是真实桌面观察到的时序（较早读取覆盖较新的审阅结果），
  本机未重做桌面复现；新增的 Node 契约测试是**先写测试后验证实现**，一次通过，
  没有留下"先红后绿"的失败记录，不冒称已做敏感性对照。
- R07-CI01：三处失败来自规划方 Windows CI（固定 8f95c26），本机 macOS 无法复现。
  修复只能由下一轮 SSH 推送的新 CI 验证，本轮不声称 Windows 已通过。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=f93fd2e281fcd6bd1644c782258bce02758777c5
