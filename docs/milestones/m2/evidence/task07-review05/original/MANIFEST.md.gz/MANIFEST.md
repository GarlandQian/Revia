# 任务 07 第四轮复核返修检查清单

基线：4f5cb0835cb8ff11f5114455c44daec49f968b70
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| cargo test --test review_marks | 0 | review_marks.out / review_marks.err / review_marks.exit（21 passed） |

本轮改动只涉及前端入口与 `review_marks` 测试，未改共享生产代码，因此按交接要求只跑
`review_marks` 与前端三项，未重跑完整 Rust 套件。上一轮完整 Rust 原始输出为
**252 passed / 1 ignored**（规划方已更正，我上轮写的 251 合计有误）。

## 失败历史（保留）

本轮新用例先失败、随后修好，原因都是**用例设计**问题而非产品缺陷：

1. `unrelated_head_change_keeps_mark_when_file_versions_unchanged` 首次失败：
   用 `f.commit()`（`git add --all`）把 a.txt 的未暂存改动一起提交了，导致 a.txt 离开改动列表。
   改为只 `git add -- other.txt` 再提交。
2. `submodule_with_directory_git_dir_tracks_real_version` 首次失败两次：
   (a) 检出基线提交会与父仓库 gitlink 一致，`sub` 离开改动列表；
   (b) 用普通 clone 替换子模块目录后，父仓库不再把它当子模块。
   最终改为保留真实 submodule，把指针型 `.git` 内容搬进 `sub/.git` 成为**真实目录**并清掉
   `core.worktree`，再检出两个都偏离基线的提交。
3. `packed_refs_symbolic_branch_switch_invalidates_submodule_mark` 首次失败：
   `pack-refs --all` 只打包已存在的引用，而 branch-b 还没在子模块 clone 里创建。
   改为先 `fetch` 再 `branch --force` 建两个分支后打包。

## 临时实验目录

本轮全部临时仓库与数据目录都由 `tempfile::TempDir` / `mktemp -d` 独占创建；
未再触碰 `/tmp/t-deinit`、`/tmp/nl-test` 这两个既有固定名路径，也未清理或覆盖它们。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
桌面行为未验证。
commit=88fe98e51ed9eb1f69eae13b081d9d0f9a72e354
