#!/usr/bin/env python3
"""按真实 argv 执行并逐条落盘：argv/cwd/env 覆盖/start/end/exit/stdout/stderr。

不使用固定指针文件；日志目录由调用方传入。
"""
import json, os, subprocess, sys, time

log = sys.argv[1]
commands = json.loads(sys.argv[2])
cwd = "/Users/garland/.codex/worktrees/m2-close-finish/Revia"
# 只记录与构建/测试相关的最小环境，不读取凭据。
env_overrides = {"CI": "1", "NO_COLOR": "1"}
base_env = {"PATH": os.environ.get("PATH", ""), "HOME": os.environ.get("HOME", "")}
base_env.update(env_overrides)

index = []
for i, argv in enumerate(commands):
    stem = f"{i:02d}-{argv[0].replace('/', '_')}-{argv[1].replace('/', '_') if len(argv) > 1 else ''}"
    started = time.time()
    proc = subprocess.run(argv, cwd=cwd, env={**base_env}, capture_output=True, text=True)
    ended = time.time()
    open(os.path.join(log, f"{stem}.out"), "w").write(proc.stdout)
    open(os.path.join(log, f"{stem}.err"), "w").write(proc.stderr)
    open(os.path.join(log, f"{stem}.exit"), "w").write(f"{proc.returncode}\n")
    index.append({
        "stem": stem,
        "argv": argv,
        "cwd": cwd,
        "env_overrides": env_overrides,
        "started_at": started,
        "ended_at": ended,
        "exit": proc.returncode,
    })
    print(f"{stem}: exit={proc.returncode}")
open(os.path.join(log, "invocations.json"), "w").write(json.dumps(index, indent=2))
