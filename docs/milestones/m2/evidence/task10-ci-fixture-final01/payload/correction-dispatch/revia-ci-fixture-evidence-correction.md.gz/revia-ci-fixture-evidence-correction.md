# review_marks CI修复：只更正文档边界，不改实现/不重测

在 /Users/garland/.codex/worktrees/m2-close-finish/Revia 的 m2 分支接续 d952a857b3faef2a4101ab5a6582217bd5a7c8e0。main和m2-ui均不动；你的Paseo cwd仍可能是main，所有命令显式指定上述m2目录。

独立Standards / Spec 对代码无确定缺陷，但发现 docs/milestones/m2/issues/10-integrated-verification.md 两处交付记录不准确：
1. 第106行“恢复三行后同一条件→通过”缺修复版+相同useConfigOnly条件的实际独立原件。最终31通过测试源码采用空fixture全局配置，不是同条件正对照。请更正为实施方此前报告过，但当前原件不足以独立确认；不以此否认运行曾发生。另需明确 sensitivity/pre-fix.out 的外层配置被env_clear覆盖，旧代码通过，是无效对照；pre-fix-useconfigonly.out 是修前在fixture内部配置下的实际身份失败原件。保留所有历史失败/无效证据，不再重测。
2. 第133行称未隔离HOME notify离线失败101的00-*.err已保留，但现存根目录及最终子目录的该组文件均为成功，invocations.json记录也不支持该表述。请明确此失败仅此前实施方描述，对应原件现在缺失、无法独立核对。已承认的早期删除事实必须保留，不补造输出或命令。

只编辑上面任务10文档，保留已核最终31/0及SHA和Windows待实际CI边界；可修正错误句并在末Comments注明两轴审查与更正来源。完整审查：/private/tmp/revia-ci-fixture-standards-1PUoKq/standards.md 和 /private/tmp/revia-ci-fixture-spec-btOIT5/spec-review.md。
不改生产、测试源码，不运行cargo/前端/GUI，不启动或改验收fixture，不推送。文档完成只做git diff --check，保存真实输出/退出，在m2按精确该路径提交一次，回报commit及clean状态。不要删除任何已有文件。
