## Spec

固定 `2a51b160d1c3871b9c67fee81ae6f082910bc1f8...d952a857b3faef2a4101ab5a6582217bd5a7c8e0`；唯一提交 `d952a85`、2 文件，工作树干净。仅静态复核源码和现存原件，未运行测试、GUI或修改仓库。

- **SP-CI-1 / P3 / 敏感性通过陈述超出原件**：派发 `/private/tmp/revia-m2-ui-merge-yk2t6656/pi-windows-fixture-repair.md:35` 要求“追加准确检查范围、原件路径、实现理由和未测边界”。`docs/milestones/m2/issues/10-integrated-verification.md:106` 称“恢复三行后同一条件 → 通过”，但指定 `sensitivity/` 仅有修前通过、强制身份配置后失败的输出，没有修后同条件通过原件。最终受测源码 `src-tauri/tests/review_marks.rs:36` 写入空配置，`:46` 与 `:855` 覆盖并隔离外层 Git 配置，因此常规31项通过不能证明 `user.useConfigOnly=true` 对照通过。应降为未独立核实，不把普通验证当同条件正对照；这不否定修复代码。

- **SP-CI-2 / P3 / 失败原件归档描述不准确**：派发同文件 `:34` 要求记录“原始stdout/stderr”。`docs/milestones/m2/issues/10-integrated-verification.md:133` 声称未隔离 HOME 的 `notify` 离线失败、退出101及 `00-*.err` 保留，但指定目录内两组现存 `00-*.err` 均为成功编译输出；根目录 `invocations.json:16` 明确隔离 HOME，`:25` 为退出0。未找到对应失败原件。应明确该次原件当前缺失／不可核对，不能用成功日志指代；不据此否认失败曾发生。

其他核对：源码 `:893` 只配置自建临时子模块本地身份及禁签名，符合派发 `:25`；`:904`、`:913`、`:924`、`:929`、`:936` 保留 gitlink、deinit拒绝及reinit不恢复断言，未跳过或放宽。T10/T12无新增回退。旧Windows日志 `:974`、`:995` 可核身份失败及28/1；最终本机31/0原件和源码SHA一致。任务10 `:139` 仍明确Windows待实际CI，未冒充D07通过。

计数：要求缺失／部分 **0**；范围扩张 **0**；错误实现（交付记录）**2**。最高严重度 **P3**；未见确定代码功能缺陷。
