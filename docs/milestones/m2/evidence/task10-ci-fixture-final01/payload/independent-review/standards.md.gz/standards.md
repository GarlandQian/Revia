## Standards

固定 `2a51b160d1c3871b9c67fee81ae6f082910bc1f8...d952a857b3faef2a4101ab5a6582217bd5a7c8e0`；唯一提交 `d952a85`、2 文件，HEAD/分支及干净工作树均已核对。已读指定规范；`CLAUDE.md` 转引 `AGENTS.md`，未发现 `CONTRIBUTING.md` / `CODING_STANDARDS.md`。

- **ST-CI-1 / P2：敏感性正对照结论超出留存证据。** `docs/milestones/m2/issues/10-integrated-verification.md:106` 称恢复三行后“同一条件”通过，但 `sensitivity/` 只留有撤修后 `useConfigOnly` 失败、普通撤修通过及修复源码快照，没有修复后同条件运行原件。最终31项成功使用空全局配置，且 fixture 自建空配置并清空继承环境，不能充当该正对照。违反 `docs/agents/local-validation.md:9` 的原始流保存要求及 `docs/agents/local-validation.md:16` 的结论对应实际结果要求。应补实际原件，或明确此项未独立核实；不据缺件断言从未运行。
- **ST-CI-2 / P3：失败日志“已保留”的描述不实。** `docs/milestones/m2/issues/10-integrated-verification.md:133` 称 `notify` 离线失败（101）的 `00-*.err` 保留；实际根目录和最终子目录的该组日志及 `invocations.json` 都是成功（0），指定目录搜不到该失败原件。依据 `docs/agents/local-validation.md:9`“既有证据保留”，需如实补记该失败证据也缺失，不把成功日志算作失败原件；已披露首轮删除的事实应保留，不能重造。

代码方面未发现确定违规：`src-tauri/tests/review_marks.rs:893` 的配置仅写自建子模块，仍用真实 Git，安全断言未变。已核最终 macOS 31 passed、exit 0、前后及提交源码 SHA 一致；Windows 仍待实际 CI，未提前宣称通过。本审查未运行测试、GUI或编辑仓库。

结论：确定问题 **2**（P2×1、P3×1，均为证据报告边界）；Fowler 启发式建议 **0**。少量 fixture 配置重复不值得为本次最小修复引入抽象。
