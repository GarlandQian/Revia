#!/usr/bin/env python3
"""按真实 argv 执行并逐条落盘（本任务版）：额外转发 CARGO_HOME 以便 HOME 隔离时仍可用离线缓存。

用法: record2.py <logdir> <commands-json> <extra-env-json>
"""
import json, os, subprocess, sys, time

log, commands_json, extra_json = sys.argv[1], sys.argv[2], sys.argv[3]
commands = json.loads(commands_json)
extra_env = json.loads(extra_json)
cwd = "/Users/garland/.codex/worktrees/m2-close-finish/Revia"
base_env = {
    "PATH": os.environ.get("PATH", ""),
    "HOME": extra_env.get("HOME", os.environ.get("HOME", "")),
    "GIT_CONFIG_GLOBAL": extra_env.get("GIT_CONFIG_GLOBAL", ""),
    "GIT_CONFIG_NOSYSTEM": extra_env.get("GIT_CONFIG_NOSYSTEM", "1"),
    "CARGO_HOME": os.environ.get("CARGO_HOME", os.path.join(os.environ.get("HOME", ""), ".cargo")),
    "CARGO_NET_OFFLINE": "true",
    "NO_COLOR": "1",
}

index = []
for i, argv in enumerate(commands):
    stem = f"{i:02d}-{argv[0].replace('/', '_')}-{argv[1].replace('/', '_') if len(argv) > 1 else ''}"
    started = time.time()
    proc = subprocess.run(argv, cwd=cwd, env=base_env, capture_output=True, text=True)
    ended = time.time()
    open(os.path.join(log, f"{stem}.out"), "w").write(proc.stdout)
    open(os.path.join(log, f"{stem}.err"), "w").write(proc.stderr)
    open(os.path.join(log, f"{stem}.exit"), "w").write(f"{proc.returncode}\n")
    index.append({
        "stem": stem, "argv": argv, "cwd": cwd,
        "env_overrides": {k: v for k, v in base_env.items() if k != "PATH"},
        "started_at": started, "ended_at": ended, "exit": proc.returncode,
    })
    print(f"{stem}: exit={proc.returncode}")
open(os.path.join(log, "invocations.json"), "w").write(json.dumps(index, indent=2))
