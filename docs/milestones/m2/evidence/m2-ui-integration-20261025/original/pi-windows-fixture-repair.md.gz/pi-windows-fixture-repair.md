# M2 集成 CI 定点修复：审阅子模块 fixture 的提交身份

你是既有 Pi 实施方。此任务不是任务08，也不恢复任务08派发。用户已要求把 m2-ui 合入 m2，随后没有问题才进入 M3；m2-ui 已安全快进合入。本次仅修复真实 Windows CI 暴露的测试 fixture 问题，不降低验收门槛。

## 工作目录与允许范围

- 每条命令显式 cwd `/Users/garland/.codex/worktrees/m2-close-finish/Revia`。当前分支必须为 `m2`，起始 HEAD `2a51b160d1c3871b9c67fee81ae6f082910bc1f8`，工作树干净；先核对。如果不符且有未知改动，停止报告。
- **不要在会话默认 cwd `/Volumes/T7 Shield/project/Revia` 中编辑、切分支或提交。** main 含用户的图标、AGENTS、配置等改动，全部保留。
- `/Volumes/T7 Shield/project/Revia-m2-ui` 有仍在运行的固定桌面验收，完全不得编辑、构建或运行测试。
- 允许修改 `src-tauri/tests/review_marks.rs`，以及在 `docs/milestones/m2/issues/10-integrated-verification.md` 的 Comments 末尾追加本次限定修复/检查交接。原则上不需要生产代码修改；若发现必须改变产品契约或其他范围，先报告，不自行扩大。
- 不改用户 Git 全局/系统/项目配置，不删除 index.lock，不运行 reset/checkout/restore/amend，不动已有 fixture。测试只能使用当前已有 tempfile 隔离体系。
- 只提交上述明确文件到 m2；不要合并、推送、开PR、打标签、发布、构建Release、启动GUI、运行D06或长测。不要把任何待验收任务标done。

## 真实失败与业务目的

固定2a51的 Compile Check：
`https://github.com/GarlandQian/Revia/actions/runs/40172283582`

Windows job `121105479132` 的真实完整日志已保存：
`/private/tmp/revia-m2-ui-merge-yk2t6656/windows-job-121105479132.log`

前端类型、lint、build通过。Rust `review_marks` 运行29项，28通过、1失败：
`deinitialized_submodule_is_not_confirmed_and_cannot_be_claimed` 在测试内 `git commit -m two` 报 `Author identity unknown`，断言位置 `review_marks.rs:860`。Windows Release 编译因而被跳过。

源码中 source 仓库设置了本地 user.name/user.email/commit.gpgsign，但克隆出的 `f.repo/sub` 在创建第二个提交前没有身份；仓库本地config不会随clone继承。请核对原件并做最小修复，让这个既有真实Git回归的临时子模块提交身份和禁用签名确定，不依赖宿主是否可推断身份。

业务安全断言必须保持：子模块gitlink改动仍显示；deinit后未知检出内容不能继续认领/新增审阅标记；重新init也不凭空恢复旧标记。不要用cfg(windows)跳过、ignore、宽松断言或伪Git结果让CI变绿。

## 验证与交付

1. 先读仓库 AGENTS.md、`docs/agents/local-validation.md`、任务07/10相关Comments和现有fixture。完成全部相关修改后一次集中验证。
2. 只跑受影响的现有 `review_marks` 集成测试（`/opt/homebrew/bin/cargo test --manifest-path src-tauri/Cargo.toml --offline --locked --test review_marks`）；使用隔离临时HOME/Git配置，不继承真实用户配置；不要机械重跑前端、全量Rust或新建框架。
3. 如Rust生成绑定有空白，只用现有 `tools/strip-binding-whitespace.mjs` 还原生成字节，确认没有未授权生成物改动；运行 `git diff --check`。
4. mktemp独占目录记录实际路径、固定前后SHA、真实argv/cwd、明确非敏感环境、开始/结束、退出码、原始stdout/stderr。不把本机通过写成Windows通过；Windows必须由规划方再次推m2后的实际CI验证。
5. 在任务10 Comments追加准确检查范围、原件路径、实现理由和未测边界；明确旧CI失败保留。精确暂存允许文件并新建独立提交，不amend。
6. 回报提交SHA、diff范围、检查结果/日志路径。不要重试或触碰桌面恢复/退出流程，不做M3。

本轮Q105照常：遇渠道错误保留已有改动，规划方会按同任务连续三次错误规则处理；不要切模型。
