import gzip
import hashlib
import json
from pathlib import Path
import subprocess

source = Path('/private/tmp/revia-task13-watch-mw6eybl6')
repo = Path('/Volumes/T7 Shield/project/Revia-m2-ui')
head = (source / 'source.txt').read_text().strip()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == head
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
state = json.loads((source / 'exit.json').read_text())
assert state['exitCode'] == 0 and all(state[key] for key in ['binaryUnchanged', 'sourceUnchanged', 'fixtureStatusAndIndexEntriesUnchanged'])
target = repo / 'docs/milestones/m2/evidence/task13-desktop03'
target.mkdir(exist_ok=False)
files = sorted(p for p in source.iterdir() if p.is_file()) + [source / 'data/settings.json', source / 'data/watch-failure.txt']
entries = []
for path in files:
    relative = path.relative_to(source)
    raw = path.read_bytes()
    compress = path.suffix != '.png'
    stored = target / 'original' / (str(relative) + ('.gz' if compress else ''))
    stored.parent.mkdir(parents=True, exist_ok=True)
    data = gzip.compress(raw, mtime=0) if compress else raw
    stored.write_bytes(data)
    assert (gzip.decompress(stored.read_bytes()) if compress else stored.read_bytes()) == raw
    entries.append(dict(source=str(path), stored=str(stored.relative_to(target)), gzip=compress,
                        sourceBytes=len(raw), storedBytes=len(data), sourceSha256=hashlib.sha256(raw).hexdigest(), storedSha256=hashlib.sha256(data).hexdigest()))
(target / 'manifest.json').write_text(json.dumps(dict(sourceCommit='6b3ddf5d3046e5745e65c81076806bbda441b359', launchCommit=head,
    binarySha256='b0b2a64e324cda9156a301fd73b9e823094942eb0c16b31691ca758a956efb61',
    boundary='Existing Rust watch_failure injection, light visible UI only, no external fixture change or product Git write, not full Q95 or final M2 acceptance.',files=entries),ensure_ascii=False,indent=2)+'\n')
(repo / 'docs/milestones/m2/task13-desktop03.md').write_bytes((source / 'task13-desktop03.md').read_bytes())
issue = repo / 'docs/milestones/m2/issues/13-ui-polish.md'
issue.write_bytes(issue.read_bytes() + (source / 'task13-comment.md').read_bytes())
print('archived', len(entries), 'files')
