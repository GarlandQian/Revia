import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/Volumes/T7 Shield/project/Revia-m2-ui')
head = '35da167f8a2202b19a211ade2c311f5ff430cd90'

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])

assert git('rev-parse', 'HEAD').decode().strip() == head
assert git('status', '--porcelain', '--untracked-files=no') == b''

def edit(path, before, after):
    target = repo / path
    text = target.read_text()
    assert text.count(before) == 1, (path, before)
    target.write_text(text.replace(before, after, 1))

edit('src/lib/platform.ts',
     '/** 判断是否在输入类控件（<input>, <textarea>, [contenteditable]）或弹窗内，让出快捷键避免穿透（Q93、审查意见 6）。 */',
     '/** 输入、选择控件或弹窗保留自己的键盘行为，不触发后台操作（Q93）。 */')
edit('src/lib/platform.ts', '    tag === "textarea" ||', '    tag === "textarea" ||\n    tag === "select" ||')

edit('src/features/diff/DiffView.tsx', '          tone={tone}\n          marker=', '          tone={tone}\n          kind={row.lineKind ?? "context"}\n          marker=')
edit('src/features/diff/DiffView.tsx', '  tone,\n  marker,', '  tone,\n  kind,\n  marker,')
edit('src/features/diff/DiffView.tsx', '  tone: LineTone;\n  marker: string;', '  tone: LineTone;\n  kind: RowCell["kind"];\n  marker: string;')
edit('src/features/diff/DiffView.tsx',
     '    <span className={tone ? `cell cell-${tone}` : "cell"}>\n      <span className="marker">{marker}</span>',
     '    <span className={`cell cell-${kind}${tone ? ` cell-${tone}` : ""}`}>\n      <span className="marker">{marker}</span>')
edit('src/features/diff/DiffView.tsx',
     '    <span className={tone ? `cell cell-${tone}` : "cell"}>\n      <span className="marker">{markerFor(cell.kind)}</span>',
     '    <span className={`cell cell-${cell.kind}${tone ? ` cell-${tone}` : ""}`}>\n      <span className="marker">{markerFor(cell.kind)}</span>')
edit('src/lib/jumpDomProbe.ts',
     '    const cells = view === "split" ? [children[1], children[3]] : [children[2]];\n    const gutterPositions = view === "split" ? [0, 2] : [0, 1];',
     '    const cells = view === "split" ? [children[1], children[4]] : [children[2]];\n    const gutterPositions = view === "split" ? [0, 3] : [0, 1];')
edit('src/lib/jumpDomProbe.ts',
     '    if (children.length !== (view === "split" ? 4 : 3) || !guttersMatch) continue;',
     '    const middleMatches = view !== "split" || children[2]?.matches("span.mid");\n    if (children.length !== (view === "split" ? 5 : 3) || !guttersMatch || !middleMatches) continue;')

icons = repo / 'src/components/app/FileTypeIcon.tsx'
text = icons.read_text()
colors = {
    '#3178c6': 'var(--file-typescript)', '#d6a514': 'var(--file-javascript)',
    '#c46a2f': 'var(--file-rust)', '#7a8291': 'var(--file-json)',
    '#c9634f': 'var(--file-yaml)', '#9a6b3f': 'var(--file-toml)',
    '#5b8bd0': 'var(--file-markdown)', '#8250df': 'var(--file-css)',
    '#d4643a': 'var(--file-html)', '#d98e2b': 'var(--file-sql)',
    '#4f9a5b': 'var(--file-shell)', '#3d7ab8': 'var(--file-python)',
    '#9c6ade': 'var(--file-image)', '#8c90a0': 'var(--file-default)',
    '#ffffff': 'var(--file-icon-label)',
}
for color, token in colors.items():
    assert color in text
    text = text.replace(color, token)
icons.write_text(text)
edit('src/index.css',
     '/* ---------- 窗口框架：主工具栏、工具窗口图标条、岛屿面板、状态栏（Q107） ---------- */',
     ':root {\n' + ''.join(f'  --file-{name}: {color};\n' for color, name in [
         ('#3178c6', 'typescript'), ('#d6a514', 'javascript'), ('#c46a2f', 'rust'),
         ('#7a8291', 'json'), ('#c9634f', 'yaml'), ('#9a6b3f', 'toml'),
         ('#5b8bd0', 'markdown'), ('#8250df', 'css'), ('#d4643a', 'html'),
         ('#d98e2b', 'sql'), ('#4f9a5b', 'shell'), ('#3d7ab8', 'python'),
         ('#9c6ade', 'image'), ('#8c90a0', 'default'), ('#ffffff', 'icon-label')])
     + '}\n\n/* ---------- 窗口框架：主工具栏、工具窗口图标条、岛屿面板、状态栏（Q107） ---------- */')
for letter, state in [('M', 'modified'), ('A', 'added'), ('D', 'deleted'),
                      ('R', 'renamed'), ('U', 'conflict'), ('T', 'typeChanged')]:
    css = repo / 'src/index.css'
    text = css.read_text()
    assert text.count(f'.status-{letter} {{') == 1
    css.write_text(text.replace(f'.status-{letter} {{', f'.status-{state} {{', 1))

for filename in ['test-ui-input.mjs', 'test-jump-dom-probe.mjs']:
    target = repo / 'tools' / filename
    assert not target.exists()
    target.write_bytes((Path('/private/tmp') / ('revia-' + filename)).read_bytes())

edit('docs/milestones/m2/issues/13-ui-polish.md',
     '**What to build:** 在已确认的 UI 方向内，把 M2 完成后的现有界面做成 macOS 原生质感、信息密度适合开发工具的样子，浅色、深色都成立，且不影响 diff 性能。',
     '**What to build:** 按已确认的 rev3 与 Q107，把 M2 现有界面改为 Rebased（JetBrains 新版界面）的布局与外观；浅色、深色都成立，且不影响 diff 性能。')
edit('docs/milestones/m2/issues/13-mockups-rev3/README.md',
     '# 任务 13 静态效果图 · 修订稿 rev3（待用户确认）',
     '# 任务 13 静态效果图 · 修订稿 rev3（用户已确认）')
edit('docs/milestones/m2/spec.md',
     '- 两个任务按派发规则先交给 Pi（deepseek），失败时由规划方实现。',
     '- 任务 12 沿用 Pi 派发规则；任务 13 按 Q107 改由规划方接手，保留效果图确认与最终验收门槛。')

review = '''

### 2026-10-24 / 规划方（Codex）：接手顺序与任务13首轮限定复核

用户同意先在 `m2-ui` 复核、真实桌面与 D06 验收，通过后再合入 `m2`；明确“后续 ui 按现在的来”。已确认 rev3 / Q107 是当前外观基准，不再沿用此前被否定的 macOS 原生方案；必要修复不改变这个方向。目前未合并、未删除 worktree。

固定 `be02cb7431af3f6587a82bebf6360fca73879b8b...35da167f8a2202b19a211ade2c311f5ff430cd90`，24 文件；两个独立轴仅静态审查，不把旧08缺陷计为本UI增量。

#### Standards：确定问题3项（P2二、P3一），Fowler判断建议0项

- **ST13-R1-1 / P2**：`DiffView.tsx:537/601/628` 新并排行有5节点，单元格类改为色调；`jumpDomProbe.ts:154/232-237` 仍要求旧语义类及4节点。普通行文字核验失败，使 sourceReady / 返回颜色恢复样本失效。违反规格实现决策9及D06测量链要求。同步语义 DOM 与准确位置，不放宽文字、行号、marker或高亮匹配。
- **ST13-R1-2 / P2**：`App.tsx:2906` 新原生select未进入 `platform.ts:71` 焦点边界，焦点在视图下拉时按审阅快捷键会持久标记并导航；旧按钮有额外排除。违反规格实现决策7控件行为不穿透。
- **ST13-R1-3 / P3**：`FileTypeIcon.tsx:9` 直接颜色表/fallback/SVG白字绕过CSS变量。违反technical-direction颜色集中规则；迁入变量并保持已确认图标视觉。

#### Spec：缺失/部分1项P3、范围扩张0项、实现错误1项P2

- **SP13-R1-1 / P3**：`ChangesList.tsx:260` 用真实枚举生成 `status-modified/added/deleted/renamed/conflict/typeChanged`，CSS却只定义字母后缀。除未跟踪外状态色未生效，不符合Q31和确认稿。本映射错误原已存在，不称为UI改版新引入的数据回归；本任务仍需兑现状态色。
- **SP13-R1-2 / P2**：同视图select焦点穿透；违反本任务“已确认的键盘行为、焦点不穿透不变”和spec决策7。

统计：Standards3，最严重P2；Spec2，最严重P2。修复与受影响检查、固定版本限定复核均未在本条提前声称通过；旧模拟IPC截图不替代真实桌面/D06，Windows仍待后续仅推m2的CI。
'''
task = repo / 'docs/milestones/m2/issues/13-ui-polish.md'
task.write_text(task.read_text() + review)
assert git('rev-parse', 'HEAD').decode().strip() == head
subprocess.run(['git', '-C', str(repo), 'diff', '--check'], check=True)
print(json.dumps({'sourceBase': head, 'modified': git('diff', '--name-only').decode().splitlines()}, ensure_ascii=False))
