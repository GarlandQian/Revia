import gzip
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/Volumes/T7 Shield/project/Revia-m2-ui')
assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD']).decode().strip() == '35da167f8a2202b19a211ade2c311f5ff430cd90'
first = Path('/private/tmp/revia-task13-check01-ukzmi5rb')
second = Path('/private/tmp/revia-task13-check02-nsjuha75')
assert json.loads((second / 'summary.json').read_text())['sourceMatchesBeforeFullChecks']
assert json.loads((second / 'summary.json').read_text())['allChecksPassed']
dest = repo / 'docs/milestones/m2/evidence/task13-review01'
dest.mkdir()
entries = []
sources = [(f'check01/{p.name}', p) for p in sorted(first.iterdir()) if p.is_file()]
sources += [(f'check02/{p.name}', p) for p in sorted(second.iterdir()) if p.is_file()]
sources += [(f'scripts/{p.name}', p) for p in map(Path, [
    '/private/tmp/revia-task13-fix01.py', '/private/tmp/revia-task13-check01.py',
    '/private/tmp/revia-task13-check02.py', '/private/tmp/revia-task13-record01.py'])]
for name, source in sources:
    data = source.read_bytes()
    compressed = len(data) > 4096
    stored = gzip.compress(data, mtime=0) if compressed else data
    relative = name + ('.gz' if compressed else '')
    target = dest / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(stored)
    entries.append({'source': str(source), 'stored': relative, 'gzip': compressed,
                    'sourceBytes': len(data), 'storedBytes': len(stored),
                    'sourceSha256': hashlib.sha256(data).hexdigest(),
                    'storedSha256': hashlib.sha256(stored).hexdigest()})
manifest = {'base': '35da167f8a2202b19a211ade2c311f5ff430cd90',
            'boundary': 'Uncommitted task13 corrections captured by product.diff and source hashes; static/local checks only, no Release/desktop/D06/Windows/merge.',
            'files': entries}
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for entry in entries:
    stored = (dest / entry['stored']).read_bytes()
    original = gzip.decompress(stored) if entry['gzip'] else stored
    assert hashlib.sha256(stored).hexdigest() == entry['storedSha256']
    assert hashlib.sha256(original).hexdigest() == entry['sourceSha256']
    assert original == Path(entry['source']).read_bytes()

acceptance = repo / 'docs/milestones/m2/task13-validation01.md'
acceptance.write_text('''# 任务13：接手修复与本地检查

日期：2026-10-24。当前仅在 `m2-ui` 收尾；用户同意先复核、真实桌面和 D06，通过后合入 `m2`。后续界面以已确认 rev3 / Q107 为准，不另起视觉方案。

## 范围

首轮限定两轴复核固定 `be02cb7...35da167`，完整意见见 [13 Comments](./issues/13-ui-polish.md#comments)。Standards 3 项（最严重 P2，Fowler 判断建议 0）、Spec 2 项（最严重 P2，范围扩张 0）。

- 视图下拉进入生产焦点谓词的隔离范围，防止审阅等全局快捷键穿透。
- 保留新 diff 色调，同时恢复语义单元格类；独立跳转探针对齐并排五节点结构，仍严格检查文字、行号、marker 和 token，不放宽匹配。
- 图标颜色迁入 CSS 变量，保持既定外观；状态字母颜色使用生产枚举后缀。
- 任务及规格残留外观描述对齐 Q107，保留旧意见和旧效果图作为历史。

## 实测检查

[原始记录与逐文件清单](./evidence/task13-review01/manifest.json) 包含命令、退出码、stdout/stderr、源码前后哈希、产品 diff 和驱动脚本。所有检查完成于同一组未提交修复，最终源码与首轮检查前逐文件 SHA256 完全相同。

| 检查 | 真实结果 |
| --- | --- |
| bindings / `tsc -b` / lint / build | 均退出 0；lint 保留现有测试工具的 6 条 unused 警告 |
| Node 内置回归 | 178 通过：IPC 11、jump DOM 11、refresh gate 115、row store 25、UI input 3、visible highlight 13 |
| Python 工具回归 | 20 通过 |
| 完整 Rust | 265 通过 / 1 ignored；lib 101、discard 71、file 20、hunk 24、refresh 15、review 31、session 3 |
| 修复敏感性 | 同两份新回归分别读取旧 `35da167` 模块，均按预期退出 1；不是原生 GUI 复现 |
| 初次差异检查 | 真实退出 2：完整 Rust 后 ts-rs 又生成绑定行尾空白，原错误保留 |
| 受影响复验 | 现有 strip-binding-whitespace 工具规范化后，类型检查、两项新回归、diff-check 均退出 0；全部源码哈希回到首轮检查前原字节，不重跑完整 Rust |

新回归使用 Node 内置设施与最小 DOM / HTMLElement 语义夹具，直接调用生产探针和焦点谓词；不是实际 React 渲染、布局引擎或原生键盘输入。真实桌面和 D06 仍是独立门槛。

## 尚未完成

本轮修复尚待固定提交的两轴限定复核；没有新 Release、真实桌面浅深截图、D06、Windows CI 或合并。旧模拟 WebKit 截图不替代真实应用；本页不能作为任务13或整个 M2 的完成结论。08 的既有关闭问题仍另行返修，不归咎本UI增量，也不因本地检查通过而忽略。
''')
issue = repo / 'docs/milestones/m2/issues/13-ui-polish.md'
issue.write_text(issue.read_text() + '''
### 2026-10-24 / 规划方：首轮修复与集中检查

保留确认的 rev3 外观，完成上述 3/2 项对应修复：select 焦点隔离、diff 语义类和并排五节点探针对齐、图标颜色变量、状态色枚举映射。两份 Node 内置生产入口回归仅验证语义，不冒称浏览器或桌面。

Rust 265 通过/1 ignored、Node 178、Python 20，以及 bindings/tsc/lint/build 均退出0；完整Rust最后再导出绑定空白使初次 diff-check 退出2，已用现有规范化工具处理，源码逐文件SHA恢复检查前原字节，受影响类型/两项新回归/diff-check复验退出0。原失败不删除。详见[检查说明](../task13-validation01.md)及[原始清单](../evidence/task13-review01/manifest.json)。尚待固定提交限定复核，未Release/真实桌面/D06/Windows/合并，暂不勾验收项。
''')
report = repo / 'docs/milestones/m2/report.md'
text = report.read_text()
anchor = '## 当前进度（2026-10-23）\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '''
- 任务13改版按用户确认的 rev3 / Q107 收尾，用户同意先在 `m2-ui` 复核和真实桌面/D06，再合 `m2`，后续UI以当前方向为准。首轮限定复核Standards3/Spec2（各最严重P2）对应修复完成；[本地检查](./task13-validation01.md)核Rust265/1ignored、Node178、Python20及前端检查退出0，保留首次绑定空白失败与规范化后复验，最终全部源码SHA回到检查前。尚待新固定提交复核，没有Release/桌面/D06/Windows/合并，不提前done；08既有缺陷仍独立待返修。
''', 1)
report.write_text(text)
print(json.dumps({'archivedFiles': len(entries), 'storedBytes': sum(e['storedBytes'] for e in entries), 'manifest': str(dest / 'manifest.json')}))
