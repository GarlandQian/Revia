from pathlib import Path
import json,re
run=Path('/private/tmp/revia-rust-memory-verify.aC01we/ci')
r=json.loads((run/'05-final-run.out').read_text());log=(run/'06-final-log.out').read_text()
assert r['headSha']=='59b925d846286441df4c66ce2074cba4d46299a8' and r['conclusion']=='success' and r['status']=='completed'
platforms={}
for job in r['jobs']:
    name=job['name'];assert job['conclusion']=='success'
    required=('Check frontend types','Lint frontend','Build frontend','Run Rust tests','Build release binary')
    assert all(any(s['name']==step and s['conclusion']=='success' for s in job['steps']) for step in required)
    lines=[line for line in log.splitlines() if line.startswith(name+'\tRun Rust tests\t')]
    counts=[tuple(map(int,m)) for line in lines if (m:=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)) for m in [m.groups()]]
    assert len(counts)==9
    counts_total={'passed':sum(c[0] for c in counts),'failed':sum(c[1] for c in counts),'ignored':sum(c[2] for c in counts)}
    assert counts_total['failed']==0 and counts_total['ignored']==1
    for test in ('compact_layout_renders_requested_range_across_hunks','no_eol_markers_keep_row_positions_and_separate_change_blocks','empty_diff_has_no_layout_or_anchors'):
        assert any('git::rows::tests::'+test+' ... ok' in line for line in lines)
    platforms[name]={'reportedHarnessCounts':counts_total,'countsBySuite':counts,'steps':{s['name']:s['conclusion'] for s in job['steps'] if s['name'] in required},'newLayoutTestsPresent':True}
summary={'runId':r['databaseId'],'headSha':r['headSha'],'url':r['url'],'status':r['status'],'conclusion':r['conclusion'],'platforms':platforms,
         'boundary':'CI harness totals include legacy session_flow fixture-optional tests. Their real fixture workload was explicitly rerun locally in this repair; CI harness counts alone are not fixture execution evidence.'}
(run/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
