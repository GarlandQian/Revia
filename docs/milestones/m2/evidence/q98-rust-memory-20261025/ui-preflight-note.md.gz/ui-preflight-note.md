# CUA 预检事件（不计作验收）

CUA getState 首次观察 Revia 不在运行。为预读接口调用 getApp(bundleId) 时因多个同标识应用而失败；随后 getApp(本worktree的完整.app路径)在macOS自动启动了普通实例，尚未带测量隔离环境，不作为本轮任何验收样本。
AX显示普通Revia窗口及既有fixture登记，未点击内容控件、未执行Git写操作。得知getApp会自动启动后立即通过该应用Cmd-Q退出；AX返回App quit，后续listApps确认Revia isRunning=false。没有采集普通实例内存、没有把该普通实例结果当作性能或长测证据。
未对该普通实例的持久应用数据做前后快照，不宣称无任何元数据触达。后续仅在已由隔离环境启动且确认存活后绑定该app路径，避免再次自动启动普通实例。
