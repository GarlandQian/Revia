from pathlib import Path
import datetime
import gzip
import hashlib
import json

root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
run = Path('/private/tmp/revia-rust-memory-verify.aC01we')
archive = root / 'docs/milestones/m2/evidence/q98-rust-memory-20261025'
assert not archive.exists()
archive.mkdir(parents=True)
entries = []
excluded = []
for source in sorted(run.rglob('*')):
    if not source.is_file():
        continue
    relative = source.relative_to(run)
    if (relative.parts[0] in ('home', 'tmp', 'fixtures', 'cold')
            or relative.parts[0].startswith('data-') or source.is_symlink()):
        excluded.append({'source': str(source),
                         'reason': 'Owned fixture/runtime data or symlink; retained in run, not command evidence'})
        continue
    raw = source.read_bytes()
    target = archive / (str(relative) + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    entries.append({'source': str(source), 'archive': str(target.relative_to(archive)),
                    'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})

analysis = json.loads((run / 'analysis.json').read_text())
manifest = {
    'recordedAt': datetime.datetime.now().astimezone().isoformat(),
    'sourceHead': analysis['sourceHead'],
    'productCommit': '9e5c7d1b7d30d06631ea53b63e1360fb45b4c063',
    'runRoot': str(run), 'runCompleted': True, 'q98VerdictAuthoritative': True,
    'q98Passed': analysis['q98Passed'],
    'binarySha256': analysis['binarySha256'],
    'ciRunId': 40199770545,
    'note': 'One complete formal Q98 run after targeted repair. All D06 attempts, original review findings, CI analysis failure and first native-sample correlation output retained. No repeated soak or rewritten raw journals.',
    'verification': 'Each gzip decompressed and byte-compared against source during archival; SHA256 records original bytes.',
    'fileCount': len(entries), 'files': entries, 'excluded': excluded,
}
(archive / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print('Archived and byte/SHA verified', len(entries), 'originals;', len(excluded), 'runtime/fixture files excluded.')
