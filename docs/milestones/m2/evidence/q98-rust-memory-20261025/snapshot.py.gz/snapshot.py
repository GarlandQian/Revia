from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
run = Path('/private/tmp/revia-rust-memory-verify.aC01we')
phase = sys.argv[1]
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
source = {}
for name in tracked:
    if name and (name.startswith(('src/', 'src-tauri/', 'tools/')) or
                 name in ('package.json', 'pnpm-lock.yaml', 'vite.config.ts', 'tsconfig.json', 'tsconfig.app.json')):
        source[name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
artifacts = {}
for path in sorted((root / 'dist').rglob('*')):
    if path.is_file():
        artifacts[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
for name in ('src-tauri/target/release/revia', 'src-tauri/target/release/bundle/macos/Revia.app/Contents/MacOS/revia'):
    path = root / name
    if path.is_file():
        artifacts[name] = hashlib.sha256(path.read_bytes()).hexdigest()
result = {
    'capturedAt': datetime.datetime.now().astimezone().isoformat(),
    'cwd': str(root), 'phase': phase,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
    'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root).decode(),
    'sourceSha256': source, 'artifactSha256': artifacts,
}
if phase != 'before-build':
    before = json.loads((run / 'snapshot-before-build.json').read_text())
    result['sourceMatchesBeforeBuild'] = source == before['sourceSha256']
    assert result['sourceMatchesBeforeBuild'], 'Source changed since freeze'
(run / ('snapshot-' + phase + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(phase, result['head'], len(source), 'source files;', len(artifacts), 'artifacts; status=', repr(result['status']))
