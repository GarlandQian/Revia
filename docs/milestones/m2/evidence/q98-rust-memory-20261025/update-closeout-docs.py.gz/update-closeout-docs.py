from pathlib import Path
import shutil

root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
run = Path('/private/tmp/revia-rust-memory-verify.aC01we')
docs = root / 'docs/milestones/m2'
before = run / 'docs-before-closeout'
assert not before.exists()
before.mkdir()
for name in ('report.md', 'issues/10-integration-matrix.md',
             'issues/10-integrated-verification.md', 'issues/11-desktop-acceptance.md'):
    target = before / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(docs / name, target)
shutil.copy2(run / 'q98-rust-memory-20261025.md', docs / 'q98-rust-memory-20261025.md')

def line_replace(text, prefix, replacement):
    lines = [line for line in text.splitlines() if line.startswith(prefix)]
    assert len(lines) == 1, (prefix, len(lines))
    return text.replace(lines[0], replacement, 1)

path = docs / 'report.md'
text = path.read_text()
text = line_replace(text, '- **Rust 减分配修复恢复验证**',
    '- **Rust 减分配修复完成复验**：产品9e5c7d1、受测HEAD59b925d，源码中重复全量排版/文本分配已消除；完整Rust harness274/0失败/1既有ignored，旧session_flow首轮缺fixture后已显式补跑三项实际通过，lint/build含类型检查exit0。正式双轴首轮各1P3（仅文档），59b925d限定复核均闭合、新增0，原发现保留。143份源码本地检查/构建/长测前后一致。见[本轮完整记录](./q98-rust-memory-20261025.md)。')
text = line_replace(text, '- **实际CI通过**',
    '- **新版实际CI通过**：[40199770545](https://github.com/GarlandQian/Revia/actions/runs/40199770545)对应59b925d；macOS arm64与Windows x64的类型检查/lint/build、Rust及Release编译均成功，harness分别274/246通过、0失败、各1既有ignored。新增三项布局测试两平台实际ok；旧fixture-optional session_flow不以CI总数冒称业务执行。本轮只按Q97正常推m2，后续文档/证据提交未重构建或重测；旧40174661706成功及40172283582失败保留各自版本。')
text = line_replace(text, '- **D06四组已测**',
    '- **新版D06四组有效，原跳转超帧未闭合**：59b925d标准首屏124/129ms；真冷文字3/2ms、八次独立首帧35/35，滚动各60真rAF/0fallback/0uncovered。原appear18/22/28ms的withinOneFrame=false及统一最大帧35ms保留，另一目标探针不能倒填，返回首帧并非全色。统一首次未取得前台可见合成窗口的失败原件也保留，不笼统称D06全部通过。见[新版测量](./q98-rust-memory-20261025.md#新版-d06-与保留的不利结果)；[旧版测量](./final-measure-20261025.md)不覆盖。')
text = line_replace(text, '- **Q98正式长测完整但Rust超幅未通过**',
    '- **新版完整Q98通过**：59b925d新Release主动1801.023秒、同PID93979、29阶段最终全部有效，应用自行exit0、留证权威。Rust footprint首47.8/末47.6/峰49.6MiB，maxRise1.8、斜率-0.0051；压力后WebContent footprint/malloc的maxRise1.3/5.4、斜率+0.0922/+0.2639，均达原阈值。与旧完整长测Rust72.9MiB超幅对照；历史失败保留，不拼接、不放宽规则，不声称全部历史分配来源已调用栈归因。见[本轮完整记录](./q98-rust-memory-20261025.md)及[旧完整失败](./q98-formal-20261025.md)。')
text = line_replace(text, '- **仍需收口**',
    '- **仍需收口**：D06原跳转超帧；必要的审阅外改失效/同位置更新、跨目标旧响应、真实Rejected、hunk键盘与完整文件快捷键/丢弃恢复、字号增大和有限原生退出补验；任务05剩余查看/清空项区分自动化与桌面。任务08仍ready-for-human未done，任务10仍ready-for-agent、11及13未done。新版Q98及最终产品源码双平台CI已完成，不因文档收尾重复长测；全部剩余验收通过才合main，再做M3访谈和规格。')
text = text.replace('已完成新版Release及完整正式30分钟长测，结果见前项；旧vmmap255根因仍未验证，不将工具复核通过称作Q98/M2通过。',
    '该留证版随后完整长测Rust超幅；本轮减分配修复又以新Release完成Q98通过，分别留存。旧vmmap255根因仍未验证，不将工具复核通过单独称作Q98/M2通过。', 1)
anchor = '\n\n## 历史进度（按记录当时状态）'
assert anchor in text
text = text.replace(anchor, '\n\n本轮源码9e5c7d1、实际受测59b925d的新Release/D06/Q98/CI及四份独立审查原件另归入[本轮清单](./evidence/q98-rust-memory-20261025/manifest.json)。二进制SHA256 `28da0f0dc4bf542af589c0e73cc6592520860adee0852fa0f0b5da899438e9fd`；旧桌面样本不倒填为该版本。' + anchor, 1)
path.write_text(text)

path = docs / 'issues/10-integration-matrix.md'
text = path.read_text()
text = line_replace(text, '更新日期：', '更新日期：2026-10-25。由Pi准备，规划方按终态原件校正。自动化、Q98通过与桌面未完成分开，不代表M2通过。本轮实际CI及Release/D06/Q98均固定59b925d，产品修复为9e5c7d1；后续仅文档/证据收尾，不冒称重新构建或重测。')
text = line_replace(text, '**当前源码边界**', '**当前源码边界**：用户“继续吧”放行后，本轮Rust减分配修改已完成本地检查、双轴审查闭环、新Release、四组D06测量、双平台CI和完整正式Q98。143份源码检查/构建/长测前后相同。Q98三条均通过；D06原appear18/22/28ms超帧仍保留未闭合，不以另一目标探针倒填。旧桌面证据各保留其受测版本。详见[本轮完整记录](../q98-rust-memory-20261025.md)。')
text = line_replace(text, '| D06 性能 |', '| D06 性能 | 新版四组有效可见测量；标准首屏124/129ms、滚动0未覆盖；**原appear18/22/28ms超帧未闭合，不笼统判全部通过** |')
text = line_replace(text, '| D01 30', '| D01 30 分钟长测 | **本轮完整Q98通过**：59b925d主动1801.023秒、同PID93979、29阶段最终全有效，Rust maxRise1.8、WebContent两条1.3/5.4MiB均达标；旧72.9MiB超幅失败及更早失败保留。见[本轮记录](../q98-rust-memory-20261025.md) |')
text = text.replace('`Compile Check #40174661706`（head `f10fc971c14e556c239cb4648cabfbbfc28ad4b4`，**success**）',
    '[Compile Check #40199770545](https://github.com/GarlandQian/Revia/actions/runs/40199770545)（head `59b925d846286441df4c66ce2074cba4d46299a8`，**completed / success**）', 1)
text = text.replace('**271 passed / 0 failed / 1 ignored**', '**274 passed / 0 failed / 1 ignored**', 1)
text = text.replace('**243 passed / 0 failed / 1 ignored**', '**246 passed / 0 failed / 1 ignored**', 1)
old = '**原件**：`/private/tmp/revia-m2-ci-final.cXI0qX/`\n（`ci-run-40174661706-check01.json`、`ci-run-40174661706.log` 为证据；\n`ci-counts-derived.json` 只是摘要导出，不能替代原始 log）。'
assert old in text
text = text.replace(old, '**原件**：`/private/tmp/revia-rust-memory-verify.aC01we/ci/` 的 `05-final-run.out`、`06-final-log.out` 及逐次调用元数据/双流；`analysis.json` 仅为派生摘要。已归档到[本轮清单](../evidence/q98-rust-memory-20261025/manifest.json)。新增三项布局测试两平台均实际ok；旧fixture-optional `session_flow` 在CI仍可能提前返回，harness总数不单独当其业务执行证据。本轮本地显式fixture补跑三项实际通过。')
text = text.replace('**旧失败保留**：`2a51`', '**旧CI保留**：`#40174661706`（f10fc971）成功不回填为新版本；`2a51`', 1)
text = text.replace('补充：`session_flow.rs`（3 项）覆盖会话打开、行切片冷热成本、高亮请求形状；',
    '补充：旧 `session_flow.rs`（3 项）设计覆盖会话打开、行切片冷热成本、高亮请求形状，但默认fixture缺失会提前返回；本轮本地首轮未计业务通过，随后显式 `REVIA_M1_FIXTURE` 实际补跑三项通过；', 1)
text = line_replace(text, '| **D01**', '| **D01** 功能前后各 30 分钟同进程长测（Q98） | 功能前既有验收保留；本轮59b925d主动1801.023秒、同PID93979、29阶段最终有效、自然exit0、权威留证；Rust maxRise1.8/斜率-0.0051，压力后WebContent两条maxRise1.3/5.4、斜率+0.0922/+0.2639均通过。见[本轮记录](../q98-rust-memory-20261025.md)。旧完整72.9MiB超幅及两轮中断失败保留 | 本轮功能后Q98已通过，不因文档收尾重复长测；没有调用栈归因，不宣称所有历史分配来源已证明 |')
text = line_replace(text, '| **D06**', '| **D06** 性能 | 新版59b925d四组真实可见窗口测量；标准首屏124/129ms、真冷文字3/2ms、八次首帧35/35、滚动各60真rAF/0兜底/0未覆盖 | 原appear18/22/28ms为withinOneFrame=false，保留未闭合；另一目标探针不能倒填，不能笼统称D06全部通过 |')
text = line_replace(text, '| **D07**', '| **D07** 检查与 Windows 编译 | 最新 #40199770545 双平台success，固定59b925d；本地Rust harness274/0失败/1既有ignored、显式fixture补验3、前端检查均通过 | 本轮最终产品源码检查与双平台实际编译已完成；后续仅文档/证据不冒称新构建或新CI |')
heading = '### D06 实测（四组有效可见窗口测量）'
assert heading in text
new_section = '''### 本轮 D06 实测（59b925d）

原件根 `/private/tmp/revia-rust-memory-verify.aC01we/`，`d06-analysis.json` 逐项独立核对；[本轮报告](../q98-rust-memory-20261025.md#新版-d06-与保留的不利结果)保留完整口径与失败尝试。

| 场景 | 首屏 | 原 appear / warm | 独立文字出 / 回 | 返回严格全色 DOM | 滚动最大帧 / p95 |
| --- | ---: | --- | --- | ---: | --- |
| 标准并排 | 124 | **18 / 7** | 2 / 1 | 32 | 19 / 17 |
| 标准统一 r2 | 129 | **22 / 6** | 2 / 1 | 33 | **35 / 17** |
| 真冷并排 | 124* | 10 / 3 | 3 / 1 | 29 | 18 / 17 |
| 真冷统一 | 108* | **28 / 4** | 2 / 1 | 32 | 17 / 17 |

单位毫秒；*30000源行冷负载首屏独立报告。四组可见/聚焦，focusLosses/hiddenTransitions=0；滚动各60真rAF、0fallback、0uncovered。八次独立首帧35/35文本、0占位；冷外跳实际各缺35行，返回首帧并非全色。原appear18/22/28ms均withinOneFrame=false，未闭合、不倒填；原warm四组均一帧内。标准统一首次未取得前台合成窗口、120秒失败（ok=false/combos=[]）全原件保留，r2是新输出的独立补测。

### 旧版 D06 实测（2a51，保留历史）'''
text = text.replace(heading, new_section, 1)
text = text.replace('| [最终测量](../evidence/final-measure-20261025/manifest.json) | 见清单 | D06四组、Q98两轮失败与独立派生审核 |',
    '| [最终测量](../evidence/final-measure-20261025/manifest.json) | 见清单 | 旧D06四组、Q98两轮失败与独立派生审核 |\n| [Rust修复复验](../evidence/q98-rust-memory-20261025/manifest.json) | 见清单 | 新检查/四份审查报告/Release、全部D06尝试、完整Q98通过及新版双平台CI |', 1)
text = line_replace(text, '- **D01 未通过**', '- **D01 本轮通过**：完整主动1801.023秒、最终权威证据有效、三条内存指标均达原阈值；旧三轮失败不覆盖，不宣称历史波动全部调用栈归因。')
text = line_replace(text, '- 既有桌面/D06 Release', '- 旧桌面/D06 Release对应2a51，旧完整Q98另有6f420a8；本轮Release/D06/Q98实际59b925d，新binary SHA独立归档。旧桌面局部结果不倒填为新版重做。')
text = line_replace(text, '- 上述旧版验收未新增测试', '- 本轮新增三项、补强两项布局回归已执行，通过正式双轴闭环、新版Release/D06实测、双平台CI和完整Q98；D06原跳转超帧仍未闭合，其余桌面剩余项不因内存通过而勾完，未扩张必须GUI的场景。')
path.write_text(text)

comment = '''
### 2026-10-25 / Codex：Rust 减分配复验完成，完整 Q98 通过

产品9e5c7d1、实际受测59b925d；正式双轴首轮Standards1P3/possible0、Spec1P3（产品行为0），均为矩阵文档状态，59b925d限定复核确认闭合、新增0，原始发现及四份报告保留。完整本地Rust harness274/0失败/1既有ignored，首轮旧session_flow缺fixture提前返回未计业务通过，随后显式隔离fixture补跑三项实际通过；前端检查及143份源码SHA核对通过。

新.app binary SHA256 `28da0f0dc4bf542af589c0e73cc6592520860adee0852fa0f0b5da899438e9fd`；完整正式Q98主动1801.023秒、同PID93979、29阶段最终全部有效、自然exit0且CUA确认停止。Rust footprint47.8→47.6、峰49.6MiB，maxRise1.8/斜率-0.0051；压力后WebContent footprint及malloc的maxRise1.3/5.4、斜率+0.0922/+0.2639均通过原阈值。194常规/29阶段/5暖机后压力样本完整，可见性有效、无errors/partialCandidates，fixture语义与原index字节不变。独立重算吻合，旧72.9MiB完整失败及更早中断保留，未做调用栈归因，不宣称全部历史来源已证明。

新版[CI40199770545](https://github.com/GarlandQian/Revia/actions/runs/40199770545)固定59b925d，两平台前端/Rust/Release全部success，harness macOS274/Windows246、0失败、各1既有ignored；旧fixture-optional用例不以CI总数冒称业务执行。本轮按Q97只正常推m2，后续仅文档/证据提交不冒称重新构建或重测。

D06四组有效，但原appear18/22/28ms超帧保留未闭合，不拿独立探针倒填；前台合成窗口失败尝试、CUA预检普通实例误启动立即退出、CI派生脚本SyntaxError和Q98派生native选点时间关联纠正均完整留证。最后一项仅重跑派生分析，未重跑长测。详见[本轮报告及原件](../q98-rust-memory-20261025.md)。D02/D03/D04/D05/D08与任务05剩余边界仍按矩阵收口，10/11/13及M2未done，不合main、不启动M3，不因文档收尾重复完整长测。
'''
for name in ('10-integrated-verification.md', '11-desktop-acceptance.md'):
    path = docs / 'issues' / name
    text = path.read_text()
    if name == '11-desktop-acceptance.md':
        old = '- [ ] 功能完成后的 release 应用同进程、可见窗口连续长测 30 分钟，不卡死且热身后 Rust／WebView 内存不持续增长，记录负载、版本、时间与趋势。'
        assert old in text
        text = text.replace(old, old.replace('- [ ]', '- [x]', 1) + ' 本轮59b925d完整Q98通过，见[复验记录](../q98-rust-memory-20261025.md)；其余验收未完成。', 1)
    path.write_text(text + comment)
print('Updated closeout report, matrix and two task records; no product source modified.')
