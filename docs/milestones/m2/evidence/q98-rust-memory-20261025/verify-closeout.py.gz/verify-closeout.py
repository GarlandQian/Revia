from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re
import subprocess

root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
run = Path('/private/tmp/revia-rust-memory-verify.aC01we')
archive = root / 'docs/milestones/m2/evidence/q98-rust-memory-20261025'
manifest = json.loads((archive / 'manifest.json').read_text())
assert len(manifest['files']) == manifest['fileCount']
assert len({e['archive'] for e in manifest['files']}) == manifest['fileCount']
for entry in manifest['files']:
    raw = gzip.decompress((archive / entry['archive']).read_bytes())
    assert len(raw) == entry['bytes']
    assert hashlib.sha256(raw).hexdigest() == entry['sha256']
    assert raw == Path(entry['source']).read_bytes(), entry['source']

source = json.loads((run / 'snapshot-after-soak.json').read_text())['sourceSha256']
for name, expected in source.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
assert len(source) == 143
assert manifest['q98Passed'] and manifest['q98VerdictAuthoritative']
docs = [root / 'docs/milestones/m2' / name for name in (
    'q98-rust-memory-20261025.md', 'report.md', 'issues/10-integration-matrix.md',
    'issues/10-integrated-verification.md', 'issues/11-desktop-acceptance.md')]
links = 0
for document in docs:
    for link in re.findall(r'\]\(([^)]+)\)', document.read_text()):
        if '://' in link or link.startswith('#'):
            continue
        assert (document.parent / link.split('#')[0]).exists(), (document, link)
        links += 1
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root).decode().splitlines()
assert set(changed) == {
    'docs/milestones/m2/report.md',
    'docs/milestones/m2/issues/10-integration-matrix.md',
    'docs/milestones/m2/issues/10-integrated-verification.md',
    'docs/milestones/m2/issues/11-desktop-acceptance.md',
}, changed
result = {
    'verifiedAt': datetime.datetime.now().astimezone().isoformat(),
    'archivedOriginalCount': manifest['fileCount'], 'allGzipBytesAndSha256Match': True,
    'allOriginalsUnchangedAfterArchiving': True, 'productSourceFilesUnchanged': len(source),
    'localDocumentLinksChecked': links, 'onlyExpectedTrackedDocumentationChanged': True,
    'note': 'This verification is derived finalization metadata, not an extra product run or a payload original counted by manifest.files.',
}
(archive / 'independent-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
