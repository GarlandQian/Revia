from pathlib import Path
import json
run=Path('/private/tmp/revia-rust-memory-verify.aC01we')
rows=[]
for label in ('standard-split','standard-unified-r2','cold-split','cold-unified'):
    r=json.loads((run/f'd06-{label}.json').read_text());c=r['combos'][0];v=r['visibility'];s=c['scroll'];j=c['jump'];dom=c['jumpDom']
    assert r['ok'] and not v['hidden'] and not v['hiddenTransitions'] and not v['focusLosses'] and v['focused']
    assert s['screens']==s['requestedScreens']==s['rafFrames']==60 and s['fallbackFrames']==s['uncoveredFrames']==0
    assert c['jumpDomError'] is None and dom['preparationError'] is None
    for direction in ('outward','return'):
        d=dom[direction]
        assert d['completed'] and not d['timedOut'] and d['frameReady']
        assert d['firstFrame']['dom']['textMatched'] and d['firstFrame']['dom']['placeholderRows']==0
        assert d['firstFrame']['dom']['matchedRows']==d['firstFrame']['dom']['requiredRows']
    rows.append({'label':label,'visibility':v,'rowCount':c['firstScreen']['rowCount'],'firstScreenMs':c['firstScreen']['fromListChangesMs'],
                 'appearMs':j['appearMs'],'withinOneFrame':j['withinOneFrame'],'warmAppearMs':j['warmAppearMs'],'warmWithinOneFrame':j['warmWithinOneFrame'],
                 'targetWasCached':j['targetWasCached'],'warmTargetWasCached':j['warmTargetWasCached'],
                 'outwardTextMs':dom['outward']['textDomMs'],'returnTextMs':dom['return']['textDomMs'],
                 'outwardMissingRowsBefore':dom['outward']['missingRowsBefore'],'returnColorMs':dom['return']['colorDomMs'],
                 'returnFirstFrameColorsMatched':dom['return']['firstFrame']['dom']['colorsMatched'],
                 'firstFrameMatchedRows':[dom[d]['firstFrame']['dom']['matchedRows'] for d in ('outward','return')],
                 'scroll':s})
invalid=json.loads((run/'d06-standard-unified.json').read_text())
assert not invalid['ok'] and not invalid['combos']
summary={'sourceHead':'59b925d846286441df4c66ce2074cba4d46299a8','validRuns':rows,
         'invalidRuns':[{'file':'d06-standard-unified.json','reason':invalid['error']}],
         'note':'Four complete visible/focused runs; readiness failure preserved separately. Original appear/warm and first-frame DOM refer to different jumps; no overwrite of adverse values or overall D06-pass claim.'}
(run/'d06-analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
for r in rows:
    print(r['label'],'first',r['firstScreenMs'],'appear/warm',r['appearMs'],r['warmAppearMs'],'withinFrame',r['withinOneFrame'],r['warmWithinOneFrame'],
          'independentText',r['outwardTextMs'],r['returnTextMs'],'missingBefore',r['outwardMissingRowsBefore'],'max/p95',r['scroll']['frameMaxMs'],r['scroll']['frameP95Ms'],'color',r['returnColorMs'])
print('One invalid readiness run preserved:',invalid['error'])
