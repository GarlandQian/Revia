from pathlib import Path
import datetime
import hashlib
import json
import re
import statistics

run = Path('/private/tmp/revia-rust-memory-verify.aC01we')
report = json.loads((run / 'q98.json').read_text())
frontend = json.loads((run / 'q98.json.frontend.json').read_text())
regular = [json.loads(line) for line in (run / 'q98.json.samples.jsonl').read_text().splitlines()]
phases = [json.loads(line) for line in (run / 'q98.json.phase-samples.jsonl').read_text().splitlines()]
commands = [json.loads(line) for line in (run / 'q98.json.evidence.jsonl').read_text().splitlines()]
def instant(value):
    return datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
operation_offset = (instant(frontend['operationsStartedAt']) - instant(report['startedAt'])).total_seconds()
cutoff = operation_offset + 180
def series(points):
    xs, ys = [x / 60 for x, _ in points], [y for _, y in points]
    mx, my = statistics.mean(xs), statistics.mean(ys)
    slope = sum((x-mx)*(y-my) for x,y in zip(xs,ys)) / sum((x-mx)**2 for x in xs)
    return {'sampleCount': len(points), 'firstMb': ys[0], 'lastMb': ys[-1],
            'minMb': min(ys), 'maxMb': max(ys), 'maxRiseMb': round(max(ys)-ys[0], 2),
            'regressionMbPerMinute': round(slope, 4),
            'passed': max(ys)-ys[0] <= 10 and slope <= 0.5,
            'points': [{'elapsedSec':x,'mb':y} for x,y in points]}
pressure = [s for s in phases if s['pressure'] and s['valid'] and s['authoritative']
            and s['samplingStartedElapsedSec'] >= cutoff]
recomputed = {'rustFootprintMb': series([(s['elapsedSec'], s['rustFootprintMb']) for s in regular
               if s['elapsedSec'] >= cutoff and 'rustFootprintMb' in s])}
for key in ('webContentFootprintMb', 'webContentMallocAllocatedMb'):
    recomputed[key] = series([(s['samplingStartedElapsedSec'], s[key]) for s in pressure])
assert regular == report['memoryTimeSeries']
assert phases == report['phaseMemoryTimeSeries']
assert frontend == report['frontend']
for key, value in recomputed.items():
    for field in ('sampleCount', 'firstMb', 'lastMb', 'maxMb', 'maxRiseMb', 'regressionMbPerMinute', 'passed'):
        assert value[field] == report['q98MemoryVerdict']['series'][key][field], (key,field)
pid = report['reviaPid']
expected = {role: regular[0][field] for role,field in [('WebContent','webContentPids'),('Networking','networkingPids'),('GPU','gpuPids')]}
assert all(len(pids) == 1 for pids in expected.values())
assert all(s['webContentPids']==expected['WebContent'] and s['networkingPids']==expected['Networking']
           and s['gpuPids']==expected['GPU'] and s['serviceDomain']==f'pid/{pid}' for s in regular+phases)
assert all(s['valid'] and s['authoritative'] and s['checkpointEndConfirmed'] for s in phases)
assert len(phases)==len(frontend['phaseCheckpoints'])==len(report['progressEvidence']['closedCheckpoints'])
assert len(pressure) >= 3
vis = [s['visibility'] for s in frontend['samples']] + [frontend['finalVisibility']]
assert all(not v['hidden'] and v['hiddenTransitions']==0 and v['rafPerSecond']>5 and v['maxFrameGapMs']<=2000 for v in vis)
assert report['runCompleted'] and report['q98MemoryVerdictAuthoritative'] and not report['errors']
assert not report['partialCandidates']
assert not report['cleanup']['terminateAttempted'] and not report['cleanup']['killAttempted']
assert report['cleanup']['pollBeforeCleanup']==report['cleanup']['pollAfterCleanup']==0
assert frontend['ok'] and frontend['actualDurationSeconds'] >= 1800
assert all(frontend[counter] > 0 for counter in ('totalFileSwitches','totalViewSwitches','totalScrolls','totalJumps'))
assert len(frontend['files'])==7
wall=(instant(frontend['operationsEndedAt'])-instant(frontend['operationsStartedAt'])).total_seconds()
assert abs(wall-frontend['checkpointPauseSeconds']-frontend['visibilityPauseSeconds']-frontend['actualDurationSeconds'])<0.02
snapshot=json.loads((run/'snapshot-after-soak.json').read_text())
fixture=json.loads((run/'fixture-after.json').read_text())
assert snapshot['sourceMatchesBeforeBuild'] and snapshot['status']=='' and fixture['semanticStateUnchanged']
def mb(text):
    match=re.fullmatch(r'([\d.]+)([KMG])',text)
    return float(match[1])*{'K':1/1024,'M':1,'G':1024}[match[2]]
rust_maps=[]
for command in commands:
    if command.get('argv') != ['vmmap','-summary',str(pid)] or 'stdout' not in command:
        continue
    text=command['stdout']
    footprint=re.search(r'^Physical footprint:\s+([\d.]+[KMG])$',text,re.M)
    empty=re.search(r'^Malloc Large \(empty\)\s+([\d.]+[KMG])\s+([\d.]+[KMG])\s+([\d.]+[KMG])',text,re.M)
    zone=re.search(r'^DefaultMallocZone_\S+\s+(.+)$',text,re.M)
    fields=zone[1].split() if zone else []
    rust_maps.append({'startedAt':command['startedAt'],'purpose':command['purpose'],
        'footprintMb':mb(footprint[1]),'emptyLargeDirtyMb':mb(empty[3]) if empty else 0,
        'defaultMallocLiveAllocatedMb':mb(fields[5]) if fields else None,
        'defaultMallocDirtyMb':mb(fields[2]) if fields else None})
steady_maps=[s for s in rust_maps if (instant(s['startedAt'])-instant(frontend['operationsStartedAt'])).total_seconds() >= 180]
steady_regular=[s for s in regular if s['elapsedSec'] >= cutoff and 'rustFootprintMb' in s]
selected={}
for name, sample in [('first',steady_regular[0]),
                     ('max',max(steady_regular,key=lambda s:s['rustFootprintMb'])),
                     ('last',steady_regular[-1]),
                     ('min',min(steady_regular,key=lambda s:s['rustFootprintMb']))]:
    sampling_start=instant(sample['samplingStartedAt'])
    nearest=min((s for s in rust_maps if s['purpose']=='rust-footprint'),
                key=lambda s:abs((instant(s['startedAt'])-sampling_start).total_seconds()))
    delta=(instant(nearest['startedAt'])-sampling_start).total_seconds()
    assert 0 <= delta < 1, (name,delta)
    assert nearest['footprintMb']==sample['rustFootprintMb'], (name,nearest,sample)
    selected[name]={**nearest,'regularSampleElapsedSec':sample['elapsedSec'],
                    'regularSamplingStartedAt':sample['samplingStartedAt'],
                    'commandStartOffsetSeconds':delta}
summary={
    'analyzedAt':datetime.datetime.now().astimezone().isoformat(),
    'sourceHead':snapshot['head'],'sourceFileCount':len(snapshot['sourceSha256']),
    'sourceUnchanged':True,'fixtureSemanticUnchanged':True,
    'fixtureExactIndexBytesUnchanged':fixture['indexSha256']==json.loads((run/'fixture-before.json').read_text())['indexSha256'],
    'binarySha256':report['binarySha256'],'reviaPid':pid,'webkitPids':expected,
    'reportMatchesRawJournals':True,'finalFrontendMatchesFile':True,
    'operationsStartedAt':frontend['operationsStartedAt'],'operationsEndedAt':frontend['operationsEndedAt'],
    'operationsWallSeconds':wall,'activeSeconds':frontend['actualDurationSeconds'],
    'checkpointPauseSeconds':frontend['checkpointPauseSeconds'],'visibilityPauseSeconds':frontend['visibilityPauseSeconds'],
    'operationOffsetSeconds':operation_offset,'driverSetupSeconds':frontend['setupSeconds'],
    'warmupCutoffElapsedSeconds':cutoff,
    'warmupNote':'Exact operation timestamp alignment selects the same samples and verdict as driver setupSeconds on this run.',
    'regularSampleCount':len(regular),'phaseSampleCount':len(phases),'validFinalPhaseCount':len(phases),
    'postWarmupPressureCount':len(pressure),'visibilitySampleCount':len(vis),
    'rafPerSecondRange':[min(v['rafPerSecond'] for v in vis),max(v['rafPerSecond'] for v in vis)],
    'maxFrameGapMs':max(v['maxFrameGapMs'] for v in vis),'hiddenTransitions':0,
    'finalReportComplete':True,'q98VerdictAuthoritative':True,'q98Passed':all(value['passed'] for value in recomputed.values()),
    'series':recomputed,'cleanup':report['cleanup'],
    'rustNativeMemoryObservation':{
        'capturedVmmapCount':len(rust_maps),'selectedRegularSamples':selected,
        'steadyDefaultMallocLiveAllocatedRangeMb':[min(s['defaultMallocLiveAllocatedMb'] for s in steady_maps),max(s['defaultMallocLiveAllocatedMb'] for s in steady_maps)],
        'note':'Region-level observations only; they do not identify allocation call sites or prove a leak. Cache cardinality and allocator policy were not changed.'},
    'artifactSha256':{name:hashlib.sha256((run/name).read_bytes()).hexdigest() for name in
        ('q98.json','q98.json.frontend.json','q98.json.samples.jsonl','q98.json.phase-samples.jsonl','q98.json.evidence.jsonl')},
}
(run/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('Independent verification: full active run; authoritative evidence; Q98 passed =', summary['q98Passed'])
print('143 source files unchanged; fixture semantic unchanged:',fixture['semanticStateUnchanged'])
for key,value in recomputed.items(): print(key,{k:v for k,v in value.items() if k!='points'})
print('Native memory selected samples:',json.dumps(selected))
