# 任务 07 实施检查清单

基线：234f248175ada05d44dbf639655e07a2957a9dac
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| cargo test（完整既有套件） | 0 | cargo-test.out / cargo-test.err / cargo-test.exit |

Rust 合计 239 项：lib 99、discard_recovery 70（1 ignored 桌面夹具）、file_staging 20、
hunk_staging 24、refresh_isolation 15、review_marks 8、session_flow 3。

## 失败历史（保留）

首次完整 cargo test 时 refresh_isolation::t13_refresh_does_not_spawn_per_file_git_processes 失败
（「刷新 5 个文件不应按文件起 Git 进程，实际新增 5 次」），原因是我最初在每次 refresh 里
WorktreeIdentity::capture（每次多起 2 次 git rev-parse）。改为在 open 会话时捕获一次身份后通过。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测、自动性能测试均未执行；未推送/合并/发布。
commit=d892baee87c70d67878d29924b3a2fb7b496f7ba
