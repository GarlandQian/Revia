# 任务 12 界面清理检查清单

基线：ff2fc640d3a6fa771d1d6b8a5514a3d7471ab347
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| cargo test（完整既有套件） | 0 | cargo-test.out / cargo-test.err / cargo-test.exit |

Rust 合计 247 项：lib 99、discard_recovery 71（1 ignored 桌面夹具）、file_staging 20、
hunk_staging 24、refresh_isolation 15、review_marks 15、session_flow 3。

本轮无失败记录。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
普通启动与测量模式下的实际界面未验证（需要真实桌面）。
commit=48482656b7bf46223e371e44d1d1dddb6f60903b
