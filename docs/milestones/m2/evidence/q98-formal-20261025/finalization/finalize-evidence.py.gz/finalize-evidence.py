from pathlib import Path
import datetime
import gzip
import hashlib
import json

run=Path('/private/tmp/revia-q98-final.Zcp8cD')
root=Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
archive=root/'docs/milestones/m2/evidence/q98-formal-20261025'
manifest_path=archive/'manifest.json'
manifest=json.loads(manifest_path.read_text())
extra=[p for p in sorted((run/'commands').iterdir()) if p.name.startswith(('13-','14-'))]
extra.extend([run/'commands/invocations.json',run/'finalize-evidence.py'])
captured=datetime.datetime.now().astimezone().isoformat()
for source in extra:
    relative=Path('finalization')/source.relative_to(run)
    target=archive/(str(relative)+'.gz')
    assert not target.exists()
    raw=source.read_bytes()
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(target.read_bytes())==raw
    manifest['files'].append({'source':str(source),'archive':str(target.relative_to(archive)),
        'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'capturedAt':captured})
manifest['fileCount']=len(manifest['files'])
manifest['finalizedAt']=captured
manifest['finalizationNote']='Initial invocations.json snapshot predates checks13/14; finalization preserves the appended aggregate separately, without overwriting the earlier snapshot.'
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for entry in manifest['files']:
    raw=gzip.decompress((archive/entry['archive']).read_bytes())
    assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
print('Verified all',manifest['fileCount'],'archived originals; no source/test changes.')
