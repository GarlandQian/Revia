from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

run = Path('/private/tmp/revia-q98-final.Zcp8cD')
repo = run / 'fixtures/diffs'
phase = sys.argv[1]
env = {'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
       'HOME': str(run / 'home'), 'TMPDIR': str(run / 'tmp') + '/',
       'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_OPTIONAL_LOCKS': '0'}
def git(*argv):
    return subprocess.check_output(['/usr/bin/git', '-C', str(repo), *argv], env=env).decode()
files = {}
for path in sorted(repo.rglob('*')):
    if path.is_file() and '.git' not in path.relative_to(repo).parts:
        files[str(path.relative_to(repo))] = hashlib.sha256(path.read_bytes()).hexdigest()
result = {'capturedAt': datetime.datetime.now().astimezone().isoformat(), 'repo': str(repo),
          'head': git('rev-parse', 'HEAD').strip(), 'status': git('status', '--porcelain=v1'),
          'indexEntries': git('ls-files', '--stage'),
          'indexSha256': hashlib.sha256((repo / '.git/index').read_bytes()).hexdigest(),
          'workingFileSha256': files, 'explicitEnv': env}
if phase == 'after':
    before = json.loads((run / 'fixture-before.json').read_text())
    result['semanticStateUnchanged'] = all(before[key] == result[key] for key in
        ('head', 'status', 'indexEntries', 'workingFileSha256'))
(run / ('fixture-' + phase + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(phase, result['head'], len(files), 'working files;',
      'unchanged=' + str(result.get('semanticStateUnchanged', 'baseline')))
