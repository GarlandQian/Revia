from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil

root=Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
run=Path('/private/tmp/revia-q98-final.Zcp8cD')
shutil.copy2(run/'q98-formal.md',root/'docs/milestones/m2/q98-formal-20261025.md')
report=root/'docs/milestones/m2/report.md'
text=report.read_text(encoding='utf-8')
old=next(line for line in text.splitlines() if line.startswith('- **Q98未通过'))
new='- **Q98正式长测完整但Rust超幅未通过**：接管版两轴复核后固定6f420a8构建新版，主动1801.042秒、29阶段最终全部有效，应用自行退出且整体留证权威。本轮未复现vmmap错误；WebContent footprint/malloc两条通过，Rust常规footprint首138.5、最高211.4、末132.5MiB，maxRise72.9超过+10，斜率+0.2401不能抵消超幅。原生empty大块dirty区域与波动对应，具体分配来源仍待定位，不宣称泄漏或根因已修。见[完整正式长测](./q98-formal-20261025.md)；旧两轮失败保留、不拼接。'
text=text.replace(old,new,1)
text=text.replace('先定位长测采样留证和Rust内存问题','留证修复已复核且完整长测有效，接下来定位Rust原生大块分配波动')
text=text.replace('实际受测Release构建源为2a51b160','既有桌面/D06实际受测Release构建源为2a51b160',1)
report.write_text(text,encoding='utf-8')
matrix=root/'docs/milestones/m2/issues/10-integration-matrix.md'
text=matrix.read_text(encoding='utf-8')
old=next(line for line in text.splitlines() if line.startswith('| D01 30'))
new='| D01 30 分钟长测 | **完整运行但Q98未通过**：新版6f420a8主动1801.042秒、29阶段最终全有效；WebContent两条通过，Rust maxRise72.9MiB超+10。见[正式长测](../q98-formal-20261025.md)，旧两轮失败保留 |'
text=text.replace(old,new,1)
old=next(line for line in text.splitlines() if line.startswith('| **D01**'))
new='| **D01** 功能前后各 30 分钟同进程长测（Q98） | 新版6f420a8主动1801.042秒、同PID60845、29阶段最终完整有效、自然exit0、权威留证；WebContent footprint/malloc通过，Rust maxRise72.9MiB失败。见[完整正式记录](../q98-formal-20261025.md)。旧78.54墙秒帧间隔失败、1223.25墙秒vmmap中断及Rust+82均保留，不混入新结果 | 定位Rust原生empty大块dirty波动的分配来源，必要修复独立复核后重新完整正式验收；不是已证明泄漏，不放宽Q98 |'
text=text.replace(old,new,1)
text=text.replace('- **D01 未完成**：两轮均失败，第二轮还缺完整前端阶段证据；本文件不作通过结论。',
                  '- **D01 未通过**：第三轮主动1801.042秒、最终阶段证据完整，但Rust超幅；旧两轮失败保留，本文件不作Q98通过结论。')
text=text.replace('- 本 Release 对应 `2a51`，不是 `f10` 重新构建。',
                  '- 既有桌面/D06 Release 对应 `2a51`，不是 `f10` 重新构建；本轮完整Q98另有 `6f420a8` 新版构建与独立binary SHA，不倒填其他验收。')
matrix.write_text(text,encoding='utf-8')
comment='\n### 2026-10-25：接管版完整正式长测，Rust超幅未通过\n\n固定6f420a8构建真实新版.app，binary SHA256 `08ec2eeec7f6d8f8e997cdac027ee20220334a44803061522fadef444b95e44f`；143份源码构建/运行前后不变。主动1801.042秒、29阶段最终全部有效、同PID60845自然exit0，runCompleted及整体权威均true，vmmap本轮未失败。WebContent两条通过；Rust footprint 138.5→132.5、最高211.4MiB，maxRise72.9失败，斜率+0.2401不抵消。原生empty大块dirty解释主要波动，但调用点仍未知，不宣称泄漏或故障修好。见[正式长测及原件](../q98-formal-20261025.md)。按Q113由Codex继续定位，不再派Pi；10/11/M2仍未完成，不合main/M3。\n'
for name in ('10-integrated-verification.md','11-desktop-acceptance.md'):
    with (root/'docs/milestones/m2/issues'/name).open('a',encoding='utf-8') as handle:
        handle.write(comment)
archive=root/'docs/milestones/m2/evidence/q98-formal-20261025'
assert not archive.exists()
archive.mkdir(parents=True)
entries=[]
excluded=[]
for source in sorted(run.rglob('*')):
    if not source.is_file(): continue
    relative=source.relative_to(run)
    if relative.parts[0] in ('home','tmp','fixtures') or source.is_symlink():
        excluded.append({'source':str(source),'reason':'Owned fixture/runtime data or symlink, retained in original run; not command evidence'})
        continue
    raw=source.read_bytes()
    target=archive/(str(relative)+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0))
    assert gzip.decompress(target.read_bytes())==raw
    entries.append({'source':str(source),'archive':str(target.relative_to(archive)),
                    'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'recordedAt':datetime.datetime.now().astimezone().isoformat(),
          'sourceHead':'6f420a84dc68a98a0709e0fb537c1845ca4c0418',
          'runRoot':str(run),'runCompleted':True,'q98VerdictAuthoritative':True,'q98Passed':False,
          'note':'One full formal run, not a silent retry. Original failed build and duplicate concurrent invocation index retained.',
          'fileCount':len(entries),'files':entries,'excluded':excluded}
(archive/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Archived and verified',len(entries),'files;',len(excluded),'runtime/fixture files retained only in run')
