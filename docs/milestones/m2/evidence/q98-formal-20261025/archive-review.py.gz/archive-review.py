from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil

root = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
run = Path('/private/tmp/revia-q98-final.Zcp8cD')
archive = root / 'docs/milestones/m2/evidence/q98-evidence-review03'
assert not archive.exists()
archive.mkdir(parents=True)
entries, excluded = [], []
for label, base in {
    'standards': Path('/private/tmp/revia-q98-r3-standards.9qUKFp'),
    'spec': Path('/private/tmp/revia-q98-spec-review03.UD0IJZ'),
}.items():
    for source in sorted(base.rglob('*')):
        if not source.is_file():
            continue
        relative = source.relative_to(base)
        if source.is_symlink() or '__pycache__' in relative.parts or any(p.endswith('.app') for p in relative.parts):
            excluded.append({'source': str(source), 'reason': 'Mock app/cache/symlink; not real application evidence'})
            continue
        raw = source.read_bytes()
        destination = archive / label / (str(relative) + '.gz')
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(gzip.compress(raw, mtime=0))
        assert gzip.decompress(destination.read_bytes()) == raw
        entries.append({'source': str(source), 'archive': str(destination.relative_to(archive)),
                        'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
manifest = {
    'recordedAt': datetime.datetime.now().astimezone().isoformat(),
    'reviewBase': '85a2f5c569302ee43af07f0bd768f995478bc2df',
    'reviewTarget': 'ddb9da5bda35162131b3f0011a56303f4937685f',
    'standards': {'hardFindings': 0, 'heuristics': 0}, 'specFindings': 0,
    'fileCount': len(entries), 'files': entries, 'excluded': excluded,
}
(archive / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
shutil.copy2(run / 'review03.md', root / 'docs/milestones/m2/q98-evidence-review03.md')
report = root / 'docs/milestones/m2/report.md'
text = report.read_text(encoding='utf-8')
old = next(line for line in text.splitlines() if line.startswith('- **Q98') and 'Codex' in line)
new = '- **Q98留证接管版复核通过**：Pi一次返修仍未合格后，Codex按Q113直接修复；固定85a2f5c...ddb9da5独立复核Standards确定0/启发式0、Spec0，上轮发现闭合。Python46及源码契约/diff-check原件已核，App/阈值/暖机/负载未改。见[第三轮独立复核](./q98-evidence-review03.md)。下一步构建新版Release及完整正式30分钟长测；旧Rust振幅与vmmap255根因仍未验证，不将工具复核通过称作Q98/M2通过。'
report.write_text(text.replace(old, new, 1), encoding='utf-8')
task = root / 'docs/milestones/m2/issues/10-integrated-verification.md'
with task.open('a', encoding='utf-8') as handle:
    handle.write('\n### 2026-10-25：Codex接管版独立复核通过\n\n固定85a2f5c...ddb9da5，两轴分别为Standards确定0/启发式0、Spec0，上轮留证发现闭合；实际App协议形状正对照及真实main故障入口已独立核对。见[审查记录](../q98-evidence-review03.md)及原件manifest。按Q113不再交回Pi；接下来固定新版Release和完整正式30分钟长测，任务10仍ready-for-agent、11/M2未完成。旧Rust +82MiB和vmmap255不是已解决结论，桌面/D06/最终双平台CI仍有独立门槛。\n')
print('Archived and verified', len(entries), 'files; excluded', len(excluded))
