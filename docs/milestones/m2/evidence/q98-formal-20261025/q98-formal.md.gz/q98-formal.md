# 功能后 Q98 正式长测：完整运行，Rust 超幅未通过

日期：2026-10-25。Codex 接管留证修复的[独立双轴复核](./q98-evidence-review03.md)通过后，固定 clean HEAD `6f420a84dc68a98a0709e0fb537c1845ca4c0418` 构建新版 `.app`，执行一次完整正式长测。**流程完成、原件权威资格有效，但 Q98 不通过；M2 未完成、不合 main、不开始 M3。**

## 版本与隔离

- 留证工具固定产品修改为 `ddb9da5`，受审差异 `85a2f5c...ddb9da5`；受测 HEAD 后续仅归档复核文档。Standards 确定0/启发式0，Spec0；本次没有新增 App/Rust 产品修改。
- 真实 `pnpm tauri build --bundles app` exit0，先运行现有前端 build 再 Release 编译和 bundle；实际 bundle 内 binary SHA256 为 `08ec2eeec7f6d8f8e997cdac027ee20220334a44803061522fadef444b95e44f`，与同次裸 binary 一致，没有沿用旧 `.app`。
- 143份 tracked 源码/测试/配置/锁文件在构建前、后及长测后 SHA 完全一致，工作树 clean。前端 JS/CSS 和全部产物 SHA 随快照归档。此前进度消息误写137份，原始快照和本记录以实际143份为准。
- 唯一目录 `/private/tmp/revia-q98-final.Zcp8cD`，本次新建 HOME/TMPDIR、fixture 和驱动创建的独立应用数据；`env -i`，全局/系统 Git 配置隔离，仅操作本次自建仓库。fixture HEAD、工作文件、暂存区语义及原始 index 字节前后均核对。
- 正式参数 `--minutes 30 --interval 10`，未启用 diagnostic/minimal/focus/keep-on-top；Q98 阈值、180秒暖机、负载、压力和采样间隔均未改。

## 完整运行与留证

| 项目 | 实测 |
| --- | --- |
| 驱动起止（北京时间） | 19:52:15.563–20:25:20.092；1984.51墙秒 |
| 主动操作起止（北京时间） | 19:52:17.913–20:25:18.385 |
| 主动 / 操作墙钟 / 阶段暂停 | **1801.042 / 1980.472 / 179.415秒**；可见性暂停0 |
| Revia / WebContent / GPU / Networking PID | 60845 / 60848 / 60847 / 60849 |
| 循环 / 文件 / 视图 / 滚动 / 跳转 | 626（末轮部分）/ 4379 / 7505 / 20644 / 3754 |
| 常规 / 阶段 / 热身后压力样本 | 192 / 29 / 5；29段最终全部 valid、authoritative，缺失/无效0 |
| 可见性 | 185个前端样本加最终观测，hidden/hiddenTransitions均0；rAF约6.98–61次/秒，最大帧间隔1021ms，不宣称全程60fps |
| 结束 | 应用自行exit0；清理前后poll均0，terminate/kill均未尝试；CUA确认Revia未运行 |

CUA在启动、运行中和近结束留截图/AX，仅在空白标题栏激活一次，没有触发内容控件；截图是时点证据，不代替完整前端可见性监测。`caffeinate -di`仅防空闲睡眠，未改系统设置。进程归属来自各自 launchctl services，不用全局新增PID差集。

最终 frontend JSON、29条增量checkpoint及阶段BEGIN/END完整一致；常规/阶段JSONL与汇总逐字比对，部分失败候选0，driver errors为空，`runCompleted=true`、`q98MemoryVerdictAuthoritative=true`。所有外部采样命令成功，**本轮未复现旧vmmap255，但不声称已修复其系统根因**。

独立派生审核使用真实操作开始时间对齐180秒暖机；本轮入选样本与driver setupSeconds口径完全相同，三条判定逐字段一致。driver的墙秒或exit0不充当主动时长/内存通过。

## Q98 内存判定

单位MiB，斜率MiB/分钟。每条均须 `maxRise<=10` 且 `slope<=0.5`；压力样本须至少3个。

| 指标 | 样本 | 首值 → 末值 | 最高 | maxRise | 斜率 | 结论 |
| --- | ---: | --- | ---: | ---: | ---: | --- |
| Rust常规footprint | 58 | 138.5 → 132.5 | 211.4 | **72.9** | +0.2401 | **失败：超幅** |
| 压力后WebContent footprint | 5 | 90.7 → 81.1 | 90.7 | 0.0 | -0.3479 | 通过 |
| 压力后WebKit malloc allocated | 5 | 22.1 → 27.3 | 27.3 | 5.2 | +0.2357 | 通过 |

Rust末值回落或斜率达标不抵消超幅；不挑点、不重跑取最好一次、不拼接旧两轮。此次完整失败是有效验收结果，不再归为留证缺失。

## 已缩小的定位范围与未知项

利用本次已保存的93份Rust `vmmap -summary` 原件做只读派生，不额外启动GUI/采样：

| 常规采样位置 | Rust footprint | `Malloc Large (empty)` dirty | `DefaultMallocZone` live allocated |
| --- | ---: | ---: | ---: |
| 热身后首样本 | 138.5 | 89.0 | 25.1 |
| 常规最高样本 | 211.4 | 157.8 | 33.8 |
| 常规最低样本 | 82.8 | 29.1 | 33.7 |
| 末样本 | 132.5 | 78.9 | 33.8 |

最高与首样本footprint相差72.9，其中empty大块dirty相差68.8；最高与最低相差128.6，其中empty大块dirty相差128.7。**波动主要落在原生分配器已经标为空的大块dirty区域，而非已证明不断增加的存活对象。** 这只是区域级证据，尚不能把来源归给具体Rust分配点、布局缓存或WebKit IPC，也不能据此宣称无泄漏。尚未做调用栈/分配来源归因，没有猜测性清缓存、强制GC、替换分配器或放宽阈值。

下一步由Codex继续定位反复大块分配来源，再做有证据的针对性修复与独立复核；不再把本轮返修派回Pi。修复后仍须新版完整正式Q98。其他桌面、D06和最终版本双平台CI门槛独立保留。

## 原件边界

[manifest](./evidence/q98-formal-20261025/manifest.json)保留本轮汇总/前端/日志/JSONL/命令双流、真实argv/cwd/显式非敏感环境/时间/exit、源码/产物/fixture快照、CUA和独立派生脚本与结果；gzip逐件解压核验字节/SHA。fixture/app数据/二进制不伪装为命令原件，仍留在独占现场。

首次构建精简PATH缺pnpm，实际exit127、未开始编译；补入现有Node路径后同一源码构建成功，失败原件保留。构建与fixture生成曾并行，记录器分配了两个序号05；文件stem分别为`05-release-app-node-path`与`05-fixture`，所有流和两条aggregate调用独立存在，没有覆盖或事后改号。fixture生成的Xcode环境警告原样保留，exit0，不把警告称作长测故障。旧Release、旧两轮失败、旧D06/CI不改写为本次版本结果。
