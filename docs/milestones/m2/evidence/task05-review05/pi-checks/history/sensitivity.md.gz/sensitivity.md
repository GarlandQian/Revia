# 敏感性对照（本轮）

问题 3（完成留证 sync 失败）：
- 临时把 finish_attempt 在 Completed 分支改为直接返回 failure.0（不降级），
  跑 completion_journal_sync_failure_persists_needs_verification：
  失败，重开后 RestoreAttempt 的 state 为 Completed、written 为 ["target.ts"] —— 正是复核指出的缺陷。
- 恢复实现后该用例通过。
- 同一用例中确认失败点确实落在目录同步：错误信息为
  「完成留证失败…IO 错误：Permission denied (os error 13)；待核对留证已替换但目录同步失败（…Permission denied…），重开应显示待核对」。
