# 任务 05 第四轮限定返修检查清单

基线：81f2c692c7b02721516fbd21d36655b0f68c323d（见 base-sha.txt）
改动前 diff：pre-change.diff
检查前源码 SHA-256：source-sha256-before-check.txt（本次检查实际所测源码）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| cargo test --test discard_recovery | 0 | cargo-discard.out / .err / .exit（70 项） |
| cargo test --lib | 0 | cargo-lib.out / .err / .exit（94 项） |

## 失败历史

- history/sensitivity.md：临时移除完成留证降级后，新回归失败并复现「Completed 残留」；恢复实现后通过。

## 未执行（按交接要求）

完整 223 项历史检查未全部重跑（仅重跑受影响的 discard_recovery 与 lib）；
Release、GUI/open、D06、双平台 CI、长测、Node/Python 工具测试均未执行；未推送/合并/发布。
commit=69d6527af8a10aa8324a2b7483931b8407bb8684
