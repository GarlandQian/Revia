import assert from "node:assert/strict";
import { ReviewOverlay, ReviewRecoveryScheduler, readThroughReview } from "file:///Users/garland/.codex/worktrees/revia-m2/Revia/src/lib/refreshGate.ts";
const overlay=new ReviewOverlay();
for(let i=0;i<1025;i++)overlay.record("fixture-wt",`f${i}`,{head:"h",worktree:"w"},true,2);
const scheduler=new ReviewRecoveryScheduler(3);
const old={worktreeId:"fixture-wt",revision:9,entries:[],review:{paths:[],reviewed:[],total:0,reviewedCount:0,seq:0}};
let reads=0;
async function refreshTarget(id){
  const outcome=await readThroughReview(overlay,async()=>{reads++;return old;});
  if(!outcome.ok){await scheduleRecovery(outcome.worktreeId);return false;}
  return true;
}
async function scheduleRecovery(id){await scheduler.schedule(id,()=>refreshTarget(id));}
const status=await Promise.race([scheduleRecovery("fixture-wt").then(()=>"settled"),new Promise(resolve=>setTimeout(()=>resolve("still-pending"),100))]);
console.log(JSON.stringify({topology:"App scheduleReviewRecovery -> runner refreshTarget -> untrusted read -> scheduleReviewRecovery(same worktree)",status,reads,attempts:scheduler.attemptsFor("fixture-wt"),maxAttempts:3,evictedWatermark:overlay.evictedWatermark("fixture-wt")},null,2));
assert.equal(status,"settled","A repeated untrusted recovery read must settle, not await its own in-flight promise");
