import assert from "node:assert/strict";
import { ReviewOverlay, ReviewRecoveryScheduler, readThroughReview } from "file:///Users/garland/.codex/worktrees/revia-m2/Revia/src/lib/refreshGate.ts";
const overlay=new ReviewOverlay();
function acceptBatch(seq){for(let i=0;i<1025;i++)overlay.record("fixture-wt",`f${i}`,{head:"h",worktree:"w"},true,seq);}
acceptBatch(2);
const scheduler=new ReviewRecoveryScheduler(3);
const freshAtReadStart={worktreeId:"fixture-wt",revision:9,entries:[],review:{paths:[],reviewed:[],total:0,reviewedCount:0,seq:2}};
let reads=0,release;
async function refreshTarget(id){
  const outcome=await readThroughReview(overlay,()=>{reads++;return new Promise(resolve=>{release=resolve;});});
  if(!outcome.ok){await scheduleRecovery(outcome.worktreeId);return false;}
  return true;
}
async function scheduleRecovery(id){await scheduler.schedule(id,()=>refreshTarget(id));}
const initialWatermark=overlay.evictedWatermark("fixture-wt");
const pending=scheduleRecovery("fixture-wt");
assert.equal(typeof release,"function");
// The recovery read was fresh (seq2). A real newer seq3 result is accepted while delivery is held.
acceptBatch(3);release(freshAtReadStart);
const status=await Promise.race([pending.then(()=>"settled"),new Promise(resolve=>setTimeout(()=>resolve("still-pending"),100))]);
console.log(JSON.stringify({initialWatermark,readSeq:2,laterWatermark:overlay.evictedWatermark("fixture-wt"),status,reads,attempts:scheduler.attemptsFor("fixture-wt"),maxAttempts:3},null,2));
assert.equal(status,"settled","A fresh recovery read superseded while in flight must settle instead of waiting for itself");
