# 任务 07 第十五轮限定返修检查清单（读取拒收与重新核对）

基线：9afef4890fddf24884a3e53b3207d06093d2f319

## 命令 / 退出码 / 原始输出（最终实现）

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out（tests 85 / pass 85 / fail 0） |
| git diff --check | 0 | git-diff-check.out / git-diff-check.exit |

最终源码前后 SHA（source-sha256-before-check.txt / -after-check.txt）逐行一致。
本轮只改前端共享层、App 与 Node 测试；Rust 未改，未重跑 Rust 套件。

## 敏感性对照（sensitivity/）

| 回退的修复 | exit | tests | pass | fail | 失败用例 |
| --- | --- | --- | --- | --- | --- |
| A-untrusted-passthrough | exit=1 | 85 | 84 | 1 | 完整快照读取：不可信时明确拒收，并按原目标重新核对（ST07-R15-1 / SP07-R15-2） |
| B-entry-no-check | exit=1 | 85 | 84 | 1 | 逐路径读取不可信时同样明确拒收（getRows 入口） |
| C-scheduler-unbounded | exit=1 | 85 | 84 | 1 | 重读有界：不前进时停止，不产生请求风暴 |

- `A-untrusted-passthrough`：不可信读取原样返回（回到 fb468c2 行为）→ 闭环用例失败。
- `B-entry-no-check`：逐路径读取不检查可信度 → getRows 拒收用例失败。
- `C-scheduler-unbounded`：调度器不设上限 → 「重读有界」用例失败。

## 过程记录（如实）

1. 本轮先在 `/private/tmp/revia-task07-r16-Bocje8` 跑过一轮完整检查（同样 85/85 通过），
   之后我为了清理 lint 告警用脚本批量删除了若干「未使用声明」，误删了仍在使用的变量，
   导致 12 项用例失败。为回到可用状态我执行了 `git checkout tools/test-refresh-gate.mjs`，
   **这一操作丢弃了本轮对测试文件的改动**，随后我按原内容重新应用并重新跑通 85/85。
   - 该目录原件**保留未删**（`/private/tmp/revia-task07-r16-Bocje8`），其中包含那次 85/85 的记录。
   - 批量删除后的失败输出与 `git checkout` 之后的中间状态**没有单独留档**，因为它们在同一个工作区里被覆盖；
     这里如实说明，不冒称已保存。
2. 最终交付以 `/private/tmp/revia-task07-r16b-CcozFw` 为准。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=0600b81001318a7b7d934f5d316c389643ec1feb
