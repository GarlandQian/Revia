import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/Volumes/T7 Shield/project/Revia-m2-ui'); out=pathlib.Path('/private/tmp/revia-m2-ui-integrated-qnvblzpc/build')
out.mkdir(exist_ok=False)
files=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
def hashes():
    return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files if f and (root/f).is_file()}
(out/'source-before.json').write_text(json.dumps(hashes(),indent=2))
(out/'source.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root))
env={k:os.environ[k] for k in ['HOME','PATH'] if k in os.environ}; env['PATH']='/opt/homebrew/bin:'+env['PATH']; env['CARGO_NET_OFFLINE']='true'
commands=[['touch','src-tauri/src/lib.rs'],['pnpm','tauri','build','--bundles','app','--no-sign','--ci','--config','{"build":{"beforeBuildCommand":""}}']]
for i,cmd in enumerate(commands):
    start=time.time()
    with (out/f'build-{i}.stdout').open('wb') as stdout,(out/f'build-{i}.stderr').open('wb') as stderr:
        result=subprocess.run(cmd,cwd=root,env=env,stdout=stdout,stderr=stderr)
    (out/f'build-{i}.json').write_text(json.dumps(dict(command=cmd,cwd=str(root),exitCode=result.returncode,startedAt=start,endedAt=time.time()),indent=2))
    print(i,cmd,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
(out/'source-after.json').write_text(json.dumps(hashes(),indent=2))
binary=root/'src-tauri/target/release/bundle/macos/Revia.app/Contents/MacOS/revia'
(out/'binary.json').write_text(json.dumps(dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),size=binary.stat().st_size),indent=2))
print('sourceUnchanged',hashes()==json.loads((out/'source-before.json').read_text()),flush=True)
print((out/'binary.json').read_text(),flush=True)
