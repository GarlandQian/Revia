# B10 Spec 独立限定复核

固定范围：`5f632d661ce5dc37b237c27f60205c8d41fcf86c...2a51b160d1c3871b9c67fee81ae6f082910bc1f8`；唯一提交 `2a51b16`，6 文件非空，受测工作树干净。本轴只读源码及锁定依赖，未运行检查、构建或 GUI，未读取另一轴报告。

- 缺失／部分要求：**0 项**。
- 范围扩张：**0 项**。
- 看似实现但错误：**0 项**。
- 最高严重度：无。本轮未发现有确定生产交错支撑的新缺陷；结论仅为静态复核。

## 核对依据

`spec.md:126` 要求“请求关闭窗口或退出先保留窗口和进程”，`:127` 要求“正常完成并记录结果后执行原关闭／退出请求”“结果待核对则先展示、不静默退出”。`src-tauri/src/lib.rs:138` 在 build 后、run 前安装适配；`src-tauri/src/platform/macos_exit.rs:29` 核验实际 delegate 类，`:56` 拒绝覆盖已有／继承实现，`:51` 重新注册同一保活对象；`:39` 转发既有退出事件，`:111` 始终取消当前 Cocoa 终止，包括转发失败或 panic，不再依赖原来未收到的 ExitRequested。

真实链仍接 `src/App.tsx:807` → `:811` 的同一 CloseDriver；Wait／Stay 位于 `:2788`／`:2792`，待核对真实刷新及代际确认位于 `:2798`、`:2819`、`:2824`。`src/lib/refreshGate.ts:1578` 在最终释放保护的 await 后复核 attempt／代际，`:1588` 锁写后才发出原退出动作；`src/App.tsx:1130` → `src-tauri/src/commands.rs:1065` 保留 Rust 最后保护。锁定 runtime 的 RequestExit 转为 ExitWithCode，Tao 使用 stop:，不重新进入 Cocoa terminate:，未见取消循环。

`spec.md:131` 要求“平台逻辑集中，核心操作保持平台无关”；新实现集中于 macOS 平台模块，未新增菜单、产品流程或扩张 Q108 授权。

## 验证边界

5f 版 C02 是真实失败，不因本次静态结论或报告的 Rust 271 通过而改写。新增 selector／转发测试不证明真实 AppKit 调度；仍须固定新 Release 重验 Cmd-Q、Dock Quit、连续两笔写、Wait／Stay、待核对和最终退出。监听尚未就绪／不可用时存在已记录的 fail-closed 交付边界；系统强退及注销／关机续行不在本轮承诺内。未验证桌面、D06、CI、Q98，任务 08／10／11／M2 均不能据此判完成。
