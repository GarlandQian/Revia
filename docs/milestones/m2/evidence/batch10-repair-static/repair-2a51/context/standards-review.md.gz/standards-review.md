# B10 Standards 独立复核

固定范围：`git diff 5f632d661ce5dc37b237c27f60205c8d41fcf86c...2a51b160d1c3871b9c67fee81ae6f082910bc1f8`；唯一提交 `2a51b16`，6 文件，非空。仅静态读取固定提交与锁定版本的本地依赖源码，未读取另一轴、修改源码或运行检查/构建/GUI。

## 确定规范违反

0 项，最高严重度无。

- `src-tauri/src/lib.rs:138` 在 Tauri build 后、事件循环前安装保护；`src-tauri/src/platform.rs:13` 和 `src-tauri/Cargo.toml:27` 将适配及依赖限定在 macOS，符合 AGENTS.md 平台集中管理规则、Q55/ADR-0007；未改变前端 B09 写门禁。
- `src-tauri/src/platform/macos_exit.rs:20` 核对主线程、实际 delegate 类和已有/继承方法；`:48` 注册方法后重新登记同一保活 delegate，未替换菜单或 Tao 对象。`:71` 的返回编码来自透明封装 NSUInteger 的 `NSApplicationTerminateReply`，与锁定 objc2-app-kit 0.3.2 定义及三参 IMP 签名一致；未发现确定 ABI 错配。
- `src-tauri/src/platform/macos_exit.rs:97` 对成功、转发错误及 panic 均 Cancel；`:38` 转交原有事件，由 `src/App.tsx:807` 进入同一 CloseDriver。最终 `commands.rs:1065` 仍复核 ExitGuard 再 `AppHandle::exit`。核对锁定 runtime-wry 2.12.2 的 RequestExit/ExitRequested 及 tao 0.37.1 的 ExitWithCode/stop 路径，未回到 Cocoa terminate，因此没有新增递归退出或绕过 Q91/Q96 原动作、Wait/Stay、待核对的确定反例。
- 任务 08 Comments 保留桌面失败原件、注明本轮待复核且未完成，符合 issue-tracker 和 local-validation 的状态/证据分工。

## Fowler 判断建议

0 项；未发现值得单列的明确基线 smell。

## 验收边界

现有两项 Rust 回归检查转发决策和真实注册 selector，但不执行生产 `install(app)`、AppKit delegate 缓存刷新及真实 Cmd-Q/Dock Quit。271/0/1 ignored 是实施检查，不替代新固定 Release 的桌面 Wait/Stay、晚结果、pending 和无写入退出验证；亦不替代最终 CI/D06/Q98。本报告不将静态闭合表述为桌面通过。
