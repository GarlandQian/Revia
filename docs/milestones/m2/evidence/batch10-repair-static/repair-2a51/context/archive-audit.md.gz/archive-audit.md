# B10 归档边界与最小原件清单

本次仅只读核对已有文件并写本审计；不修改仓库、fixture 或进程，不运行构建/测试/GUI，不实际归档。`desktop/run02` 在派发时仍运行：本审计不冻结其日志、不读取最终结论，不把随后出现的截图当作已完成验收。待根代理完成允许的安全读写验证并正常退出后，再补齐最终清单。

## 固定身份与证据分层

| 分组 | 固定身份 | 现有权威边界 |
| --- | --- | --- |
| 旧集成检查/构建 | `5f632d661ce5dc37b237c27f60205c8d41fcf86c`；binary `0623cacdf0c395a00d2eba975df7699c0e72d788a0d80d84f7b94a25c1e3a09d` | `/private/tmp/revia-m2-ui-integrated-qnvblzpc` 的 13 条检查原始退出码均 0；153 份检查源码前后哈希清单相等，构建前后 2276 份 tracked-file 哈希字典相等。仅该版本的检查/构建，不是 B10 桌面通过。 |
| 旧集成桌面/失败 | 同上；PID23756 | `/private/tmp/revia-m2-desktop-_2le4ddh`。C01 正常窗口询问/Stay；C02 成功结果被显式门控后真 Cmd-Q 提前退出 0。必须保留，不被 B10 成功样本覆盖。Git 已执行，不得写成 Git 被杀或数据丢失。 |
| B10 修复检查/构建 | `2a51b160d1c3871b9c67fee81ae6f082910bc1f8`；binary `fd5ffc86131aebbe77850487192005166a63c1a98f9e97aa72b3ddaa1d96988d` | `/private/tmp/revia-b10-vzc_he0k`。Rust 271/0/1 ignored 是实施检查；154 份检查/构建源码哈希清单分别前后相等，构建 2277 份 tracked-file 哈希字典前后相等。不同清单作用域不能混称同一个文件数。 |
| B10 桌面 run01 | 同上；PID47783 | run01 已正常退出，含新窗口 Stay、Cmd-Q Stay、菜单 Quit Wait 的原件；C03 Dock 样本无效，见下表。 |
| B10 桌面 run02 | 同上；launch 记录 PID55553，`SHELL=/usr/bin/false` | 仍是开放运行，不形成最终通过或最终源码不变结论；启动前快照、已固定中间快照和失败/未执行边界可归档，但必须标 partial。 |

## 不能算作通过的样本

| 样本 | 已有原件 | 必须保持的结论 |
| --- | --- | --- |
| 旧 5f C02 | 旧 `run01/{launch,exit}.json`、`C02-captured/data/{claimed,captured}/C02UnstageStay.json`、旧 `ui/16-unstage-inflight.txt`、B10 根 `failure.json` | 捕获至退出约 31.35 秒，未到 300 秒门控超时；无 release/delivered。属于确定失败，不并入新版本通过数。`failure.json` 是事后记录，不是原始 CUA 返回转储。 |
| B10 C03 Dock | `desktop/dock-tool-failure.json`、`C03-auto-timeout/data/captured/B10C03DockWait.json`、`.../delivered/B10C03DockWait.json` | 获取 Dock 工具超时约 916 秒，没有执行 Dock Quit；交付记录 `explicit:false`，无对应 release marker。自动超时不是人为控制释放，不算 Dock Quit、Wait 或显式门控通过。 |
| 字号放大 | `desktop/font-shortcuts.json`、`font-adjusted/data/settings.json`、启动前 settings | 原件只记录两次 `super+shift+equal` 和一次 minus，最终字号 11，不能据此证明两次加号生效，也不能宣称字号加减完整通过。可保留减小/保存的局部观察，完整放大仍未验。 |
| B10 C05 | `desktop/permission-control.json`、`C05-before/`、`C05-not-executed/`、`ui/11*`、`ui/12*` | 未确认，restore 未执行；现有 AX 至多支持到达恢复入口，不证明权限失败、结果待核对或关闭联动。两快照的 HEAD/status/index/工作区diff/暂存diff及文件哈希+mode相同，src 临时权限已恢复 0755。不得将预设权限故障当作实际故障已触发。 |
| run02 后续 | `desktop/run02/` 及后续新增截图 | 待正常结束、after 快照、exit 与完整日志后才可形成新结论；不得为归档方便杀进程、补造退出或提前取最终哈希。 |

B10 `C02-captured` 与 `C02-released` 的五份 Git 输出和文件哈希+mode均相同，结合 `explicit:true` 的交付及 `ui/06*` 可支持该次 Cmd-Q Stay/释放后仍开着。`run01-after/data/delivered/B10C04MenuWait.json` 为 explicit true，交付时间早于 exit 约 243ms，结合 `ui/07*`、`ui/08*`、`ui/09*` 支持该次菜单 Quit Wait。不能由它们外推尚未验证的 Dock Quit、pending 或失败路径。

## 建议归档分组与最小原件

建议在一个新证据目录下使用以下互不覆盖的子目录；保留原绝对路径至归档相对路径映射，不重命名旧样本为新版本样本。

### 1. `integration-5f/`

- 旧集成目录根的 `base-sha.txt`、`invocations.json`、`record.py`、`tested-source-list.txt`、两份 `tested-source-sha256-*.txt`。
- `00` 至 `12` 每条命令的 `.out/.err/.exit` 全部保留，含空输出、warning 和绑定清理；不要只留成功摘要。
- `build.py` 与 `build/{source.txt,source-before.json,source-after.json,binary.json,build-0.json,build-0.stdout,build-0.stderr,build-1.json,build-1.stdout,build-1.stderr}`。
- 注意旧 `build-*.json` 没有逐条保存精确 environment；`build.py` 只规定从当时环境继承 HOME/PATH 并增加 CARGO_NET_OFFLINE。保留这一证据局限，不事后补称已保存完整构建环境。

### 2. `desktop-5f-failure/`

- 旧桌面根 `prepare.{json,stdout,stderr}`、`fixture.json`、`launch.py`、`evidence.py`、`review-fixture-addition.json`、`C01-verdict.json`；B10 根 `failure.json` 作为关联的事后记录。
- `run01/{launch.json,exit.json,stdout,stderr}`，以及 `run01-before/`、`run01-after/`、`C01-captured/`、`C01-released/`、`C02-captured/`。每个快照保留 `state.json`、五组 Git stdout/stderr、`worktree/` fixture 文件原字节、`data/` 内 settings/review/recovery 及 hold/claimed/captured/release/delivered。
- 旧 `ui/11*` 至 `ui/16*` 作为失败闭环必留；已有 `ui/01*` 至 `ui/10*`、`partial-restored/`、`review-all-before-stage/`、`review-new-before-old-release/` 若用于任务05/07局部结论也保留，仍标来源 5f，不借用作 B10 新版本验收。

### 3. `repair-2a51/`

- `checks-cpi33j4q/{resolve,rust}/` 中全部 invocations、record.py、base/source-list/前后哈希、每条 stdout/stderr/exit。resolve 保留为依赖解析，不算额外产品测试。
- `checks-path.txt`、`dependency-behavior.json`、`fixed-source-check.json`、`standards-review.md`、`spec-review.md`、本审计；报告是分析材料，不能冒充原始命令输出。本审计只核对另一轴报告存在，不读取其内容。
- `build/` 内全部元数据、命令原件及 source manifests；`touch` 构建强制失效动作必须保留，不能只留 tauri build 成功行。无需复制构建目标目录。

### 4. `desktop-2a51/`

- `desktop/{fixture.json,fixture-continuity.json,evidence.py,launch.py,C02-verdict.json,run01-verdict.json,dock-tool-failure.json,font-shortcuts.json,permission-control.json}`。
- 已完成 `run01/{launch.json,exit.json,stdout,stderr}`；`run01-before/`、`font-adjusted/`、C01/C02 captured/released、`C03-auto-timeout/`、`C04-waiting/`、`run01-after/`、`C05-before/`、`C05-not-executed/`，逐快照保留上一组相同原件类别。
- `ui/01*` 至 `ui/12*` 的 PNG/AX TXT/身份时间 JSON 全部保留；`07-native-quit-menu.txt` 没有对应 PNG/JSON时不补造。后续 13+ 截图待 run02 结束后与实际动作逐项归属，不能凭文件名宣布通过。
- 新旧运行共用同一个独占 fixture、HOME、数据目录且未 reset；延续说明必须保留。B10 快照中携带的旧 C01/C02/R07 marker 是历史残留，不重复计为新 PID 的操作。

## 包装与封存要求

- 文本、JSON、脚本、原始 stdout/stderr 按原字节 gzip；PNG 原样存。禁止重新序列化 JSON、修改换行、去 warning、裁剪失败、对摘要倒填数据；不要从工具渲染文字重新抄录 hash 或含掩码内容。
- manifest 至少包含原始绝对路径、归档相对路径、字节数、原字节 SHA256、压缩文件 SHA256、内容类别、source/binary/PID关联、sample status（pass/failed/invalid/partial/not-executed）和已知局限；逐件解压校验原 SHA256。相同内容可按 SHA 去重并保留每个原路径映射，不可丢失快照归属。
- 不将完整 `.app`、`target/`、`node_modules/`、fixture `.git/` 或完整 Git 仓库复制进证据仓库。旧失败 `.app` 已在 B10 `failing/Revia.app` 本地保留，不删除/覆盖；仓库只保 binary SHA、大小/身份和构建原件。fixture 的小型文件原字节、Git状态/index列表/二进制diff与回收记录足以保留本轮可观察状态，完整fixture暂留本地。
- 归档 run02 前：确认无本次在途 hold、已恢复临时权限，按实际允许动作正常退出；保存全部 stdout/stderr、exit code/time、after 快照、源码/二进制不变核对，再生成最终 manifest。没有该完成信号时保留开放边界，不把 08/10/11/M2 标 done。
- 原始 CUA 请求/响应未见独立完整转储；现有 PNG/AX、手写 action/verdict JSON 和任务会话可相互佐证。若平台能导出既有原始调用记录，应另存并去无关私密信息；无法导出就明确缺口，不把事后摘要包装成原始响应。

本审计不确认 Windows CI、最终 D06 或 Q98，也不建议改动最终长测顺序。
