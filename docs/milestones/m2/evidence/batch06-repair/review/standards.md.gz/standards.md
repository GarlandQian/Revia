## Standards

固定 `95d37df24f95e159c7175069b0ace6fabc287a56...ff6ba78`，唯一提交、4文件非空；只读，未运行检查。

### 确定违反

1. **P1／排他认领失败触发同步递归。** `src/lib/refreshGate.ts:1228`在已有claim时返回null，但`src/App.tsx:1143`随即重新调用reconcile；授权及claim均未改变，持续“proceed→claim null→reconcile”，直至栈溢出，每层还会发送保护IPC。确定触发：A Quit→Wait→A完成，退出保护回包仍挂起；B开始并先完成，其真实end回调进入上述循环；重复退出事件亦可触发。违反`docs/technical-direction.md:56` Q96的可控等待／留在应用闭环。已有执行应等待状态变化，不能同步自调用。
2. **P2／等待原生裁决时继续自动重投。** `src/lib/refreshGate.ts:1533`在delivered后释放claim、保留授权，紧接着`:1534`调用真实App reconcile。若无新写入，立即再次认领并投递close；裁决事件尚未到达期间没有等待状态或次数边界。违反任务08 ST-B06-08-3“不重复投递”的排他要求及Q96原请求闭环。此问题发生在claim已释放后，与第1项独立。
3. **P2／旧程序化关闭事件仍能越过Stay。** A Quit→Wait后已发出close，但IPC／CloseRequested暂缓；用户启动B，另一次关闭询问中选择Stay，B完成；旧CloseRequested随后到达。`src/App.tsx:775`将其当作全新request，因已无写入而自动授权，`:778`无代际归属地completeVerdict并放行关闭。claimId只保护回包方法，没有保护原生事件。违反`docs/technical-direction.md:56` Q96“留在应用”；需关联并拒绝已失效的原生投递。

### 判断与边界

Fowler判断建议0项。旧吞Quit、失败取消自动授权、投递后保留原动作的直接修复已有静态改善，不重复计数。新增测试仍将reconcile简化为计数、原生动作模拟为记录，未覆盖上述App重入及真实裁决接线；按`docs/agents/local-validation.md:16`保留证据边界，不另计缺陷。

确定违反3项：P1一项、P2两项；最高P1；判断建议0项。
