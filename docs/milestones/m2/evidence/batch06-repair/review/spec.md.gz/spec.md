## Spec

缺失/部分0项，范围扩张0项，实现错误1项；最严重P1，本轮仍不通过。行号对应`ff6ba78`。

### 实现错误

- **P1：排他claim接入真实App后仍会同步无限重入。** 违反`docs/milestones/m2/spec.md:126`提供“等待完成后关闭／退出”和“留在应用”，并阻断`:127`“正常完成并记录结果后执行原关闭／退出请求”。可复现交错：A写期间Quit→Wait；A结束，旧exit正在await释放保护；B开始并先结束，实际收尾再次调用reconcile。`src/lib/refreshGate.ts:1195`因授权仍在返回proceed，`:1228`因已有claim返回null；`src/App.tsx:1143`却立即递归调用相同reconcile。状态没有变化，遂反复同步保护IPC、递归至栈溢出，而不是等待旧claim完成。重复原生退出事件也能进入此链。派发要求明确要求去掉这一同步重入，但本轮未修改该分支。

相关所有权子点不另计数：`src/lib/refreshGate.ts:1533`在仅delivered、原生裁决尚未到达时释放claim，`:1534`立即重入真实reconcile；无写/pending时会重新投递同一关闭请求，而非保持“等待裁决”。这说明投递、等待与重入仍未在App链上完整收敛，不另放大为“重复close”独立缺陷。

前轮“立即Quit丢请求”和“失败后保留自动授权”的直接路径已静态闭合；真实Rust接收端回归保持闭合，不重复计旧项。

测试边界：新增测试仍以计数型reconcile、fake native结果为主，未驱动上述真实App重入，Node165不能证明此链通过。本轴未运行检查或GUI；Release、原生裁决实测、D06、CI及长测仍待验收。
