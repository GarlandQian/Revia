# M2整批B07返修：必须收敛App真实关闭驱动，不能只补helper

业务目标：在途写/待核对期间保留进程；完成后执行原关闭/退出，Stay撤回旧动作。验证仅用本次唯一自建临时fixture与独立应用数据，保护路径/文件/权限/暂存区，不碰用户仓库、凭据、main或m2-ui。

实施目录唯一为 `/Users/garland/.codex/worktrees/m2-close-finish/Revia`，m2分支。生产起点`ff6ba782a3e5a2e30960856e60bc49bb2bdca876`，规划方下一提交仅Comments/证据。先读local-validation.md、任务08最新ST-B07-08-1..3与SP-B07-08-1。保留此前闭合修复，不改Q107/rev3/产品决策。

B06虽6条检查全绿，但没有实现上轮明确要求的“App真实共享驱动”与“claim失败不得递归”。请本轮完整落实，不再只向CloseCoordinator追加方法、在测试手动拼调用后宣称App同源。

## 三项一起修

1. **同步递归（P1）**：gate1228已有claim→null，App1143立即reconcile，状态不变一直proceed→null→reconcile至栈溢出且发IPC风暴。确定交错A写Quit→Wait→A结束，release挂起，B开始并先结束；或重复native-exit事件。已有执行时应返回稳定“执行/等待中”状态，等待真正状态变化，不同步自调用也不定时自旋。
2. **delivered未等裁决便重投（P2）**：gate1533释放claim保留授权，1534真实reconcile，无B时立即再次投递close。必须区分“执行中”“已投递等待裁决”“被拦截需等待新写完成”与“明确失败待用户选择”。每次原生投递只能有一个在途裁决，回包不是重试许可；有在途时重复请求/reconcile不能重复投递。
3. **旧程序化CloseRequested越过Stay（P2）**：A Quit→Wait→A结束，已调用close但事件暂缓；B开始，另一次关闭询问选Stay，B完成；旧CloseRequested才到App775，被当新request('close')并无代际completeVerdict放行。需要原生投递/裁决与请求所有权关联，Stay后的旧原生动作不得当新用户意图。只用claimId保护IPC回包不够。请核对锁定依赖原生事件API，采用能真实关联/裁决的最小适配，不能仅注释声称旧事件被取消；不能无条件destroy或用禁浏览/禁切worktree绕过。真正无在途写/无旧投递时用户的新close/exit仍正常，不能一律吞新请求。

## 强制生产同源边界

把App实际使用的“收到原生请求→决策→reconcile→claim→异步执行→回包/失败→原生裁决→Wait/Stay”调度收在一个共享生产驱动中（具体命名自选）。App只做Tauri/React适配与展示，现有写编排end/rollback、核对结束调用同一驱动。测试驱动它，允许注入可控deferred IPC/native事件层，**不允许reconcile只是计数或在测试手拼生产分支**。测试native层必须会交付原生事件并经过同一驱动，而不只push动作或返回completed替代App的delivered。不要为本轮新建测试框架。

回归最少覆盖完整真实驱动的：
- A退出release挂起，B开始/结束以及重复native-exit：调用有界、不递归、不多发；旧执行恢复后正确收尾。
- close回包先于/后于裁决两种顺序：无B时只投递一次并等待裁决；有B时保留原exit并在B结束后按原动作继续；旧claim不能清新claim。
- close已投递后B请求/Stay，B结束再交旧原生事件：保持窗口，不把旧事件当全新请求；其后真正新用户close/exit仍可执行。
- release/native持续失败只自动一次、可见Wait/Stay，再明确Wait才重试；立即Quit晚事件、pending代际、晚Wait、rollback与监听生命周期既有回归不退。

## 检查与交付

所有相关修改先做完，再集中最小Node/tsc/lint/build/diff-check。Rust若为原生适配改生产契约，补对应真实生产入口必要Rust测试/绑定检查，不复制实现；若Rust未变不再为了日志重复Rust3。保留首次失败，修后仅重跑受影响项。

复用已有真实record.py，mktemp唯一日志目录，逐命令真实argv/cwd、显式非敏感环境、start/end/exit/stdout/stderr及受测生产/测试/构建配置/锁文件before/after SHA。禁止固定指针/事后补造/抓凭据。报告必须明确App现在具体调用哪个共享驱动，给上述交错的实际回归名称与结果，不把helper绿色扩大成GUI通过。

明确文件暂存提交m2后停止等复核。08最多ready-for-human，08/10/11/M2不done。不GUI/Release/D06/CI/长测/推送/合并。汇报SHA、真实检查结果、唯一原件目录、未测边界。
