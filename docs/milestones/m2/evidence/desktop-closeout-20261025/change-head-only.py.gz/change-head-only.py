from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time
from evidence import ROOT, REPO, ENV, snapshot

snapshot('D04-reviewed-before-head')
commands = []

def git(args, data=None, env=ENV):
    started = time.time()
    result = subprocess.run(['git', *args], cwd=REPO, env=env, input=data, capture_output=True)
    commands.append({'argv': ['git', *args], 'cwd': str(REPO), 'startedAt': started,
                     'endedAt': time.time(), 'exitCode': result.returncode,
                     'stdin': data.decode() if data is not None else None,
                     'environment': env, 'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()})
    assert result.returncode == 0, commands[-1]
    return result.stdout.strip()

head = git(['rev-parse', 'HEAD']).decode()
index = (REPO / '.git/index').read_bytes()
working = (REPO / 'src/hunk.ts').read_bytes()
old = git(['show', 'HEAD:src/hunk.ts']) + b'\n'
new = old.replace(b'= 10;', b'= 5010;', 1)
assert new != old
blob = git(['hash-object', '-w', '--stdin'], new).decode()
alternate = ROOT / 'head-only.index'
assert not alternate.exists()
alternate.write_bytes(index)
alternate_env = {**ENV, 'GIT_INDEX_FILE': str(alternate)}
git(['update-index', '--cacheinfo', f'100644,{blob},src/hunk.ts'], env=alternate_env)
tree = git(['write-tree'], env=alternate_env).decode()
commit = git(['commit-tree', tree, '-p', head, '-m', 'Desktop HEAD-only fixture']).decode()
git(['update-ref', 'HEAD', commit, head])
assert (REPO / '.git/index').read_bytes() == index
assert (REPO / 'src/hunk.ts').read_bytes() == working
(ROOT / 'D04-head-only-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
snapshot('D04-head-only-after')
print('Changed HEAD only:', head, '->', commit, '; exact index and working bytes unchanged')
