import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
FIXTURE = json.loads((ROOT / 'fixture.json').read_text())
REPO = Path(FIXTURE['repositoryPath'])
DATA = Path(FIXTURE['reviaDataDirectory'])
ENV = {
    'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
    'HOME': FIXTURE['isolatedHome'],
    'USERPROFILE': FIXTURE['isolatedHome'],
    'XDG_CONFIG_HOME': FIXTURE['isolatedHome'],
    'GIT_CONFIG_NOSYSTEM': '1',
    'GIT_CONFIG_GLOBAL': str(Path(FIXTURE['isolatedHome']) / '.gitconfig'),
    'GIT_TERMINAL_PROMPT': '0',
    'REVIA_ACCEPTANCE': '1',
    'REVIA_ACCEPTANCE_DIR': str(DATA),
}


def snapshot(name):
    dest = ROOT / name
    dest.mkdir(exist_ok=False)
    commands = []
    for label, args in [
        ('head', ['rev-parse', 'HEAD']),
        ('index-path', ['rev-parse', '--git-path', 'index']),
        ('status', ['status', '--porcelain=v2', '-z']),
        ('index', ['ls-files', '--stage', '-z']),
        ('worktree-diff', ['diff', '--binary']),
        ('index-diff', ['diff', '--cached', '--binary']),
    ]:
        argv = ['git', '--no-optional-locks', *args]
        start = time.time()
        result = subprocess.run(argv, cwd=REPO, env=ENV, capture_output=True)
        (dest / f'{label}.stdout').write_bytes(result.stdout)
        (dest / f'{label}.stderr').write_bytes(result.stderr)
        commands.append(dict(argv=argv, cwd=str(REPO), startedAt=start,
                             endedAt=time.time(), exitCode=result.returncode))
        assert result.returncode == 0
    files = {}
    for path in sorted(REPO.rglob('*')):
        rel = path.relative_to(REPO)
        if '.git' in rel.parts or not path.is_file() or path.is_symlink():
            continue
        content = path.read_bytes()
        files[str(rel)] = dict(sha256=hashlib.sha256(content).hexdigest(),
                              size=len(content), mode=oct(path.stat().st_mode & 0o777))
        target = dest / 'worktree' / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    shutil.copytree(DATA, dest / 'data')
    (dest / 'state.json').write_text(json.dumps(dict(
        sampledAt=time.time(), environment=ENV, commands=commands, files=files,
        indexSha256=hashlib.sha256((REPO / (dest / 'index-path.stdout').read_text().strip()).read_bytes()).hexdigest(),
    ), indent=2) + '\n')
    return dest


if __name__ == '__main__':
    print(snapshot(sys.argv[1]))
