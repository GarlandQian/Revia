# M2 桌面补验当前检查点：等待用户确认真实 hunk 丢弃

时间：2026-10-25T23:13:58.085680+08:00

- cwd `/Users/garland/.codex/worktrees/m2-close-finish/Revia`，m2 / 50018c6，工作树clean；产品源码/Release未改。正式Q98已通过，本轮不重复。
- 新现场 `/private/tmp/revia-m2-desktop-closeout.K0wQZe`。此前本轮D02键盘/暂存/取消暂存、D03旧A不覆盖B/真实Rejected+watch警告、D04等长外改/仅HEAD失效、D08真实KP_Add 12→13→12原件均在此；尚未归档repo，不要丢现场。
- 追加通过D05正常Close/Wait：PID9652，hold `D05-close-wait-stage`真实stage_file成功，点窗口close→Wait，显式release（receipt explicit:true）后原关闭完成，run01 exit0、源码/binary未变，CUA listApps确认Revia已退出。14/15截图与AX、16-apps、D05-b-close-wait-captured/release-time等留存。同时验证降级监视下合法写入仍可成功。
- run02沙箱启动PID10914立即exit-6、stdout/stderr空，保留失败；不能说产品崩溃已归因。经require_escalated重启run03正常，PID10993、exec session32275，目前仍在运行，未退出。不要kill。
- CUA `getApp('com.apple.dock')`和`getApp('Dock')`各timeoutReached（-10005）；Ctrl-F3也未取得Dock AX。没有点击真实Dock Quit、没有arm新的写入hold，Dock代表样本仍缺，不能拿其他Quit冒充。可能需用户协助原生Dock点击。
- 任务05补验：在B查看A的record-1792939599324-9200-2，保存17身份不匹配详情、18只读Git diff，直接恢复disabled。这里只证明非当前worktree IdentityMismatch，不冒称原目录已删除/移动。切回A后真实LaterChanges提示、只读Git diff、恢复disabled（19）。run03-before与D05-after-readonly-inspections文件/模式、语义index相同，rawIndex也相同（readonly-integrity.json）。
- **当前窗口已在A/src/hunk.ts的单hunk丢弃最终确认**，尚未点击“保存到回收区并丢弃”。20-hunk-discard-awaiting-user.png/AX，D02-before-gui-hunk-discard快照。用户确认前不要执行GUI删除。
- 精确目标：A路径 `/private/tmp/revia-m2-desktop-closeout.K0wQZe/revia-task05-desktop-tFktzS/repo/src/hunk.ts`；首hunk value010=9010，计划丢弃回index=10；第二hunk value140=1140必须保留。HEAD该位置5010（D04夹具），index10。先完整文件保存到隔离回收区，不改index。后续查看新record并恢复应还原完整9010/1140；恢复按钮也按具体风险处理，清空UI必须动作时另问，不把本次许可当清空许可。
- 目前仅dialog等待，无在途写/关闭。watch-failure.txt仍在本轮data，保留有意降级；hold.json旧id已claimed，不会重复hold相同id。
- CUA绑定closeoutApp、closeoutFs、closeoutRoot仍有效；继续时先rewriteDocumentation，再取全AX，不能沿用截图前编号。当前最后截图后索引失效。
- D06仍未改源码/未新测；原appear18/22/28超帧未闭合，不能以独立80%探针倒填60%目标。后续考虑同次目标DOM/首帧观测但尚未实施。若产品源码变更需固定版本检查/审查/Release/D06/按影响处理，不机械重复Q98。
- 尚未更新repo报告/矩阵、归档新原件、提交/推送/合main/M3。下一步等本次具体hunk丢弃GUI确认。
