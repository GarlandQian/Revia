# M2 桌面补验当前检查点：hunk往返已完成，清空等最终确认

时间：2026-10-25T23:20:05.666055+08:00

本节覆盖下方等待hunk确认状态。

- 用户明确允许hunk丢弃，并补充“清空也允许”。本轮hunk丢弃→新record查看→完整文件恢复实际完成。清空尚未执行；CUA要求删除在最终操作时确认，现已到最后按钮等待该确认。
- PID10993 / exec session32275 / run03仍运行，普通隔离验收模式。无在途写、不用kill；源码/Release未改，HEAD50018c6 / clean。
- 首次点此前对话框时因期间重新激活而确认失效，21截图/AX与D02-after-invalidated-confirmation证明文件/模式/rawIndex/records均未变，D02-invalidated-integrity.json留证。取消后重新打开相同目标（9010→10首hunk，第二1140保留），实际执行成功。
- 新记录 `record-1792941412253-10993-5`，真实saved.json before完整字节等于丢弃前整个文件，outcome.completed.after等于实际丢弃后文件；source discardHunk、同fixture身份。D02-after-gui-hunk-discard、D02-hunk-discard-integrity.json；22截图显示只余第二hunk。暂存区逐字节未变、无关文件/模式未变。
- 23详情明确单hunk恢复完整文件、Ready。真实点击恢复及应用内确认后，24界面提示已完成，D02-after-gui-hunk-restore与D02-hunk-roundtrip-integrity.json证明所有文件/模式和rawIndex逐字节等于D02-before-gui-hunk-discard。没有外部改文件代替恢复。
- 已点击返回列表→清空回收区，只打开最终确认，**尚未点“清空全部记录”**。25-clear-six-records-awaiting-user.png/AX；D05-before-gui-clear完整快照含6条测试record（原5条+本次1条）、settings和其他应用data，删除前原件已保留。
- 当前最终框：“确认清空全部回收记录？此操作不可撤销。”下一步仅删除本轮独立data `/private/tmp/revia-m2-desktop-closeout.K0wQZe/revia-task05-desktop-tFktzS/revia-data/recovery/record-*`，不应改仓库工作区/index/settings/其他data。需要用户当前确认后才点最终按钮；不把之前预授权视为最终操作时确认。
- clear通过后需UI空列表/删除计数与前后完整性核对；关闭当前普通实例正常exit0；Dock样本仍缺（CUA两次timeout），D06原appear仍未闭合，未改源码/新测；不重复Q98。
- 尚未归档本轮原件进repo、更新矩阵/报告、提交/推送/合main/M3；不要丢本轮现场。此前进度及全部历史继续见下。
