from pathlib import Path
import json
import hashlib
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
def load(path): return json.loads((ROOT / path).read_text())
def state(name): return load(name + '/state.json')
def text(name): return (ROOT / name).read_text()
def unchanged(a, b, raw=True):
    assert state(a)['files'] == state(b)['files'], (a, b, 'files')
    assert (ROOT / a / 'index.stdout').read_bytes() == (ROOT / b / 'index.stdout').read_bytes(), (a, b, 'index')
    if raw: assert state(a)['indexSha256'] == state(b)['indexSha256'], (a, b, 'raw index')

source = load('source-before.json')
assert len(source) == 143
assert all(hashlib.sha256(subprocess.check_output(['git','show','50018c6:'+p],cwd=SOURCE)).hexdigest()==sha for p,sha in source.items())
for run in ('run01','run03'):
    exit = load(run+'/exit.json')
    assert exit['exitCode'] == 0 and exit['binaryUnchanged'] and exit['sourceUnchanged']

for name in ('D02-stage-hunk-captured','D02-stage-file-captured','D02-unstage-hunk-captured','D02-unstage-file-captured'):
    assert state(name)['files'] == state('initial')['files']
assert state('D02-unstage-file-captured')['indexSha256'] == state('initial')['indexSha256']
assert '+export const value010 = 1010;' in text('D02-stage-hunk-captured/index-diff.stdout')
assert '+export const value140 = 1140;' not in text('D02-stage-hunk-captured/index-diff.stdout')
assert '+export const value140 = 1140;' in text('D02-stage-file-captured/index-diff.stdout')
assert '+export const value010 = 1010;' not in text('D02-unstage-hunk-captured/index-diff.stdout')
assert '+export const value140 = 1140;' in text('D02-unstage-hunk-captured/index-diff.stdout')
assert 'Tab' not in text('04-hunk-tab-focus-ax.txt') or '暂存此 hunk' in text('04-hunk-tab-focus-ax.txt')
for id in ('D02-stage-hunk','D02-stage-file-shortcut','D02-unstage-hunk','D02-unstage-file-shortcut','D03-old-a-list','D03-stale-hunk-rejected','D05-close-wait-stage'):
    data = ROOT/'run01-after/data'
    captured=json.loads((data/'captured'/f'{id}.json').read_text())
    delivered=json.loads((data/'delivered'/f'{id}.json').read_text())
    assert delivered['explicit'] is True, id
    assert captured['outcome'] == ('error' if id == 'D03-stale-hunk-rejected' else 'ok'), id

unchanged('D03-b-external-before-write','D03-b-rejected-captured')
for name in ('10b-b-committed-before-release-ax.txt','11-b-after-old-a-release-ax.txt'):
    body=text(name); assert 'desktop-b' in body and 'B_ONLY.txt' in body and '3010' in body and '9010' not in body
body=text('13-real-rejected-with-watch-warning-ax.txt')
assert '操作被拒绝' in body and '文件已变化，请重新确认' in body and '自动刷新不可用' in body and '4010' in body
for name in ('07-equal-length-invalidation-ax.txt','09-head-only-invalidation-ax.txt'):
    body=text(name); assert '已审阅 0/' in body and '9010' in body
unchanged('D04-reviewed-before-head','D04-head-only-after')
assert text('D04-reviewed-before-head/head.stdout') != text('D04-head-only-after/head.stdout')
unchanged('run03-before','D05-after-readonly-inspections')
assert '原 worktree 身份无法确认' in text('17-noncurrent-record-detail-ax.txt')
assert 'button (disabled) 恢复完整文件' in text('17-noncurrent-record-detail-ax.txt')
assert '只读对比' in text('19-laterchanges-readonly-diff-ax.txt') and '只能只读对比或另存' in text('19-laterchanges-readonly-diff-ax.txt')
unchanged('D02-before-gui-hunk-discard','D02-after-invalidated-confirmation')
unchanged('D02-before-gui-hunk-discard','D02-after-gui-hunk-restore')
discard=load('D02-hunk-discard-integrity.json'); rid=discard['recordId']
pre=(ROOT/'D02-before-gui-hunk-discard/worktree/src/hunk.ts').read_bytes()
post=(ROOT/'D02-after-gui-hunk-discard/worktree/src/hunk.ts').read_bytes()
assert post == pre.replace(b'value010 = 9010;', b'value010 = 10;') and b'value140 = 1140;' in post
saved=load('D02-after-gui-hunk-discard/data/recovery/'+rid+'/saved.json')
outcome=load('D02-after-gui-hunk-discard/data/recovery/'+rid+'/outcome.json')
assert bytes(saved['before'][0]['content']) == pre and bytes(outcome['completed']['after'][0]['content']) == post
unchanged('D05-before-gui-clear','D05-after-gui-clear')
clear=load('D05-clear-integrity.json')
assert len(clear['removedRecordIds']) == 6 and clear['remainingRecordIds'] == [] and clear['allOtherApplicationDataBytesIdentical']
assert '暂无回收记录' in text('26-clear-completed-empty-ax.txt')
assert load('font-after-keypad-plus-settings.json')['diffFontSize'] == 13
assert load('run01-after/data/settings.json')['diffFontSize'] == 12
result={
 'sourceCommit':'50018c682fbd52eb3f89c028f5ab6c490d1874d1','releaseBuildCommit':'59b925d846286441df4c66ce2074cba4d46299a8',
 'sourceFilesVerifiedAgainstCommit':len(source),'binary':load('binary.json'),
 'passed':['D02 hunk keyboard/staging/unstaging/file shortcut','D02 actual hunk discard/full-file recovery','D03 stale A response isolated from B','D03 actual Rejected with watcher warning','D04 equal-length worktree and HEAD-only invalidation','D05 original Close/Wait completed','D08 actual keypad-plus font increase','task05 LaterChanges and noncurrent IdentityMismatch read-only views','task05 clear six isolated records'],
 'explicitDeliveryCount':7,'newRecoveryRecord':rid,
 'preservedInvalidAttempts':['font key variants without effect','stale AX index click','native selector not committed before Return','run02 sandbox startup exit -6 with empty streams','Dock API timeout twice','discard confirmation invalidated without writes'],
 'remaining':['Dock Quit in-flight representative sample','actual original-directory unavailable view if required separately','D06 same-target observation handled in separate run'],
 'boundary':'No original-directory deletion/move/rebuild GUI scenario claimed; noncurrent IdentityMismatch only. No product-source changes during desktop runs. Later measurement instrumentation is a separate source/binary.'
}
(ROOT/'desktop-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
