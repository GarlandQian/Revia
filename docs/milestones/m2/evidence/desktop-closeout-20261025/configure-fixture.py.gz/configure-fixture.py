from pathlib import Path
import json
import subprocess
from evidence import ROOT, REPO, DATA, ENV, snapshot

target = ROOT / 'linked-b'
argv = ['git', 'worktree', 'add', '-b', 'desktop-b', str(target), 'HEAD']
result = subprocess.run(argv, cwd=REPO, env=ENV, capture_output=True)
print(json.dumps({'argv': argv, 'cwd': str(REPO), 'exitCode': result.returncode,
                  'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()}))
assert result.returncode == 0
path = target / 'src/hunk.ts'
text = path.read_text()
text = text.replace('= 10;', '= 3010;', 1)
path.write_text(text)
(target / 'B_ONLY.txt').write_text('This file belongs only to linked worktree B.\n')
(ROOT / 'linked-b.json').write_text(json.dumps({'path': str(target)}, indent=2) + '\n')
snapshot('initial')
print('Prepared worktree B; ordinary acceptance instance, no measurement-mode flags.')
