# 任务 05 第二轮返修检查清单

源码基线：11a4a715a11c240ac043da2cf62a6eb6eee0e844（返修前）
返修源码：工作区改动，见 diffstat.txt
日志目录：/private/tmp/revia-task05-r2-1792786030

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 原始输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.exit |
| pnpm lint | 0 | lint.out / lint.exit |
| pnpm build | 0 | build.out / build.exit |
| /opt/homebrew/bin/cargo test --manifest-path src-tauri/Cargo.toml | 0 | cargo-test.out / cargo-test.err / cargo-test.exit |
| node tools/test-ipc-diagnostics.mjs | 0 | test-ipc-diagnostics.mjs.out |
| node tools/test-refresh-gate.mjs | 0 | test-refresh-gate.mjs.out |
| node tools/test-row-window-store.mjs | 0 | test-row-window-store.mjs.out |
| node tools/test-visible-highlight-lines.mjs | 0 | test-visible-highlight-lines.mjs.out |
| python3 -m unittest tools.test_bench_long_running | 0 | python-tests.out / python-tests.exit |

## 失败历史（保留，未删除）

| 命令 | 退出码 | 原因 | 输出 |
| --- | --- | --- | --- |
| cargo test（首次全量） | 101 | refresh_isolation t13 并发刷新读到半截文件（测试用 fs::write 非原子写） | history/cargo-test-run1.out / .err / .exit |

修复：把测试写入改为「写临时文件 + rename」，与实际编辑器一致；断言未放宽。修复后连跑 5 次 refresh_isolation 全通过。
commit=6071b599ba29a905c2f47549d76909da05c08bbd
