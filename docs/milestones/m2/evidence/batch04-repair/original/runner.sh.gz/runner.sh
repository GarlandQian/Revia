#!/bin/sh
# 本批检查的精确命令、cwd 与最小环境（供复核重放）。不含任何凭据。
set -x
cd /Users/garland/.codex/worktrees/m2-close-finish/Revia
pnpm exec tsc -b
pnpm lint
pnpm build
node tools/test-refresh-gate.mjs
/opt/homebrew/bin/cargo test --manifest-path src-tauri/Cargo.toml --lib exit_guard
/opt/homebrew/bin/cargo test --manifest-path src-tauri/Cargo.toml --test session_flow
git diff --check
