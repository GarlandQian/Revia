#!/usr/bin/env python3
"""Run one command, capture real argv/cwd/env/timing/exit/stdout/stderr as evidence.

Records at execution time (no post-hoc command list). Writes per-invocation
NN-<name>.{out,err,exit,json} plus an aggregate invocations.json.

Only explicitly non-sensitive environment overrides are recorded; the inherited
environment is NOT dumped (it may contain credentials).
"""
import datetime
import json
import os
import subprocess
import sys
import time

BASE = os.path.dirname(os.path.abspath(__file__))
CWD = "/Users/garland/.codex/worktrees/m2-close-finish/Revia"


def main():
    if len(sys.argv) < 3:
        sys.exit("usage: record.py <name> <argv...>")
    name = sys.argv[1]
    argv = sys.argv[2:]

    # Non-sensitive, explicit environment relevant to these checks.
    overrides = {}
    for key in ("PATH", "HOME", "CARGO_HOME", "CARGO_NET_OFFLINE", "CI",
                "GIT_CONFIG_GLOBAL", "GIT_CONFIG_NOSYSTEM", "TMPDIR"):
        if key in os.environ:
            overrides[key] = os.environ[key]

    existing = sorted(f for f in os.listdir(BASE) if f.endswith(".json") and f[:2].isdigit())
    index = len(existing) + 1
    stem = os.path.join(BASE, f"{index:02d}-{name}")

    started_at = datetime.datetime.now().astimezone().isoformat()
    begin = time.monotonic()
    with open(stem + ".out", "wb") as out, open(stem + ".err", "wb") as err:
        proc = subprocess.run(argv, cwd=CWD, stdout=out, stderr=err,
                              env=dict(os.environ))
    ended = time.monotonic()

    record = {
        "index": index,
        "name": name,
        "argv": argv,
        "cwd": CWD,
        "environmentOverrides": overrides,
        "environmentNote": "只记录显式非敏感变量；未导出完整继承环境（可能含凭据）",
        "startedAt": started_at,
        "endedAt": datetime.datetime.now().astimezone().isoformat(),
        "durationSeconds": round(ended - begin, 3),
        "exitCode": proc.returncode,
        "stdoutFile": os.path.basename(stem) + ".out",
        "stderrFile": os.path.basename(stem) + ".err",
    }
    with open(stem + ".exit", "w") as handle:
        handle.write(f"{proc.returncode}\n")
    with open(stem + ".json", "w") as handle:
        json.dump(record, handle, ensure_ascii=False, indent=2)
        handle.write("\n")

    aggregate = os.path.join(BASE, "invocations.json")
    history = []
    if os.path.exists(aggregate):
        with open(aggregate) as handle:
            history = json.load(handle)
    history.append(record)
    with open(aggregate, "w") as handle:
        json.dump(history, handle, ensure_ascii=False, indent=2)
        handle.write("\n")

    print(f"[{index:02d}] {name} exit={proc.returncode} {record['durationSeconds']}s")
    sys.exit(proc.returncode)


if __name__ == "__main__":
    main()
