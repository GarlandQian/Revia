from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
rows=[]
for scenario in ('standard-split','standard-unified','cold-split','cold-unified'):
    report=json.loads((ROOT/f'd06-{scenario}.json').read_text())
    assert report['ok'] is True and len(report['combos'])==1, scenario
    v=report['visibility'];assert v['focused'] and not v['hidden'] and v['focusLosses']==0 and v['hiddenTransitions']==0 and v['rafPerSecond']>5 and v['maxFrameGapMs']<=2000
    c=report['combos'][0];j=c['jump'];same=j['sameTargetDom'];s=c['scroll'];assert j['targetCovered'] and j['warmCovered']
    assert same['outward']['fromRow']==j['fromRow'] and same['outward']['toRow']==j['toRow']
    assert same['return']['fromRow']==j['toRow'] and same['return']['toRow']==j['fromRow']
    assert same['outward']['targetWasCached']==j['targetWasCached'] and same['return']['targetWasCached']==j['warmTargetWasCached']
    samples={}
    for direction,sample in same.items():
        f=sample['firstFrame'];assert f is not None and not f['hidden']
        assert sample['completed'] and not sample['timedOut'] and not sample['hidden'] and sample['hiddenTransitions']==0
        assert sample['frameBudgetMs']==16.7 and sample['textBudgetMs']==(16.7 if sample['targetWasCached'] else 100)
        dom=f['dom'];expectedReady=f['checkedMs']<=16.7 and dom['canvasReady'] and (dom['textMatched'] or (not sample['targetWasCached'] and dom['placeholderExposed']))
        assert sample['frameReady']==expectedReady and expectedReady
        assert sample['textWithinBudget']==(sample['textDomMs'] is not None and sample['textDomMs']<=sample['textBudgetMs']) and sample['textWithinBudget']
        assert sample['final']['textMatched'] and sample['final']['canvasReady']
        assert sample['targetWasCached']==(sample['missingRowsBefore']==0)
        samples[direction]={k:sample[k] for k in ('fromRow','toRow','targetWasCached','missingRowsBefore','textDomMs','textBudgetMs','frameReady','textWithinBudget')}
        samples[direction].update(firstFrameCheckedMs=f['checkedMs'],firstFrameMatchedRows=dom['matchedRows'],firstFrameRequiredRows=dom['requiredRows'],firstFramePlaceholderRows=dom['placeholderRows'])
    if scenario.startswith('cold'):assert same['outward']['missingRowsBefore']>0
    else:assert c['firstScreen']['fromListChangesMs']<=150
    assert s['rafFrames']==60 and s['screens']==60 and s['fallbackFrames']==0 and s['uncoveredFrames']==0
    assert j['withinOneFrame']==(j['appearMs']<=16.7)
    assert j['warmWithinOneFrame']==(j['warmAppearMs']<=16.7)
    rows.append(dict(scenario=scenario,firstScreenMs=c['firstScreen']['fromListChangesMs'],legacyAppearMs=j['appearMs'],legacyWithinOneFrame=j['withinOneFrame'],legacyWarmMs=j['warmAppearMs'],sameTarget=samples,scroll=s,visibility=v,independent80Percent=c['jumpDom']))
freeze=json.loads((ROOT/'snapshot-before-build.json').read_text());after=json.loads((ROOT/'snapshot-after-measurements.json').read_text());assert freeze['sourceSha256']==after['sourceSha256']
result={'sourceCommit':after['head'],'sourceCount':len(after['sourceSha256']),'artifactSha256':after['artifactSha256'],'scenarios':rows,'d06SameTargetBudgetsPassed':True,'historicalFailuresReclassified':False,'boundary':'DOM readiness at an observed rendering opportunity, not hardware scanout. New observers add cost to legacy dataWait and a frame barrier between jumps; not a bit-for-bit replay of old scheduling. Q98 was not rerun; it stays bound to 59b925d.'}
(ROOT/'d06-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for row in rows:print(row['scenario'],row['firstScreenMs'],'legacy',row['legacyAppearMs'],row['legacyWarmMs'],'same',[(k,v['textDomMs'],v['firstFrameCheckedMs']) for k,v in row['sameTarget'].items()])
print('same-target D06 checks passed; history preserved')
