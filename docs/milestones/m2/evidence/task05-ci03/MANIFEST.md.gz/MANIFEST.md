# 任务 05 身份回归补足检查清单（R05-CI02）

基线：ebe9f921cede1b5dd07da04f327b7180572b230a
检查前 src-tauri/tests/discard_recovery.rs SHA-256：f09e13412dd046480aed23f2c90dcc82ea82c6fd496073fd0b46d0c64fb7e635  src-tauri/tests/discard_recovery.rs（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| cargo test --test discard_recovery | 0 | discard_recovery.out / .err / .exit（71 passed, 1 ignored） |

本轮只改测试断言，未改产品代码；按交接要求未重跑前端与完整 Rust 套件。

## 敏感性对照（临时移除实现后运行，随后恢复）

把 recovery.rs 的 verify_publish 身份核对临时注释掉后，
publish_rechecks_identity_instead_of_reusing_captured_one **失败**：
恢复被成功执行（RestoreAttempt state=Completed, written=["target.ts"]），
说明该用例现在确实由身份核对拒绝，不再被内容保护兜底。
对照后实现已按原字节恢复（history/recovery.rs.original.bak 为对照前的原始副本）。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
Windows 未验证——本机通过不等于 Windows 通过。
commit=3d70aa8c2bcbbddddfe7bedb390e6ff51456ce88
