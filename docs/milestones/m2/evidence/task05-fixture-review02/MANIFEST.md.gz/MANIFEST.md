# 任务 05 桌面夹具 test-only 增量返修（R05-F1）

基线：eb0926c991886d47c98266e72cdeb9e10b3007f1
检查前 src-tauri/tests/discard_recovery.rs SHA-256：a7088d60264609b6b622fca021ec4e08302b679e8866a3ba7e14405663f62c53  src-tauri/tests/discard_recovery.rs

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| REVIA_TASK05_FIXTURE_BASE=/private/tmp cargo test --test discard_recovery -- --ignored --exact --nocapture prepare_task05_desktop_fixture | 0 | fixture.out / fixture.err / fixture.exit |

未执行 cargo build --tests，未跑产品/Rust 全套、前端、Release、GUI、D06、CI、长测。

## 新 fixture（从 fixture.json 读取）

- fixtureRoot: /private/tmp/revia-task05-desktop-46oHkH
- repositoryPath: /private/tmp/revia-task05-desktop-46oHkH/repo
- reviaDataDirectory: /private/tmp/revia-task05-desktop-46oHkH/revia-data
- isolatedHome: /private/tmp/revia-task05-desktop-46oHkH/home
- worktreeId: a5a5ddc07ffd7aac

## 标准 SHA-256 核对

sha256-crosscheck.txt：5/5 与 shasum -a 256 一致。

## 旧结果

上一轮 fixture /private/tmp/revia-task05-desktop-QsnQlq 与日志 /private/tmp/revia-task05-desktop-prep-WPwb8N 保持原样。
commit=8e8a16bd94dc02bc898883d4d0647d8774622331
