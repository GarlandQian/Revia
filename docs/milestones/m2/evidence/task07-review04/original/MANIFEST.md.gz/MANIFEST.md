# 任务 07 第三轮复核返修检查清单

基线：acdc9817aa36549af5e76df7ac4c8c3933122037
检查前源码 SHA-256：source-sha256-before-check.txt（检查后复核未变）

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| cargo test（完整既有套件） | 0 | cargo-test.out / cargo-test.err / cargo-test.exit |

Rust 合计 251 项：lib 99、discard_recovery 71（1 ignored 桌面夹具）、file_staging 20、
hunk_staging 24、refresh_isolation 15、review_marks 20（新增 5 项）、session_flow 3。

## 失败历史（保留）

本轮实现过程中这些新用例先失败、随后修好，原因分别是：

1. packed-refs 用例最初建在父仓库两个指向同一提交的分支上——按 Q20 的文件级版本定义
   此时**不应**失效，是我用例设计错了（不是产品缺陷）。已改为子模块内真实符号分支 +
   packed-refs + 两个不同提交。
2. `submodule_commit` 原先用 `line.trim()`，把 `submodule status` 表示「已初始化且与索引一致」的
   **前导空格**也去掉了，导致正常子模块被判为无法确认。改为只 `trim_end()`。
3. 未确认版本用例原先用普通未跟踪目录，但 Git 不会把它作为单个目录条目列出；改用真实嵌套仓库。

## 临时实验目录边界

history/experiments.md：本轮用过 `/tmp/t-deinit` 与 `/tmp/nl-test` 两个固定名字目录
（先 `rm -rf` 再建），不符合「只影响本任务创建数据」的范围要求；已如实记录且不再动它们，
后续改用 `mktemp -d` 唯一目录。无法回溯证明这些固定路径原先为空。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
桌面行为未验证。
commit=b0e27fbe9a667b3f1233673b0c7b4ab8681936af
