# 本轮临时实验记录（如实说明边界）

本轮返修过程中在 `/tmp` 下用过两个**固定名字**的实验目录：

- `/tmp/t-deinit`：`cd /tmp && rm -rf t-deinit && mkdir t-deinit` 建立，用于探查
  `git submodule deinit` 后的 `submodule status` 前缀与 porcelain 输出。
- `/tmp/nl-test`：`cd /tmp && rm -rf nl-test && mkdir nl-test` 建立，用于探查
  `git rev-parse` 在换行/含空格路径下的输出格式。

这两处**不符合** AGENTS / 本地验证里「只影响本任务创建的数据」的范围要求：
固定名字前先 `rm -rf` 无法回溯证明该路径原先为空或不属于其他任务。
上述两个目录已存在，本轮之后不再删除或覆盖重建；后续实验改用 `mktemp -d` 自建唯一目录
（例如 `mktemp -d` 生成的 `/var/folders/.../tmp.cXLCCDx05F`）。

不能声称已证明所有临时路径原先为空；也不能回溯确认 `/tmp/t-deinit`、`/tmp/nl-test`
在本次创建之前是否存在。fixture 内的 Git 配置仍隔离到自建 HOME 与显式
`GIT_CONFIG_GLOBAL`，未改真实用户配置。
