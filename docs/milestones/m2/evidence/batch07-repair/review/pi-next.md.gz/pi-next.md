# M2整批B08：原生裁决必须能阻止动作，且不能丢早到裁决

业务目标仍为Q96：写入与待核对不能被关闭打断；选择Stay后必须留在应用；正常完成后执行原意图，不重跑Git。所有验证仅本次独占临时fixture/独立应用数据。实施只在 `/Users/garland/.codex/worktrees/m2-close-finish/Revia` 的m2，起点生产`520f134ff995010d87d885594d99d3518213e725`；规划方下一提交仅Comments/证据。先读local-validation.md和08最新ST-B08/SP-B08，不碰main/m2-ui/Q107外观/用户凭据。

旧P1同步递归和delivered立刻重投已闭合。本轮只修剩下两个完整反例并保持旧回归，不再把测试中的挂起位置换成更早的release。

## 未闭合的确定反例

1. **已发出close后Stay仍关窗**：A写Quit→Wait→A结束→performNative已经调用window.close，但原生事件暂缓。原询问仍可见，用户点Stay。旧CloseRequested到了App778，hasInFlight仍true，若无写/pending就787直接return，未preventDefault；driver就算忽略也挡不住Tauri销毁。handleNativeVerdict没有代际验证，hasInFlight不是事件归属。必须让真正的原生入口使用共享驱动返回的allow/prevent决定，旧原生动作要被实际阻止，不只清字段/加注释。
2. **CloseRequested先于IPC回包被B拦，之后永远等待**：performNative已调用，回包hold；B开始；CloseRequested到达被拦并通知driver，但pendingVerdictClaim仍0，inFlight裁决未保存；后来的delivered无条件改成awaitingVerdict。B结束notify直接none，原exit不再执行。必须记录早到裁决，晚回包只能确认传输不能覆盖已消费的裁决；两种先后顺序均跑到B结束、原动作完成。

## 原生适配不能猜测

当前App仍有hasInFlight/needsExitGuard的业务分支，Node不调用它，不能称完整同源。请把原生事件处理的allow/prevent与所有权判断一并收进共享生产入口；App仅把返回决定应用到真实event.preventDefault。测试的native适配须交付事件给这个入口，并检查是否被阻止、是否最终执行，不只push投递后手动调内部裁决方法。

先核对锁定Tauri API：若CloseRequested本身没有可关联的claimId，就不能声称已携带id，也不能仅用hasInFlight推断每个事件都是自己的。可以选择能真实携带代际的原生适配；或者采用明确、受保护的最终提交阶段，避免再生成无法区分的程序化CloseRequested。若用后者，最终提交前同步检查授权/无在途/无pending并使所有写入口不能在已提交关闭后开始新写；关闭/退出要执行对应原动作，失败回到可见询问。不能用无条件destroy绕开保护，不能禁浏览或切worktree。上述是内部安全编排，不新增产品功能；不改变Q96选择语义。选最小能证明真实行为的方案，不保留两套平行执行链。

## 回归必须准确

- close确已投递后（不是release之前）Stay，再送旧原生事件：实际prevent，窗口保持；其后真正新用户close/exit可正常执行。若采取最终提交阶段，按真实UI可选择Stay的边界验证取消/提交，不能让仍可点击的Stay无效。
- close IPC回包前送blocked事件，随后回包、B结束：不挂死，原exit最终执行；回包在事件前也同样验证。
- executing/awaiting重复通知不递归、不多投递，release/native失败不自动重试，旧claim/回包不得影响新请求；pending/rollback/晚Wait原有回归保持。
- 不允许只手动调用coordinator达到期望状态，实际App共享入口必须参与。未使用runCloseExecution仍在源文件，报告此前“已删除”不准确；本轮收敛执行链时清理或如实说明，不扩无关重构。

所有相关改动完成后集中Node/tsc/lint/build/diff-check。Rust若因原生适配变化，跑必要真实生产入口Rust测试/类型绑定，不复制实现；未改则不重跑。沿用记录器mktemp唯一目录，**所有失败尝试也保存原stdout/stderr/exit，不能只grep过滤**；B07早期诊断缺完整日志如实注明，不补造。记录真实argv/cwd/非敏感显式环境、受测生产/测试/配置/锁文件前后SHA。

明确文件暂存提交m2，汇报SHA、适配如何区分请求/裁决、完整交错回归与真实检查/日志目录、未测边界。08最多ready-for-human，08/10/11/M2不得done。不GUI/Release/D06/CI/长测/推送/合并，完成停止等复核。
