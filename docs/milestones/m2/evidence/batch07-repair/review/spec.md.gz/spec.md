## Spec

缺失/部分0项，范围扩张0项，实现错误2项；最严重P2，本轮仍不通过。行号对应`520f134`。

- **P2：Stay仍不能撤销已投递的原生关闭。** 违反`spec.md:126`提供“留在应用”。A写期间Quit→Wait；A结束，程序已调用close、原生事件尚未到达；用户点击仍可见询问中的Stay；旧CloseRequested随后到达。`refreshGate.ts:1656`只清协调器请求并改变phase，没有失效在途投递；`App.tsx:778`仍判hasInFlight，无写/pending时`:787`调用裁决后直接返回，未preventDefault，Tauri仍会销毁窗口。`:1689`既不检查请求代际，也不向适配层返回“拒绝旧关闭”；即使内部忽略事件，也阻止不了外层放行。
- **P2：关闭事件先于IPC回包被阻止后，原请求永久等待不存在的下一次裁决。** 违反`spec.md:127`“正常完成并记录结果后执行原关闭／退出请求”。原exit已调用close、回包挂起；B开始写；CloseRequested先到，被`App.tsx:782`阻止并调用共享驱动。此时`refreshGate.ts:1705`只处理pendingVerdictClaim，但执行中的claim尚在inFlight，故未记住该裁决已消费。稍后delivered回包在`:1782`重新进入awaitingVerdict；B结束后`:1677`直接返回none，没有新原生事件可唤醒，原exit悬挂。

旧项静态闭合：执行中重复通知不再同步递归；delivered后不再立即重新投递；失败取消自动授权并回询问。

测试边界：`test-refresh-gate.mjs:2891`的native仍只记录投递、不交付真实适配事件；`:2994`所谓Stay反例实际停在release之前，没有覆盖“已经投递后Stay”。事件先于回包的用例也未继续验证B结束后的执行，因此Node172不能证明上述链闭合。本轴未运行检查或GUI；真实桌面、Release、D06、CI与长测仍待验收。
