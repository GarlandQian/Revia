## Standards

固定范围：`332097b...520f134`，唯一提交`520f134`；只读静态复核，未运行检查。

**确定违反：2项，均为P2**

1. **P2：旧原生关闭仍越过Stay，ST-B07-08-3未闭合。** `App.tsx:778`仅凭hasInFlight认定事件归属，`:787`调用裁决后直接放行；`refreshGate.ts:1659`处理Stay时未失效在途投递，`:1689`也不校验请求代际。交错：A写入期间Quit→Wait，A完成后已调用原生close，但事件暂缓；用户在仍显示的询问中点Stay，旧CloseRequested随后到达，无写入时仍被放行。当前Tauri适配在未preventDefault时执行destroy，忽略helper内的裁决不等于取消关闭。违反`technical-direction.md:56` Q96“或者留在应用”。需要让真实事件适配拒绝已失效投递，而非仅维护claim数字。
2. **P2：先到的阻止裁决被晚IPC回包覆盖，原请求永久悬挂。** `refreshGate.ts:1706`只释放pendingVerdictClaim；事件早于回包时仅存在inFlightClaim，因此未释放。交错：close IPC暂挂→B开始写→CloseRequested到达并被`App.tsx:782`阻止→IPC回包；`:1782`重新写入旧claim并进入awaitingVerdict。B完成后的真实通知被`:1678`挡住，而该投递的裁决已经发生，不会再来，原退出无法继续。违反`technical-direction.md:56` Q96“等待操作完成并记录结果后再执行用户的原请求”。

**Fowler判断建议：0项。**

**测试边界（不另计缺陷）：** `test-refresh-gate.mjs:2891`仅记录投递，未经过App的事件／preventDefault适配；`:2802`早事件测试未完成B并断言继续执行，`:2994`Stay测试仍停留在投递前。按`local-validation.md:16`，这些绿色结果不能证明上述生产闭环。旧同步递归及delivered后立即重投的直接路径已闭合，不重复计数。

统计：确定违反2项，最高P2；判断建议0项。
