from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat


ROOT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/revia-m2-final-measure-ex9swy__')
NAMES = [
    'q98-driver-launch.json', 'q98-driver-exit.json',
    'q98-driver.stdout', 'q98-driver.stderr', 'q98.json',
    'q98.json.frontend.json', 'q98.json.frontend.log', 'q98.json.log',
    'q98.json.samples.jsonl', 'q98.json.phase-samples.jsonl',
    'q98-start-ui.jpg', 'q98-start-ui.txt', 'q98-start-observation.json',
]


def original(path):
    before = path.stat()
    assert stat.S_ISREG(path.lstat().st_mode)
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
    return {'source': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def parsed(name):
    return json.loads((SOURCE / name).read_bytes())


def date(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))


def difference(later, earlier):
    return round((date(later) - date(earlier)).total_seconds(), 6)


run = parsed('q98.json')
frontend = parsed('q98.json.frontend.json')
launch = parsed('q98-driver-launch.json')
exit_record = parsed('q98-driver-exit.json')
phase = run['phaseMemoryTimeSeries'][0]
checkpoint = frontend['phaseCheckpoints'][0]
regular = run['memoryTimeSeries'][6]
assert phase['checkpointId'] == checkpoint['cycle'] == 22
assert not phase['pressure'] and not checkpoint['pressure']
assert run['reviaPid'] == 88354 and launch['driverPid'] == 88350
assert exit_record['exitCode'] == 1 and run['actualDurationSeconds'] == 78.54
assert run['q98MemoryVerdict']['pressureSampleCount'] == 0
actual_tree = Path('/Users/garland/.codex/worktrees/m2-close-finish/Revia')
integration_tree = Path('/Volumes/T7 Shield/project/Revia-m2-ui')
source_files = []
for relative in ['tools/bench-long-running.py', 'src/App.tsx', 'src/lib/soak.ts']:
    one = original(actual_tree / relative)
    two = original(integration_tree / relative)
    source_files.append({'relative': relative, 'actualDriverTree': one,
                         'integrationTree': two, 'byteIdentical': one['sha256'] == two['sha256']})
    assert source_files[-1]['byteIdentical']
facts = {
    'createdAtUtc': datetime.now(timezone.utc).isoformat(),
    'kind': 'derived-read-only-analysis-not-a-new-run',
    'scope': 'Explicitly named completed first-run originals only; no attempt02 files read.',
    'originals': [original(SOURCE / name) for name in NAMES],
    'sourceComparisons': source_files,
    'identity': {
        'integrationCommit': launch['integrationCommit'],
        'buildSourceCommit': launch['buildSourceCommit'],
        'binarySha256': launch['binarySha256'],
        'driverPid': launch['driverPid'], 'reviaPid': run['reviaPid'],
        'argv': launch['argv'], 'environment': launch['environment'],
    },
    'runOutcome': {
        'driverExit': exit_record, 'runCompleted': run['runCompleted'],
        'startedAt': run['startedAt'], 'endedAt': run['endedAt'],
        'targetDurationSeconds': run['targetDurationSeconds'],
        'actualDurationSeconds': run['actualDurationSeconds'],
        'errors': run['errors'], 'q98MemoryVerdict': run['q98MemoryVerdict'],
    },
    'visibility': {
        'readiness': frontend['readiness'],
        'heartbeats': [{'cycle': item['cycle'], 'elapsedSec': item['elapsedSec'],
                        'visibility': item['visibility']} for item in frontend['samples']],
        'heartbeatCount': len(frontend['samples']),
        'unfocusedHeartbeatCount': sum(not item['visibility']['focused'] for item in frontend['samples']),
        'hiddenHeartbeatCount': sum(item['visibility']['hidden'] for item in frontend['samples']),
        'interpretation': 'Unfocused is observed, but is not itself a direct Q98 abort predicate. It does not establish occlusion or the cause of the cumulative rAF gap.',
    },
    'phase22': {
        'frontendCheckpoint': checkpoint, 'driverSample': phase,
        'precedingRegularSample': regular,
        'derivedSeconds': {
            'precedingRegularSampleDuration': difference(regular['timestamp'], regular['samplingStartedAt']),
            'frontendCheckpointDuration': difference(checkpoint['endedAt'], checkpoint['startedAt']),
            'driverBeginObservationLag': difference(phase['timestamp'], checkpoint['startedAt']),
            'remainingWindowWhenDriverSamplingStarts': difference(checkpoint['endedAt'], phase['timestamp']),
            'samplingEndAfterFrontendEnd': difference(phase['samplingEndedAt'], checkpoint['endedAt']),
        },
        'interpretation': 'Same-loop regular sampling delayed checkpoint observation; invalid phase sampling is not the direct run-abort condition. No per-subcommand timings establish a vmmap pause or a product defect.',
    },
    'boundaries': [
        'No acceptance thresholds, sampling intervals or modes were changed.',
        'No GUI, build, product test or new measurement was run by this analysis.',
        'No memory growth verdict can be inferred from zero post-warmup valid pressure samples.',
        'The cumulative maximum rAF gap does not locate its precise occurrence.',
        'No later run is evaluated here, and run durations must not be spliced.',
        'This report is independent of the CI evidence archive.',
    ],
}
with (ROOT / 'facts.json').open('x') as output:
    json.dump(facts, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({'originals': len(facts['originals']), 'report': original(ROOT / 'report.md'),
                  'facts': original(ROOT / 'facts.json')}, ensure_ascii=False, indent=2))
