# 首轮正式 Q98：只读时序分析

本报告只分析 `/private/tmp/revia-m2-final-measure-ex9swy__/q98*` 中明确属于首轮的已结束原件；不读取后续活动运行，不运行 GUI、产品检查或新实验，不修改源码或原件。`facts.json` 保存本报告依据的路径、原字节 SHA256 和从原件计算的时序值；分析结果不冒充新的运行日志。

## 结论

1. **首轮不通过并保留**：目标 1800 秒，实际报告 78.54 秒，driver exit=1；现有退出记录声明受测 binary 和 integration sources 不变。
2. **确定的终止条件是累计最大 rAF 间隙 2179ms 超过既有 2000ms 阈值**，不是 `focused:false` 本身，也不是 phase22 的取样失败直接终止。
3. **phase22 确实取样超窗**。一次常规内存采样阻塞同一 Python 轮询约 3.528 秒，driver 发现 BEGIN 时前端 3.5 秒静置窗口只剩约 184ms；阶段取样又耗时 4.125 秒，跨过 END。现有工具将其标无效是正确的，不能将它当压力后内存样本。
4. 已观察到失焦，但没有证据把失焦、系统调度、测量工具扰动或产品阻塞中的任何一个定为 2179ms 的根因。**不宣称 vmmap 暂停了 WebContent，不宣称产品已复现卡死，不宣称内存增长或泄漏。**

## 固定身份

- integration commit：`f10fc971c14e556c239cb4648cabfbbfc28ad4b4`。
- binary 构建源码：`2a51b160d1c3871b9c67fee81ae6f082910bc1f8`；SHA256：`fd5ffc86131aebbe77850487192005166a63c1a98f9e97aa72b3ddaa1d96988d`。
- driver PID 88350，Revia PID 88354；实际脚本位于 `/Users/garland/.codex/worktrees/m2-close-finish/Revia/tools/bench-long-running.py`。
- 实际脚本与 m2-ui 同名脚本原字节相同，SHA256 为 `e863052801d5818c4df1e29e2ed893a9b376764060da7dc452910a9d4763f574`；两树 `src/App.tsx` 也相同。
- 参数为正式 `--minutes 30 --interval 10`，无 diagnostic、无 minimal logging、无 keep-on-top；外层 `caffeinate -di`。本报告没有改变这些条件。

## 首轮时间线

以下统一使用 2026-10-25 UTC，数字来自原始 JSON，不从渲染后的工具输出转抄哈希。

| 时刻 | 已记录事件 | 可得结论 |
| --- | --- | --- |
| 08:04:42.885504 | driver 记录开始 | 整轮计时基点 |
| 08:04:44.473 | 前端 operationsStartedAt | readiness 一次通过，记录 focused=true、hidden=false、maxFrameGap=29ms |
| 操作心跳 10/21/31/41/51/65/75 秒 | 7 次 focused=false；全部 hidden=false、hiddenTransitions=0 | 证明各采样时刻无文档焦点，不能证明整个窗口被遮挡；也不是现有 Q98 直接失败条件 |
| 08:05:45.397512–08:05:48.925186 | 第 7 笔常规内存取样，耗时 3.527674 秒 | 同一主循环内串行执行；这期间不能 poll 新 checkpoint |
| 08:05:45.813–08:05:49.315 | 前端 phase22，staged.ts / split，pressure=false | 实际静置区间约 3.502 秒，非压力阶段 |
| 08:05:49.130772 | driver 阶段采样开始；observed/start elapsed 均 66.245 秒 | 相对前端开始已晚约 3.317772 秒，只剩 0.184228 秒 |
| 08:05:53.255924 | 阶段采样结束；duration=4.125 秒 | 超过前端 END 约 3.940924 秒；END 已出现，3500ms 超窗及墙钟包含校验均失败 |
| 08:06:00.822 | 前端记录“可见连续合成中断” | 最后心跳累计 maxFrameGap=2179ms；实际触发正式长测中止 |
| 08:06:01.424963 | 总报告结束，actualDuration=78.54 秒 | 未达到 1800 秒，没有热身后有效压力样本 |

来源：`q98.json`、`q98.json.frontend.json`、`q98.json.samples.jsonl`、`q98.json.phase-samples.jsonl`、`q98.json.frontend.log`、driver launch/exit/stdout/stderr。单次 `q98-start-observation.json` 及截图只代表一个观察时刻，不是连续前台录像。

## 代码解释与边界

- `src/App.tsx:2084` 的 readiness 只要求 `!hidden && rafPerSecond > 5`；`:2092` 重置监测器。`focused` 是记录字段，不是这个条件。
- `src/lib/soak.ts:32` 累计自上次 reset 后最大的 rAF 间隙；`:46` 一次采样等待约 1 秒，`:53` 读取采样末尾的 `document.hasFocus()`。心跳和 checkpoint 不重置该最大值，所以最后发现 2179ms 不能定位其精确发生时刻。
- `src/App.tsx:2121` / `:2178` 用 hidden、低 rAF、hiddenTransitions 或 maxFrameGap>2000 判中止。`focus = diagnostic?.focus` 指单项诊断类别，不是窗口焦点；不能将诊断恢复逻辑用于正式长测续接。
- D06 的 `src/App.tsx:2528` / `:2560` 才直接检查 focused/blur。不能把 D06 的更严格焦点条件倒写成首轮 Q98 已执行的条件，也不能把 `focused:false` 等同 `hidden:true`。
- `src/App.tsx:2188` 在行/高亮静止后记录 startedAt，await BEGIN，等待 3500ms（pressure 时 16000ms），await END，再记录 endedAt。`sleep` 为异步定时器，不是阻塞 JS 的忙等待。
- `tools/bench-long-running.py:458` 在同一主循环里先 poll checkpoint，再做常规采样；`:481` 每第 3 笔附带串行 footprint 查询。原件确证本次常规采样占据了 phase22 几乎整个窗口，导致发现 BEGIN 延迟；这不是轮询间隔固定为 10 秒，主循环正常空档只睡 0.2 秒。
- driver `:209` 的阶段采样串行进行进程归属/RSS、Rust vmmap、WebContent vmmap、再次归属检查；各子命令可等待数秒，未与前端建立“采样完成再结束 hold”的握手。现有记录只有整组起止，不能进一步证明哪一子命令消耗了多少时间。
- driver `:229` / `:243` 在 END、固定窗口及墙钟区间不符时正确标记无效；`:276` 只保存该阶段结果，**不因这一无效阶段直接结束应用**。
- phase22 为 `pressure:false`，没有发送低内存通知。压力阶段约每第 5 个 checkpoint 才产生，driver `:198` 才会发送通知并等待约 10 秒。首轮未运行到这一阶段。
- driver `:326` 的 Q98 只使用热身 180 秒后的有效压力样本判断 WebContent；Rust 也要热身后常规 footprint。本次各趋势序列 sampleCount=0，结论是“数据不足，不能判断”，不是超出增长阈值。
- 总报告中的“缺少必需操作负载”来自成功收尾前未写入汇总计数（`:345`）；日志已显示真实切换/滚动在运行，不能把这条衍生错误改述为“没有执行操作”。

## 最小后续建议

保留首轮，不修改 2000ms、3500ms、16秒、10秒、180秒、30分钟及内存阈值，不拼接两次运行时长。

**允许一次同参数、独立输出、明确激活后不再切走的完整运行，作为排除焦点/环境混杂的最小对照；不是认定首轮问题被修复。** root 已通知这样的 attempt02 正在进行，本报告不读取或干扰它，不建议并行开展 vmmap 等诊断增加负载。

单纯激活不能保证解决本次已证的串行采样延迟。后续同参数运行若再次在相同边界失败，停止重复试跑，先单独定位采样工具：核对已有的常规取样起止、checkpoint BEGIN/END、阶段取样起止及可见性数据；如还不能区分耗时，需要另行安排仅定位用的分子命令计时证据，不改阈值、不拿短诊断替代正式验收，也不直接修改产品。

一个阶段采样成功或运行仍存活都不等于 Q98 通过。最终仍须同进程完成 30 分钟、连续操作/可见性合格、取得足够热身后有效压力样本并分别满足已确认的内存上限和趋势。

本报告与 CI 修复归档分开保存，不将首轮 Q98 失败混入 CI 成功结论。
