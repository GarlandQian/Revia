# 最终 D06 独立只读审核

**结论：四组均是有效可见窗口测量。标准首屏、独立语义DOM首rAF、真冷文字及滚动覆盖子项达到既定口径；必须同时保留标准统一原热跳18ms/false，不写成“全部原跳转都在一帧内”。没有发现需作废或机械重跑四组的来源/可见性问题。** 本报告只审核D06，不判断M2整体完成；未读取或操作活动Q98。

## 固定来源与有效性

原件根目录 `/private/tmp/revia-m2-final-measure-ex9swy__`。集成提交 `f10fc971c14e556c239cb4648cabfbbfc28ad4b4`；生产构建 `2a51b160d1c3871b9c67fee81ae6f082910bc1f8`；bundle SHA256 `fd5ffc86131aebbe77850487192005166a63c1a98f9e97aa72b3ddaa1d96988d`。

已核 `context.json`、`integration-source-before.json`及固定Git差异：集成版相对构建只改任务10文档与review_marks测试，生产源码/资源相同。源码快照列2277文件；所读spec/benchmark/probe与快照SHA一致。四份独立launch/exit关联同bundle、四个不同PID/应用数据目录；Rust启动日志实际data_dir与launch一致；全部exitCode=0、binaryUnchanged/integrationSourcesUnchanged=true。

四组均仅一个正确文件/视图combo，ok=true、focused=true、focusLosses=0、hidden=false、hiddenTransitions=0；1280×800、DPR2，diff视口高627。四个jumpDom均sourceReady=true，preparationError/jumpDomError=null，无超时。标准并排stderr保留一条Window move警告，不据此否定已取得的有效测量。

## 数值（毫秒）

| 场景 / PID | 首屏含读状态 | 原appear / warm | 原目标缓存 / warm缓存 | 独立文字出 / 回 | 独立首rAF核验出 / 回 | 返回完整颜色DOM |
| --- | ---: | --- | --- | --- | --- | ---: |
| 标准并排 / 85755 | 137 | 10 / 4 | 是 / 是 | 2 / 1 | 7 / 14 | 33 |
| 标准统一 / 87247 | 124 | **18 / 7** | 是 / 是 | 1 / 1 | 10 / 14 | 33 |
| 真冷并排 / 87618 | 135* | 11 / 4 | 否 / 是 | 4 / 2 | 9 / 9 | 29 |
| 真冷统一 / 87831 | 137* | 13 / 4 | 否 / 是 | 3 / 1 | 7 / 14 | 32 |

*冷仓库30000源行、显示行30001/60001，首屏数据独立报告，不混入标准150ms门槛；标准137/124均低于150。原fromOpenWorktree为198/181/210/208，不偷换成首屏fromListChanges口径。

- 标准独立目标事前缺行0/0，真冷各缺35行；冷原jump及jumpDom的targetWasCached均false，返回均true。真冷文字4/3ms低于100ms，不靠文件大推定未缓存。
- 八次独立首rAF均35/35、textMatched=true、canvasReady/canvasAligned=true、placeholderRows=0、frameReady/textWithinBudget=true。依据probe语义，覆盖完整文字、旧/新行号、marker、split结构、行top与canvas偏移/高度及预先核对的视口/底图几何；不是GPU像素扫描或实时逐行bounding-box测量。
- 两个冷跳同步检查有35行占位及ready底图，首rAF已到齐文字；同步有占位不证明它曾显示一整帧。
- 所有返回首rAF颜色尚未全齐，最终33/33/29/32ms token DOM才严格匹配；不能声称首帧全色。原colorRestoreMs=32/22/24/22只代表退出compact，不是同一指标。

## 原18ms与滚动边界

标准统一原`appearMs=18`、`withinOneFrame=false`，分段scrollCall11+taskQueue7；原目标行8061，独立jumpDom目标10748。按 `benchmark.md:70`、`:75`，18ms不是纯上屏时间，但也不能减去任务等待、倒填1ms/10ms或用独立探针消除这条未达原阈值记录。可并列写“独立正常首渲染机会前DOM就绪；原计时有一笔超阈值”，不可给无保留“每笔全绿”。

| 场景 | 屏数 / 真rAF / 兜底 / 未覆盖 | 最大帧 / p95 | droppedFrames |
| --- | --- | --- | ---: |
| 标准并排 | 60 / 60 / 0 / 0 | 18 / 17 | 0 |
| 标准统一 | 60 / 60 / 0 / 0 | 31 / 18 | 3 |
| 真冷并排 | 60 / 60 / 0 / 0 | 48 / 17 | 2 |
| 真冷统一 | 60 / 60 / 0 / 0 | 18 / 18 | 0 |

保留31/48ms等不利值；Q84/D06未规定慢帧清零，不因孤立最大值增设门槛，也不据单次样本证明所有性能绝无回归。未覆盖0只证明行数据覆盖。

## 实屏与未覆盖

已逐图查看两份`d06-standard-*-scroll.jpg`及两份`d06-cold-*-ui.jpg`：文件/视图与JSON一致，可见区域文字连续、颜色已恢复，无整块白。主代理记录标准两视图各真实滚动8页；本审核只直接复核留存的离散测后画面，不能从单张图复算页数或冒称逐帧录像。AX标题与各launch PID吻合。

按 `benchmark.md:74`、`:76`、`:77`：DOM计时包含探针开销，不是屏幕上屏时间；测后截图不是计时期间帧。源高亮显式预热，返回颜色诊断不能替代普通模式“首次打开后静置补色”；本批图仅证明测后/滚动后所见位置，其他已有普通桌面证据应单独引用。四组只证明所列负载/两视图，不证明Q98、所有文件类型/主题或全平台呈现。

详细逐项数值及输入JSON SHA见同目录 `metrics.json`。原始JSON/launch/exit/日志/截图全部只读保留，无新测量、无fixture复制、无仓库修改。
