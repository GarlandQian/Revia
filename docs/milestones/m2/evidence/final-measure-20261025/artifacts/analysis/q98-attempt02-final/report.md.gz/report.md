# Q98 attempt02 终态独立复核

本报告仅只读复核 `/private/tmp/revia-m2-final-measure-ex9swy__/q98-attempt02*` 的已结束原件及本地固定实现，不操作 GUI，不运行 build、test、长测或新的测量脚本，不修改源码、原件或 fixture。`facts.json` 保存精确原件路径、原字节 SHA256、派生统计及其计算边界。本报告不是新的运行结果。

## 结论

1. **本次正式 Q98 不通过**：driver exit=1，目标 1800 秒，driver 墙钟时长 1223.25 秒；没有最终前端报告，更没有可核对的 1800 秒主动操作时长。退出原件记录 binary/source 不变。
2. **已确认的执行错误是常规采样中 `vmmap -summary 90688` 返回 255**，不是前端自报合成中断。前端日志在结束前仍持续操作；没有“长期运行基线异常中断”或“完成”记录。现有证据不能确定 vmmap 失败的系统原因，也不能将其写成产品崩溃、WebContent 重启或内存泄漏。
3. **18 个阶段不是全部取样超窗，也不是 END 都丢失**：18/18 的 `samplingChecksPassed=true`、`checkpointEndConfirmed=true`；最终唯一错误均为“前端报告缺少唯一的 staged/split checkpoint”。预期 `.frontend.json` 文件确实不存在，因此 driver 保持 `frontend={}`，不能核验最终 checkpoint 的完整时间区间、固定文件/视图及 hold 内可见性。全部 final-invalid 是现有严格校验的结果，不能凭 provisional 成功或 BEGIN/END 就改成 valid。
4. **Rust 振幅门槛已有独立不合格数据**：现有规则选出的 34 个热身后常规 footprint 点，首点 149.2 MiB、峰值 231.2 MiB，最大增量 82.0 MiB，超过 10 MiB；斜率 -0.9827 MiB/min 在 0.5 上限内。它是振幅超限，不等于“持续增长”，更不证明泄漏。不能因另外两项缺有效阶段证据而忽略这一项。

## 固定身份与同进程归属

- integration：`f10fc971c14e556c239cb4648cabfbbfc28ad4b4`；Release 构建源码：`2a51b160d1c3871b9c67fee81ae6f082910bc1f8`。
- binary SHA256：`fd5ffc86131aebbe77850487192005166a63c1a98f9e97aa72b3ddaa1d96988d`。
- driver PID 90683，Revia PID 90685。参数仍是 `--minutes 30 --interval 10`，无 diagnostic、无 minimal logging、无 keep-on-top，外层 `caffeinate -di`。
- 120 个留存常规样本全部为 `serviceDomain=pid/90685`，WebContent `[90688]`、Networking `[90689]`、GPU `[90687]`。18 个阶段采样前和采样后归属也全部一致，没有记录到 PID 切换。
- 这是离散归属证据，不是无间断进程录像；失败的最后一笔采样没有完整落盘，不能越过证据边界保证其后的子进程状态。
- 实际 driver 位于 `/Users/garland/.codex/worktrees/m2-close-finish/Revia/tools/bench-long-running.py`；与 m2-ui 同文件原字节相同。`src/App.tsx`、`src/lib/soak.ts`、`src-tauri/src/commands.rs` 及现有 bench 测试文件也逐件相同；哈希见 facts。没有重新构建或重新散列当前 binary，运行期间不变依据为原退出记录。

## 实际时序

以下为 2026-10-25 Asia/Shanghai（UTC+08:00）；原前端日志使用 UTC。

| 时间 | 已留存事件 | 边界 |
| --- | --- | --- |
| 16:10:48.008443 | driver 开始 | 总报告墙钟基点 |
| 16:10:48.544 | 前端记录长测启动 | 非最终 `operationsStartedAt` 字段 |
| 16:10:49.690 | 第一条打开文件操作 | 说明实际负载已开始 |
| 16:11:29.911 | 原件记录 native 点击标题栏激活 PID90685 | 发生于启动约42秒后；不能改述为全程已有完整 focus 记录 |
| 16:30:54.349877—16:30:56.425793 | 最后阶段384取样，2.076秒，provisional checks通过 | 后续有匹配 END，但缺完整前端 checkpoint 结果 |
| 16:30:59.886955—16:30:59.899685 | 最后一笔完整常规采样，elapsed=1211.87 | 第120笔；最后失败候选没有追加为第121笔 |
| 16:31:10.114 | cycle389 完成 `src/Model.swift` | 循环仍有进展，不支持据本次错误认定产品卡死 |
| 16:31:11.114 | `1220s/1800s` 心跳，visible、rAF16.0；随即开始打开 generated.ts | 日志打印发生在该心跳中断检查通过之后 |
| 16:31:11.243 | 最后可见前端/后端取块日志 | 仅证明到此时仍有活动 |
| 16:31:11.251136 | stderr 文件最后写入时间，内容为 vmmap 两行错误 | 文件 mtime，不冒充 vmmap 调用开始/结束时间 |
| 16:31:11.261618 | 阶段 JSONL 文件最后写入时间 | 与 finalizer 重写最终阶段状态相符，不是新的采样 |
| 16:31:11.266764 | 总报告 `endedAt` | 记录 `frontend={}`、18 invalid |
| 16:31:11.305799 | 外层记录 driver exit=1 | 记录 binary/source unchanged=true |

stderr 原文含“cannot examine process 90688 … for unknown reasons, even though it appears to exist”以及“mach port for process 0 not valid”。后者是 vmmap 内部错误文本，实际 argv 目标仍是 90688，不能解释成 driver 误采 PID0。`sudo` 是工具提示，本复核没有执行或建议借此跳过平台边界。

stderr 没有逐调用时间戳、结构化 stdout 或前后进程状态。文件 mtime 支持这一近末尾写入顺序，但不能精确测定失败发生在最后心跳的哪一刻，也不能据此确认端口/权限/进程生命周期的根因。

## 错误路径与18个阶段为何失效

1. `tools/bench-long-running.py:481` 每第3笔常规采样做 footprint；已经落盘120笔后，下一个候选仍满足此条件。正式模式依次先取 Rust footprint，再取 WebContent footprint（`:483`、`:490`）。阶段采样自身的异常被 `:221` 收入阶段 errors，通常不会作为这次顶层 CalledProcessError 终止主循环；本次18阶段 sampling checks全部通过，顶层异常目标是90688。因此可由代码和原件推断失败属于最后一个常规采样候选，而非第18个阶段。
2. `:491–494` 对这类异常先查 Revia 是否已退出；若已退出会 break，不会记录这条顶层 CalledProcessError。本次异常被记录，说明在该次检查时 Revia 仍被认为存活。之后 `:503–512` 记录错误，并在进程仍存活时 terminate/wait，必要时 kill。
3. 当前没有独立“已发送 terminate”事件，不能把该条件分支具体执行时刻写成实测。可以确认代码进入错误清理路径，且最终传给完成校验的应用 returncode 为0——它由“应用未成功完成：0”的 fallback 文本反映。**returncode0 不代表业务或长测完成**，因为 `:347` 同时要求前端 `ok=true`。
4. 前端 `src/App.tsx:2116` 把完整 checkpoints 仅挂在内存 report；`:2498–2509` 只有正常结束或自身 catch 后才写最终 measurement。driver 清理并不会让 JavaScript 自动进入这个 catch。正常写结果的 Rust 入口在 `src-tauri/src/commands.rs:1002` 先落 JSON，`:1013` 再安排500ms后 exit0。本次预期 JSON 缺失，现有前端日志也没有完成/异常消息，不支持把它当正常写结果后退出。
5. driver `:518–522` 仅在预期 JSON 存在时读取。这里是文件缺失，不是“有文件但解析失败”。`frontend` 因而保持初始化的空对象。
6. `:252` 已从文本日志核到每个 END；但 `:255–259` 还要求前端报告中有唯一同ID的 staged/split checkpoint，之后才核压力标记、hiddenDuringHold、完整墙钟区间。空对象使18个阶段统一在这个更深层检查失败。每个原件只有这一项 final error，不能称其超窗、换PID或已观察到hold内遮挡。
7. `:525` 将最终状态重写到阶段 JSONL。现在该文件与总报告18项一致；driver stdout 仍保留所有 `samplingChecksPassed=True … pending closure`。这两个状态并不矛盾：采样即时检查通过不等于最终闭合验收通过。

现有 `tools/test_bench_long_running.py:229` 已明确要求缺 frontend 时不能 valid。返修不应删掉这一保护；要修的是失败时证据不能完整落盘的问题，而非把缺少必要证据判为有效。

## 主动时长与可见性

- 1223.25秒是 driver 墙钟；日志的1220秒也由 `src/App.tsx:2165` 计算墙钟 elapsed，不扣阶段暂停。它们都不是正式主动操作时长。
- 真正的主动时长在 `:2435–2450` 才按 wall minus checkpointPause minus visibilityPause 写入最终报告。当前没有该字段、没有最终计数，不能补造精确值，也不能把它当0秒实际负载。
- 已有18次完整BEGIN/END，含15次普通、3次pressure。仅程序计划等待就包括 `18×0.5 + 15×3.5 + 3×16 = 109.5秒`，实际暂停还包含就绪检查及IPC。这个数字只是既有代码的名义等待合计，不是恢复出的实际暂停计时。无论如何，连墙钟都不足1800秒，不满足主动操作30分钟。
- 文本日志可解析111条心跳，全部 `vis=visible`，报告的rAF范围6.4—61.0；没有前端完成或异常中断条目。按固定代码顺序推断，每条已打印心跳在当时通过了 interrupted 判断。
- 正式模式未启用结构化 diagnostic heartbeat；完整 `focused`、`maxFrameGapMs`、`hiddenTransitions` 留在内存 samples，随最终报告缺失未落盘。不能凭111条简写日志复造这些字段，也不能声称全程焦点或连续硬件可见性已完整证明。native激活与中途桌面观察各自只证明其记录边界。

## 三项Q98数值

门槛不变：热身180秒后，每项相对首点最大增量不超过10 MiB，线性斜率不超过0.5 MiB/min；WebContent只取有效压力后样本，且至少3个，Rust取常规footprint。依据 `docs/milestones/m2/spec.md:67` 及 driver `:310–342`。

| 指标 | 原报告可用于该项计算的样本 | 首点 / 最大值 / 最大增量 | 斜率 MiB/min | 本次可说的结论 |
| --- | --- | --- | --- | --- |
| WebContent footprint | 0个有效压力后样本 | 不可计算正式值 | 不可计算正式值 | 证据不足，不是已证实超过增长门槛，也不是通过 |
| WebKit malloc allocated | 0个有效压力后样本 | 不可计算正式值 | 不可计算正式值 | 同上 |
| Rust footprint | 34个热身后常规点 | 149.2 / 231.2 / 82.0 MiB | -0.9827 | 振幅超过10；斜率在上限内；18/34点超过首点+10，末点164.8也比首点高15.6 |

因 frontend 缺失，原 driver 用 `setupSeconds=0` 的既有 fallback 选择热身起点；本报告保留这个计算语义，不延长热身、不删峰值、不选择新的基准。Rust序列从183.26到1191.76秒，最小116.0 MiB，走势明显有回落，因此不能用“最大增量82”替代泄漏诊断。

另外留存了3个**未获最终有效性**的pressure原值，ID108/214/320：footprint为72.7、79.5、80.3 MiB；malloc allocated为21.4、24.0、23.6 MiB。仅对这些不可验收原值按同一公式作描述性计算，分别得到最大增量7.6/2.6 MiB，斜率+0.6782/+0.1963 MiB/min。这个额外计算不是恢复有效性或正式Q98判定；它只提醒不能预先承诺“补齐采样证据后所有内存项就会通过”。不使用普通WebContent RSS上升替代压力后门槛。

## 最小返修建议

1. **先修测量证据收尾，不做第三次盲跑。** 沿用已有测量路径，使开始/进度/每个完成checkpoint的完整结构及失败原因能可靠增量落盘；总报告缺失时，清楚区分“checkpoint metadata未落盘”和真实超窗/换PID/遮挡。保留逐阶段即时状态及最终状态，不从日志猜造精确时间或hidden字段。不能直接在每个checkpoint调用现有 `writeMeasurement`，该入口会安排退出，须保持持久记录与终止动作的明确边界。
2. **给既有 vmmap 调用和错误清理补完整原始诊断。** 记录精确argv、目标PID、起止时间、stdout/stderr、退出码，以及失败时自身子进程状态和是否发送terminate/kill。保持失败为失败，不自动sudo、不用RSS代替、不静默忽略或重试到通过。根因仍需已有证据或另行获准的最小定位证明。
3. **保留并单独处理Rust振幅不合格。** 证据收尾修复不能消除这34点的事实；先定位既有负载下的Rust占用波动，不依据未证假说改缓存、强制GC或放宽10 MiB/0.5 MiB/min/热身/时长。现有Python bench测试已有missing frontend、同PID、窗口闭合及Q98契约，可在实际返修后集中复核相关用例；本次未运行它们。

未来即使工具定位完成，仍须固定Release、独立输出、同一进程完整30分钟主动操作及足够有效压力后样本。两次失败原件都保留，不能拼接时长或把本报告当修复后重测通过。
