# Q98 attempt02 中断：只读代码路径诊断

## 结论

本轮不能验收，不能据现有原件确定产品崩溃、WebContent 重启、权限变化或 vmmap 平台故障。已定位一个确定的证据丢失路径：常规 vmmap 抛错后，driver 若发现应用仍存活就清理终止；前端完整结果仅在 runSoak 自然结束/自身异常后写一次，故 driver 中断会丢失在内存中的 checkpoint 描述及主动时长。该路径解释 `frontend={}` 和全部阶段最终失效，但不是 vmmap exit255 的根因证明。

## 实测事实

- 驱动墙钟 `1223.25s`，目标主动 `1800s`，退出码1；最后应用码0不等于长测完成。受测 source/binary 的外层核对为未变。
- 120笔已记录常规样本始终为 `pid/90685`：WebContent90688、Networking90689、GPU90687。18次阶段采样前后同组PID；这证明已有样本的归属，不证明最后失败瞬间的身份/存活状态。
- 18阶段全部 `samplingChecksPassed=true`、匹配END=true；最终全部invalid的唯一原因都是“前端报告缺少唯一的 staged/split checkpoint”。不能写成18次vmmap或窗口采样都失败。
- `.frontend.json`不存在；前端日志无“基线完成”或“异常中断”，最后仍是 `1220s/1800s cycle=389` 心跳及打开/读取 `src/generated.ts`。这里1220是heartbeat按墙钟计算，不是扣除checkpoint暂停后的主动时长。最后日志rAF16.0仅描述一个已观测窗口，不证明结束时可见或没有帧间隔中断。
- stderr只给出vmmap无法检查90688、mach port无效，未记录该失败调用的精确起止时刻、调用前后主/子进程状态或driver是否发送terminate。stderr的“try sudo”不是已确认修复建议，更不应绕开平台保护。
- Rust已存常规footprint按现有规则：34笔、首149.2、最大231.2、最大抬升82.0 MiB、末164.8、斜率-0.9827 MiB/min。超过+10门槛；负斜率不取消逐样本门槛，也不能直接称持续泄漏。缺前端setupSeconds使报告暂取0为warmup起点，须在下一版保留真实setup元数据而非事后选首样本。
- 原始压力后footprint为72.7/79.5/80.3 MiB，malloc为21.4/24.0/23.6 MiB；三笔均因完整前端阶段证据缺失而invalid。仅作定位线索，不得改valid、补造隐藏状态或用它们推导本轮通过。

## 代码链

1. `tools/bench-long-running.py:469`通过目标进程launchd表读取关联PID/RSS；:478拒绝相对于首组的PID变化。:483先读Rust vmmap，:490再读WebContent。常规采样没有失败后的PID/生命周期快照，也只有成功完成后:497才追加整个样本；因此最后一次已成功的Rust取值也会随之后WebContent失败而丢失。
2. :491遇到SubprocessError时，如果此刻`proc.poll()`已非None则break，否则:494重新抛出。报告确有CalledProcessError，因此走了抛错分支，即那次poll尚未观察到主进程退出。:503记错误；:506再次poll，仍活着就:507 terminate，5秒后还活着则:511 kill。**当前没有cleanup分支记录，不能确定第二次poll是否仍活着，也不能把“driver肯定关闭”写成实测。**
3. `src/App.tsx:2195`创建的完整checkpoint只放内存。BEGIN/END日志只有ID和pressure，缺file/view/hiddenDuringHold、精确描述记录。:2207先写END，:2209–2210才在内存填隐藏/结束字段。:2435–2455只有正常达到目标后计算最终主动时长/负载；:2498捕获的是前端自身异常，不会捕获OS终止。:2509最后一次性writeMeasurement。
4. `src-tauri/src/commands.rs:1002`先写结果文件，成功才:1013安排500ms后process::exit(0)。无结果文件且前端仍有运行日志，不支持“自然写报告后成功退出”；不存在文件的根本原因仍需下一轮有生命周期证据确认。
5. `tools/bench-long-running.py:518`只在退出后读最终前端文件；文件缺失保留空对象。:243–273最终校验必须有唯一staged/split前端描述及真实起止/隐藏状态，故18阶段全部invalid。这个fail-closed判定是正确的，不应放松。
6. macOS `src-tauri/src/platform/macos_exit.rs`会把Cocoa terminate交给共享close driver，前端最终可用request_exit令AppHandle.exit(0)。但仓库代码没有把本次SIGTERM/原生退出来源记到长测结果，不能据码0倒推是用户关闭、系统退出还是driver清理。

## 最小下一步（交原Pi，不直接实施）

- 先补**观察性证据保全**：采样命令的精确argv/PID/起止/退出码/stdout/stderr；失败时保存已经获得的部分结果和一次带时间戳的进程归属/存活快照；记录driver清理前poll、是否terminate/kill、wait结果和报告写入状态。保持失败即不通过，不静默重试替换坏样本，不增加权限，不改PID归属规则。
- 前端每个已结束checkpoint用现有debugLog或独立进度journal持久保存完整描述，以及setup时间/操作开始/计数；失败只产出明确`incomplete`的部分报告。driver仍需最终完成证明才能验收；不能让进度journal伪装最终ok。不要为此扩大产品普通模式或引入新测试框架。
- 用已有 `tools/test_bench_long_running.py`补可稳定复现的回归：主进程存活时vmmap失败、失败后自然退出竞态、driver终止、无前端最终结果、已闭合进度保留但整个run不通过。该文件现有阶段失败测试不足以覆盖main循环cleanup/最后一次样本丢失。
- 然后在固定源码/独立fixture做最小诊断确认错误路径留证；如需真实长测，必须是新的完整同进程1800主动秒，不续接本轮。现有vmmap原因未明前，不把“重跑碰到正常”当修复。
- Rust抬升另列产品/分配行为定位，不与vmmap根因混为一谈。不能通过改暖机时间、挑较高首样本、同阶段替代常规Rust取样、降低操作负载或放松+10/0.5阈值来消除失败。

## 工作边界

仅阅读指定原件、源码、既有测试；未启动GUI/应用、未运行测试/采样/build，未编辑仓库/fixture/原件。只在本独占tmp目录写本报告与派生facts.json。所有读取原件与相关源码SHA见facts.json。未找到用户DiagnosticReports目录中与Revia/WebKit/vmmap名称匹配的报告；此有限文件名检查不是系统无崩溃证明。
