# 任务 05 R05-D1 确认文案修正检查清单

基线：a588181651e29c90191a5c0cec0aa24678b94315

## 检查前源码 SHA-256（本轮仅改这两个前端文件）

5d0c5318f7a846aa374548c6282548d1378c034fe4e2b78e25588924e7c4b3d3  src/lib/i18n/zh-CN.ts
dc9c41735d1e739e4d8fe210661529dd7987251d22237033a915afb18635e805  src/components/app/RecoveryDialogs.tsx

改动前完整 diff：pre-change.diff

## 命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |

tsc 与 lint 的 stdout 为空；build 的 stderr 只有既有 Vite configLoader 提示。

## 未执行

Rust / Node / Python 测试、Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
桌面上的按钮实际显示未验证（本轮未启动应用）。
commit=804d88dbd344b13992e773c34f3403775fe5653c
