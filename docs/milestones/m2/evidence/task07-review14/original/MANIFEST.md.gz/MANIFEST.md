# 任务 07 第十三轮限定返修检查清单

基线：574660444e385f641df93c89d083acacbe1ecd7f

## 最终命令 / 退出码 / 原始输出

| 命令 | 退出码 | 输出 |
| --- | --- | --- |
| pnpm exec tsc -b | 0 | tsc.out / tsc.err / tsc.exit |
| pnpm lint | 0 | lint.out / lint.err / lint.exit |
| pnpm build | 0 | build.out / build.err / build.exit |
| node tools/test-refresh-gate.mjs | 0 | refresh-gate.out（tests 70 / pass 70 / fail 0） |
| cargo test --test review_marks | 0 | review_marks.out（31 passed） |
| cargo test --lib | 0 | cargo-lib.out（100 passed） |
| git diff --check | 0 | git-diff-check.out / git-diff-check.exit |

本轮只改 `src/lib/refreshGate.ts`（mergeEntry 持有读取真值）与两个测试文件，
未改 Rust 生产代码、未改绑定类型。

注意：`cargo test --lib` 会重跑 ts-rs 的 `export_bindings_*` 测试，把 20 个绑定文件
的行尾空白写回（这是既有行为）。检查后按现有流程跑 `node tools/strip-binding-whitespace.mjs`
清理，`git diff --check` 恢复退出 0；三个被改源码的 SHA 复核仍与检查前一致，
清理后再跑一次 tsc 与 Node 用例（tsc-z / refresh-gate-z，均退出 0，70/70）。

最终检查前后源码 SHA（source-sha256-before-check.txt / -after-check.txt）逐行一致。

## 敏感性对照（sensitivity/）

| 回退的修复 | exit | tests | pass | fail | 失败用例 |
| --- | --- | --- | --- | --- | --- |
| A-no-hold | exit=1 | 70 | 67 | 3 | 读取真值持有（true 方向）：getRows 读到 B 已审后，旧全量回执不能把它改回未审（SP07-R13-1）; 读取真值持有（false 方向）：getRows 读到 U 已取消后，旧全量回执不能把它改回已审（ST07-R13-1）; 读取真值持有：v1→v2→v1 失效仍不被旧成功复活 |
| B-hold-seq-zero | exit=1 | 70 | 67 | 3 | 读取真值持有（true 方向）：getRows 读到 B 已审后，旧全量回执不能把它改回未审（SP07-R13-1）; 读取真值持有（false 方向）：getRows 读到 U 已取消后，旧全量回执不能把它改回已审（ST07-R13-1）; 读取真值持有：v1→v2→v1 失效仍不被旧成功复活 |
| C-override-skips-watermark | exit=1 | 70 | 69 | 1 | 读取水位：读取已观察到该序号时，旧成功不能再覆盖它的真值（ST07-R10-3 / SP07-R10-3） |

说明：
- `A-no-hold`：mergeEntry 只写回 UI 布尔值、不持有读取真值 → 三个持有用例失败。
- `B-hold-seq-zero`：持有但用 0 当水位（读到的状态不参与后续比较）→ 同样三个失败。
- `C-override-skips-watermark`：让持有记录绕过快照水位判断（相当于把单文件水位
  提升成整快照水位）→ 原有的「读取水位」用例失败，说明该捷径会破坏全量语义。

## 未执行

Release 构建、GUI/open、D06、双平台 CI、长测均未执行；未推送/合并/发布。
commit=fe171c30fff669ae25b6c43033f87c99b7e85d76
